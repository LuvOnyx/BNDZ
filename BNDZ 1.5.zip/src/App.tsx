/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import BNDZUI from './components/BNDZUI';
import ConfigurationDialog from './components/ConfigurationDialog';
import { ConfigProvider } from './data/configContext';

export default function App() {
  const [isConfigOpen, setIsConfigOpen] = useState(false);

  return (
    <ConfigProvider>
      <div className="h-screen w-full bg-[#1e1e1e] overflow-hidden relative text-white">
        <BNDZUI onOpenConfig={() => setIsConfigOpen(true)} />
        
        {isConfigOpen && (
          <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
            <ConfigurationDialog onClose={() => setIsConfigOpen(false)} />
          </div>
        )}
      </div>
    </ConfigProvider>
  );
}
