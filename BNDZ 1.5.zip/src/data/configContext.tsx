import { createContext, useContext, useState, ReactNode } from 'react';

export interface AppConfig {
    [key: string]: any;
    enableContextSubmenus: boolean;
    showTopMenubar: boolean;
    enableHistoryNavigation: boolean;
    sortFoldersFirst: boolean;
    isDefaultFileManager: boolean;
    inContextMenu: boolean;
    enableEverythingSearch: boolean;
    enableNativeThumbnails: boolean;
}

export const defaultConfig: AppConfig = {
    enableContextSubmenus: true,
    showTopMenubar: true,
    enableHistoryNavigation: true,
    sortFoldersFirst: true,
    isDefaultFileManager: false,
    inContextMenu: false,
    enableEverythingSearch: true,
    enableNativeThumbnails: true
};

const ConfigContext = createContext<{ config: AppConfig; updateConfig: (v: Partial<AppConfig>) => void }>({
    config: defaultConfig,
    updateConfig: () => {}
});

export const ConfigProvider = ({ children }: { children: ReactNode }) => {
    const [config, setConfig] = useState<AppConfig>(defaultConfig);

    const updateConfig = (newVals: Partial<AppConfig>) => {
        setConfig(prev => ({ ...prev, ...newVals }));
    };

    return <ConfigContext.Provider value={{ config, updateConfig }}>{children}</ConfigContext.Provider>;
};

export const useAppConfig = () => useContext(ConfigContext);
