/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface RenameOperation {
  originalName: string;
  newName: string;
  reason?: string;
}

export const IPC = {
  // Check if running inside a native Windows WebView2 container
  // This securely routes commands through the host WinForms/WPF app if available
  isNative: typeof window !== 'undefined' && !!(window as any).chrome?.webview,
  _listeners: [] as Array<(events: any[]) => void>,
  _initialized: false as boolean,
  _progressListeners: [] as Array<(progress: any) => void>,
  _conflictListeners: [] as Array<(conflict: any) => void>,

  init() {
    if (this.isNative && !this._initialized) {
        window.addEventListener("message", (e: any) => {
           if (e.data?.type === 'FS_EVENT_BATCH') {
              this._listeners.forEach(cb => cb(e.data.payload));
           } else if (e.data?.type === 'PROGRESS_UPDATE') {
              this._progressListeners.forEach(cb => cb(e.data.payload));
           } else if (e.data?.type === 'CONFLICT_DETECTED') {
              this._conflictListeners.forEach(cb => cb(e.data.payload));
           }
        });
        this._initialized = true;
    }
  },

  onFsEvents(callback: (events: any[]) => void) {
     this.init();
     this._listeners.push(callback);
     return () => {
        this._listeners = this._listeners.filter(cb => cb !== callback);
     };
  },

  onProgress(callback: (progress: any) => void) {
     this.init();
     this._progressListeners.push(callback);
     return () => {
        this._progressListeners = this._progressListeners.filter(cb => cb !== callback);
     };
  },

  onConflictContent(callback: (conflict: any) => void) {
     this.init();
     this._conflictListeners.push(callback);
     return () => {
         this._conflictListeners = this._conflictListeners.filter(cb => cb !== callback);
     };
  },

  executeFsOperation(operationId: string, action: 'copy' | 'move' | 'delete', source: string, target: string) {
     if (this.isNative) {
         (window as any).chrome.webview.postMessage({ type: 'EXECUTE_FS_OPERATION', payload: { operationId, action, source, target } });
     } else {
         console.log(`[Web IPC Mock] Instructed C# backend to ${action} from ${source} to ${target}`);
         
         // Mock progress and conflict for web preview
         if (action !== 'delete') {
             setTimeout(() => {
                 this._progressListeners.forEach(cb => cb({ operationId, percentage: 50, currentFile: source, bytesTransferred: 5000000, totalBytes: 10000000, speedBytesPerSecond: 10000000, itemsCompleted: 1, totalItems: 2 }));
             }, 500);
             setTimeout(() => {
                 this._progressListeners.forEach(cb => cb({ operationId, percentage: 100, currentFile: source, bytesTransferred: 10000000, totalBytes: 10000000, speedBytesPerSecond: 10000000, itemsCompleted: 2, totalItems: 2 }));
             }, 1000);
         }
     }
  },

  shellExecute(action: 'open' | 'openWith' | 'copyPath' | 'compress', path: string) {
      if (this.isNative) {
          (window as any).chrome.webview.postMessage({ type: 'SHELL_EXECUTE', payload: { action, path } });
      } else {
          console.log(`[Web IPC Mock] Shell Execute: ${action} on ${path}`);
          if (action === 'copyPath') {
              navigator.clipboard.writeText(path).catch(err => console.error("Clipboard failed", err));
          }
      }
  },

  resolveConflict(operationId: string, fileName: string, resolution: 'replace' | 'skip' | 'keepboth') {
     if (this.isNative) {
         (window as any).chrome.webview.postMessage({ type: 'RESOLVE_CONFLICT', payload: { operationId, fileName, resolution } });
     } else {
         console.log(`[Web IPC Mock] Resolving conflict for ${fileName} with: ${resolution}`);
     }
  },

  watchDirectory(path: string) {
     if (this.isNative) {
        (window as any).chrome.webview.postMessage({ type: 'WATCH_DIR', payload: { path } });
     } else {
        console.log(`[Web IPC Mock] Instructed C# backend to monitor: ${path}`);
     }
  },

  async aiBatchRename(filenames: string[], instructions: string): Promise<RenameOperation[]> {
    if (this.isNative) {
      // Native C# Interop layer
      return new Promise((resolve) => {
        const id = Date.now().toString();
        function listener(e: any) {
          if (e.data && e.data.id === id) {
            window.removeEventListener("message", listener);
            resolve(e.data.result);
          }
        }
        window.addEventListener("message", listener);
        
        // Post message to the WebView2 C# host process
        (window as any).chrome.webview.postMessage({ 
            type: 'AI_BATCH_RENAME', 
            payload: { filenames, instructions }, 
            id 
        });
      });
    }

    // Web Fallback: Proxy to local Node.js Server for browser previews
    const res = await fetch('/api/gemini/batch-rename', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ filenames, customInstructions: instructions })
    });
    
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || "AI Request Failed. Ensure GEMINI_API_KEY is linked.");
    }
    
    const data = await res.json();
    return data.renamedFiles;
  },

  syncFolders(source: string, target: string, entityId: string, action: 'copy' | 'move' = 'move') {
    if (this.isNative) {
       (window as any).chrome.webview.postMessage({ 
           type: 'SYNC_FOLDERS', 
           payload: { source, target, entityId, action } 
       });
    } else {
       console.log(`[Web IPC Mock] ${action} instructions sent to move ${entityId} from ${source} to ${target}`);
    }
  },

  getSystemDrives(): Promise<any[]> {
    if (this.isNative) {
      return new Promise((resolve) => {
        const id = Date.now().toString();
        const listener = (e: any) => {
          if (e.data && e.data.type === 'DRIVES_RESULT' && e.data.id === id) {
            window.removeEventListener("message", listener);
            resolve(e.data.payload);
          }
        };
        window.addEventListener("message", listener);
        (window as any).chrome.webview.postMessage({ type: 'GET_DRIVES', id });
      });
    } else {
      return Promise.resolve([
        { name: '/C:', label: 'Local Disk', totalSpace: 500_000_000_000, freeSpace: 40_000_000_000 },
        { name: '/D:', label: 'Space Hub', totalSpace: 2_000_000_000_000, freeSpace: 1_200_000_000_000 },
        { name: '/E:', label: 'Vault', totalSpace: 4_000_000_000_000, freeSpace: 100_000_000_000 }
      ]);
    }
  },

  getSystemShortcuts(): Promise<any[]> {
    return Promise.resolve([
      { name: 'Desktop', path: '/C:/Users/Developer/Desktop', icon: 'desktop' },
      { name: 'Downloads', path: '/C:/Users/Developer/Downloads', icon: 'downloads' },
      { name: 'Documents', path: '/C:/Users/Developer/Documents', icon: 'documents' },
      { name: 'User Profile', path: '/C:/Users/Developer', icon: 'profile' }
    ]);
  },

  setAsDefaultManager(enable: boolean) {
     if (this.isNative) {
        (window as any).chrome.webview.postMessage({ type: 'SHELL_INTEGRATION', payload: { action: 'setDefault', enable } });
     } else {
        console.log(`[Web IPC Mock] Instructed C# backend to ${enable ? 'set' : 'remove'} BNDZ as default file manager`);
     }
  },

  setInContextMenu(enable: boolean) {
     if (this.isNative) {
        (window as any).chrome.webview.postMessage({ type: 'SHELL_INTEGRATION', payload: { action: 'setContextMenu', enable } });
     } else {
        console.log(`[Web IPC Mock] Instructed C# backend to ${enable ? 'add' : 'remove'} BNDZ from folder context menu`);
     }
  },

  relaunchAsAdmin() {
     if (this.isNative) {
        (window as any).chrome.webview.postMessage({ type: 'SHELL_INTEGRATION', payload: { action: 'relaunchAdmin' } });
     } else {
        console.log(`[Web IPC Mock] Instructed C# backend to relaunch as administrator`);
     }
  }
};
