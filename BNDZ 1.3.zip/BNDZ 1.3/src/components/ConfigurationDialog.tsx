import React, { useState } from 'react';
import { useAppConfig } from '../data/configContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ColorPicker } from './color-picker';
import { Checkbox } from './ui/checkbox';

const SectionHeader = ({ title }: { title: string }) => (
  <h3 className="font-bold text-[13px] text-white mt-5 mb-2">{title}</h3>
);

const ActionBtn = ({ label, className = '', onClick }: any) => (
  <button className={`bg-[#2a2a2a] hover:bg-[#444] border border-[#555] rounded-sm text-[12px] px-4 py-1 text-white ${className}`} onClick={onClick}>
    {label}
  </button>
)

export default function ConfigurationDialog({ onClose }: { onClose: () => void }) {
  const { config, updateConfig } = useAppConfig();
  const [activeTab, setActiveTab] = useState("Shell Integration");

  const categories = [
    { name: "General", items: ["Tree and List", "Sort and Rename", "Refresh, Icons, History", "Menus, Mouse, Usability", "Custom Event Actions", "Safety Belts, Network", "Controls & More", "Startup & Exit"] },
    { name: "Colors and Styles", items: ["Colors", "Highlights & Dark Mode", "Styles", "Color Filters", "Fonts", "Templates"] },
    { name: "Information", items: ["Tags", "Custom Columns", "File Info Tips & Hover Box", "Report & Data"] },
    { name: "File Operations", items: ["File Operations", "Undo & Action Log"] },
    { name: "Find and Filter", items: ["Find Files & Branch View", "Filters & Type Ahead Find"] },
    { name: "Preview", items: ["Preview", "Previewed Formats", "Thumbnails", "Mouse Down Blow Up"] },
    { name: "Tabs and Panes", items: ["Tabs", "Dual Pane"] },
    { name: "Other", items: ["Shell Integration", "Features"] }
  ];

  return (
    <div className="w-[850px] h-[650px] bg-[#1e1e1e] border border-[#555] shadow-2xl flex flex-col font-sans select-none overflow-hidden rounded-t-lg ring-1 ring-black/50">
      
      {/* Title Bar */}
      <div className="bg-[#a475d4] px-3 py-[5px] flex items-center justify-between cursor-move rounded-t-lg">
         <div className="text-[12px] text-black flex items-center gap-2 font-medium">
            <span className="text-black font-bold text-[14px]">BNDZ</span>
            Configuration - BNDZ @ C:\Users\mikey\AppData\Roaming\BNDZ64\BNDZ.ini - 28.30.0600 (64-bit)
         </div>
         <div className="flex text-black gap-[1px] justify-center items-center h-full">
            <button className="hover:bg-white/20 px-3 py-[2px] rounded-sm flex items-center justify-center">
              <svg width="10" height="1" viewBox="0 0 10 1"><path fill="currentColor" d="M0 0h10v1H0z"/></svg>
            </button>
            <button className="hover:bg-white/20 px-3 py-[2px] rounded-sm flex items-center justify-center">
              <svg width="10" height="10" viewBox="0 0 10 10"><path fill="currentColor" fillRule="evenodd" d="M1 1h8v8H1V1zm1 1v6h6V2H2z" clipRule="evenodd"/></svg>
            </button>
            <button className="hover:bg-red-500 hover:text-white px-3 py-[2px] rounded-sm flex items-center justify-center transition-colors" onClick={onClose}>
              <svg width="10" height="10" viewBox="0 0 10 10"><path fill="currentColor" d="M.7.7l8.6 8.6-.7.7L0 1.4.7.7z"/><path fill="currentColor" d="M9.3.7L.7 9.3 0 8.6 8.6 0l.7.7z"/></svg>
            </button>
         </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex flex-1 overflow-hidden" orientation="vertical">
         {/* Sidebar Tabs */}
         <div className="w-[220px] bg-[#1a1a1a] border-r border-[#333] h-full overflow-y-auto block styled-scrollbar py-2 shrink-0">
            <TabsList className="flex flex-col justify-start items-stretch p-0 bg-transparent h-auto w-full rounded-none">
               {categories.map((cat, i) => (
                 <div key={i}>
                    <div className="px-2 py-[2px] text-white text-[13px] font-bold mt-1 tracking-tight">{cat.name}</div>
                    {cat.items.map((item, j) => (
                       <TabsTrigger 
                         key={j} 
                         value={item} 
                         className="w-full justify-start text-left px-2 py-[2px] pl-[18px] text-[13px] font-normal rounded-none border-0 data-[state=active]:bg-[#444444] data-[state=active]:text-white text-[#d4d4d4] hover:bg-[#2a2d2e] data-[state=active]:hover:bg-[#444444] shadow-none"
                       >
                         {item}
                       </TabsTrigger>
                    ))}
                 </div>
               ))}
            </TabsList>
         </div>

         {/* Content Area */}
         <div className="flex-1 bg-[#1e1e1e] p-[16px] pl-[20px] overflow-y-auto styled-scrollbar">
            
            <TabsContent value="Tree and List" className="m-0 border-0 p-0 outline-none">
              <h1 className="text-[20px] font-bold text-white mb-6 leading-tight">Tree and List</h1>
              
              <SectionHeader title="Tree" />
              <div className="ml-2 mb-4 space-y-[6px]">
                 <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">A</span>uto-optimize tree</span>} checked={config.autoOptimizeTree ?? false} onChange={e => updateConfig({ autoOptimizeTree: e.target.checked })} />
                 <Checkbox label={<span>Expand tree nodes on <span className="underline decoration-1 underline-offset-[3px]">b</span>rowse</span>} checked={config.expandTreeNodesOnBrowse ?? false} onChange={e => updateConfig({ expandTreeNodesOnBrowse: e.target.checked })} />
                 <Checkbox label={<span>Expand tree nodes on <span className="underline decoration-1 underline-offset-[3px]">d</span>rag-over</span>} checked={config.expandTreeNodesOnDragOver ?? false} onChange={e => updateConfig({ expandTreeNodesOnDragOver: e.target.checked })} />
                 <Checkbox label={<span>Expand tree nodes on <span className="underline decoration-1 underline-offset-[3px]">s</span>ingle-click</span>} checked={config.expandTreeNodesOnSingleClick ?? false} onChange={e => updateConfig({ expandTreeNodesOnSingleClick: e.target.checked })} />
                 <Checkbox label={<span>Chec<span className="underline decoration-1 underline-offset-[3px]">k</span> existence of subfolders in tree</span>} checked={config.checkExistenceOfSubfoldersInTree ?? false} onChange={e => updateConfig({ checkExistenceOfSubfoldersInTree: e.target.checked })} />
                 <div className="ml-[20px]">
                    <Checkbox label={<span>In network locations as <span className="underline decoration-1 underline-offset-[3px]">w</span>ell</span>} checked={config.inNetworkLocationsAsWell ?? false} onChange={e => updateConfig({ inNetworkLocationsAsWell: e.target.checked })} disabled={!config.checkExistenceOfSubfoldersInTree} />
                 </div>
                 <Checkbox label={<span>Remembe<span className="underline decoration-1 underline-offset-[3px]">r</span> state of tree</span>} checked={config.rememberStateOfTree ?? false} onChange={e => updateConfig({ rememberStateOfTree: e.target.checked })} />
                 <Checkbox label={<span>S<span className="underline decoration-1 underline-offset-[3px]">h</span>ow localized folder names</span>} checked={config.showLocalizedFolderNames ?? false} onChange={e => updateConfig({ showLocalizedFolderNames: e.target.checked })} />
                 <Checkbox label={<span>Select parent of mo<span className="underline decoration-1 underline-offset-[3px]">v</span>ed folder</span>} checked={config.selectParentOfMovedFolder ?? false} onChange={e => updateConfig({ selectParentOfMovedFolder: e.target.checked })} />
                 <Checkbox label={<span>Select parent of <span className="underline decoration-1 underline-offset-[3px]">d</span>eleted folder</span>} checked={config.selectParentOfDeletedFolder ?? false} onChange={e => updateConfig({ selectParentOfDeletedFolder: e.target.checked })} />
                 <Checkbox label={<span>Scroll selected folder to <span className="underline decoration-1 underline-offset-[3px]">t</span>he top</span>} checked={config.scrollSelectedFolderToTheTop ?? false} onChange={e => updateConfig({ scrollSelectedFolderToTheTop: e.target.checked })} />
                 <Checkbox label={<span>Scroll subf<span className="underline decoration-1 underline-offset-[3px]">o</span>lders into view</span>} checked={config.scrollSubfoldersIntoView ?? false} onChange={e => updateConfig({ scrollSubfoldersIntoView: e.target.checked })} />
              </div>

              <SectionHeader title="List" />
              <div className="ml-2 mb-4 space-y-[6px]">
                 <Checkbox label={<span>A<span className="underline decoration-1 underline-offset-[3px]">u</span>to-select first item</span>} checked={config.autoSelectFirstItem ?? false} onChange={e => updateConfig({ autoSelectFirstItem: e.target.checked })} />
                 <Checkbox label={<span>Select <span className="underline decoration-1 underline-offset-[3px]">l</span>ast used subfolder</span>} checked={config.selectLastUsedSubfolder ?? false} onChange={e => updateConfig({ selectLastUsedSubfolder: e.target.checked })} />
                 <Checkbox label={<span>Select n<span className="underline decoration-1 underline-offset-[3px]">e</span>xt item after delete and move</span>} checked={config.selectNextItemAfterDeleteAndMove ?? false} onChange={e => updateConfig({ selectNextItemAfterDeleteAndMove: e.target.checked })} />
                 <Checkbox label={<span>Add <span className="underline decoration-1 underline-offset-[3px]">n</span>ew items at the end of the list</span>} checked={config.addNewItemsAtTheEndOfTheList ?? false} onChange={e => updateConfig({ addNewItemsAtTheEndOfTheList: e.target.checked })} />
                 <Checkbox label={<span>A<span className="underline decoration-1 underline-offset-[3px]">l</span>ways show folder sizes</span>} checked={config.alwaysShowFolderSizes ?? false} onChange={e => updateConfig({ alwaysShowFolderSizes: e.target.checked })} />
                 <div className="ml-[20px]">
                    <Checkbox label={<span>In network locations as <span className="underline decoration-1 underline-offset-[3px]">w</span>ell</span>} checked={config.inNetworkLocationsAsWell ?? false} onChange={e => updateConfig({ inNetworkLocationsAsWell: e.target.checked })} disabled={!config.alwaysShowFolderSizes} />
                 </div>
                 <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">C</span>ache folder sizes</span>} checked={config.cacheFolderSizes ?? false} onChange={e => updateConfig({ cacheFolderSizes: e.target.checked })} />
                 <div className="ml-[20px]">
                    <Checkbox label={<span>Show cac<span className="underline decoration-1 underline-offset-[3px]">h</span>ed folder sizes only</span>} checked={config.showCachedFolderSizesOnly ?? false} onChange={e => updateConfig({ showCachedFolderSizesOnly: e.target.checked })} disabled={!config.cacheFolderSizes} />
                 </div>
                 <Checkbox label={<span>Show <span className="underline decoration-1 underline-offset-[3px]">i</span>tem count with folder sizes</span>} checked={config.showItemCountWithFolderSizes ?? false} onChange={e => updateConfig({ showItemCountWithFolderSizes: e.target.checked })} />
                 <Checkbox label={<span>Show <span className="underline decoration-1 underline-offset-[3px]">f</span>older size on Properties tab</span>} checked={config.showFolderSizeOnPropertiesTab ?? false} onChange={e => updateConfig({ showFolderSizeOnPropertiesTab: e.target.checked })} />
                 <Checkbox label={<span>W<span className="underline decoration-1 underline-offset-[3px]">r</span>ap-around list</span>} checked={config.wrapAroundList ?? false} onChange={e => updateConfig({ wrapAroundList: e.target.checked })} />
              </div>

              <SectionHeader title="Items in Tree and List" />
              <div className="ml-2 mb-4">
                 <ActionBtn label={<span>Select Item<span className="underline decoration-1 underline-offset-[3px]">s</span>...</span>} className="px-6 py-[2px] bg-[#1a1a1a]" />
              </div>
            </TabsContent>

            <TabsContent value="Sort and Rename" className="m-0 border-0 p-0 outline-none">
              <h1 className="text-[20px] font-bold text-white mb-6 leading-tight">Sort and Rename</h1>
              
              <SectionHeader title="Sort" />
              <div className="flex items-center gap-[42px] ml-2 mb-4 mt-[10px]">
                 <span className="text-[12px] text-[#e0e0e0]">Sort <span className="underline decoration-1 underline-offset-[3px]">m</span>ethod:</span>
                 <select className="bg-[#1e1e1e] border border-[#666] text-[#e0e0e0] text-[12px] px-2 py-[2px] rounded-sm w-[200px] outline-none" value={config.sortMethod} onChange={(e) => updateConfig({sortMethod: e.target.value})}>
                    <option>Natural</option>
                 </select>
              </div>

              <div className="ml-2 mb-4 space-y-[6px]">
                 <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">S</span>ort folders apart</span>} checked={config.sortFoldersApart ?? false} onChange={e => updateConfig({ sortFoldersApart: e.target.checked })} />
                 <div className="ml-[20px] space-y-[6px]">
                    <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">K</span>eep folders on top</span>} checked={config.keepFoldersOnTop ?? false} onChange={e => updateConfig({ keepFoldersOnTop: e.target.checked })} disabled={!config.sortFoldersApart} />
                    <Checkbox label={<span>Sort folders always a<span className="underline decoration-1 underline-offset-[3px]">s</span>cending</span>} checked={config.sortFoldersAlwaysAscending ?? false} onChange={e => updateConfig({ sortFoldersAlwaysAscending: e.target.checked })} disabled={!config.sortFoldersApart} />
                    <Checkbox label={<span>Mixed sort on <span className="underline decoration-1 underline-offset-[3px]">d</span>ate columns</span>} checked={config.mixedSortOnDateColumns ?? false} onChange={e => updateConfig({ mixedSortOnDateColumns: e.target.checked })} disabled={!config.sortFoldersApart} />
                    <Checkbox label={<span>Mixed sort on <span className="underline decoration-1 underline-offset-[3px]">t</span>ag columns</span>} checked={config.mixedSortOnTagColumns ?? false} onChange={e => updateConfig({ mixedSortOnTagColumns: e.target.checked })} disabled={!config.sortFoldersApart} />
                    <Checkbox label={<span>Mixed sort on <span className="underline decoration-1 underline-offset-[3px]">p</span>ath columns</span>} checked={config.mixedSortOnPathColumns ?? false} onChange={e => updateConfig({ mixedSortOnPathColumns: e.target.checked })} disabled={!config.sortFoldersApart} />
                 </div>
                 
                 <div className="h-2"></div>
                 <Checkbox label={<span>Sort filenames by <span className="underline decoration-1 underline-offset-[3px]">b</span>ase</span>} checked={config.sortFilenamesByBase ?? false} onChange={e => updateConfig({ sortFilenamesByBase: e.target.checked })} />
                 <Checkbox label={<span>Treat <span className="underline decoration-1 underline-offset-[3px]">h</span>yphens and apostrophes like normal characters</span>} checked={config.treatHyphensAndApostrophesLikeNormalCharacters ?? false} onChange={e => updateConfig({ treatHyphensAndApostrophesLikeNormalCharacters: e.target.checked })} />
                 <Checkbox label={<span>Sort s<span className="underline decoration-1 underline-offset-[3px]">i</span>ze columns descending by default</span>} checked={config.sortSizeColumnsDescendingByDefault ?? false} onChange={e => updateConfig({ sortSizeColumnsDescendingByDefault: e.target.checked })} />
                 <Checkbox label={<span>Sort <span className="underline decoration-1 underline-offset-[3px]">d</span>ate columns descending by default</span>} checked={config.sortDateColumnsDescendingByDefault ?? false} onChange={e => updateConfig({ sortDateColumnsDescendingByDefault: e.target.checked })} />
                 
                 <div className="h-2"></div>
                 <Checkbox label={<span>Keep current <span className="underline decoration-1 underline-offset-[3px]">i</span>tem in view after resorting</span>} checked={config.keepCurrentItemInViewAfterResorting ?? false} onChange={e => updateConfig({ keepCurrentItemInViewAfterResorting: e.target.checked })} />
                 <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">S</span>croll to top after resorting</span>} checked={config.scrollToTopAfterResorting ?? false} onChange={e => updateConfig({ scrollToTopAfterResorting: e.target.checked })} />
                 <Checkbox label={<span>Show sort <span className="underline decoration-1 underline-offset-[3px]">h</span>eaders in all views</span>} checked={config.showSortHeadersInAllViews ?? false} onChange={e => updateConfig({ showSortHeadersInAllViews: e.target.checked })} />
                 <Checkbox label={<span>Show implicit secondary sort order arrow</span>} checked={config.showImplicitSecondarySortOrderArrow ?? false} onChange={e => updateConfig({ showImplicitSecondarySortOrderArrow: e.target.checked })} />
              </div>

              <SectionHeader title="Rename" />
              <div className="ml-2 mb-4 space-y-[6px]">
                  <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">P</span>reselect name</span>} checked={config.preselectName ?? false} onChange={e => updateConfig({ preselectName: e.target.checked })} />
                  <Checkbox label={<span>Exclude file <span className="underline decoration-1 underline-offset-[3px]">e</span>xtension from initial selection</span>} checked={config.excludeFileExtensionFromInitialSelection ?? false} onChange={e => updateConfig({ excludeFileExtensionFromInitialSelection: e.target.checked })} />
                  <Checkbox label={<span>Hide extensions from rename edit bo<span className="underline decoration-1 underline-offset-[3px]">x</span></span>} checked={config.hideExtensionsFromRenameEditBox ?? false} onChange={e => updateConfig({ hideExtensionsFromRenameEditBox: e.target.checked })} />
                  <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">S</span>erial rename with Up and Down keys</span>} checked={config.serialRenameWithUpAndDownKeys ?? false} onChange={e => updateConfig({ serialRenameWithUpAndDownKeys: e.target.checked })} />
                  <Checkbox label={<span>Show name <span className="underline decoration-1 underline-offset-[3px]">l</span>ength while renaming</span>} checked={config.showNameLengthWhileRenaming ?? false} onChange={e => updateConfig({ showNameLengthWhileRenaming: e.target.checked })} />
                  <Checkbox label={<span>Use dialog to re<span className="underline decoration-1 underline-offset-[3px]">n</span>ame single items</span>} checked={config.useDialogToRenameSingleItems ?? false} onChange={e => updateConfig({ useDialogToRenameSingleItems: e.target.checked })} />
                  
                  <div className="h-2"></div>
                  <Checkbox label={<span>Allow <span className="underline decoration-1 underline-offset-[3px]">m</span>ove on rename</span>} checked={config.allowMoveOnRename ?? false} onChange={e => updateConfig({ allowMoveOnRename: e.target.checked })} />
                  <Checkbox label={<span>Pre<span className="underline decoration-1 underline-offset-[3px]">v</span>iew all Rename Special operations</span>} checked={config.previewAllRenameSpecialOperations ?? false} onChange={e => updateConfig({ previewAllRenameSpecialOperations: e.target.checked })} />
                  
                  <div className="h-2"></div>
                  <Checkbox label={<span>A<span className="underline decoration-1 underline-offset-[3px]">u</span>to-replace invalid characters</span>} checked={config.autoReplaceInvalidCharacters ?? false} onChange={e => updateConfig({ autoReplaceInvalidCharacters: e.target.checked })} />
                  <Checkbox label={<span>Resort list immediately after rename</span>} checked={config.resortListImmediatelyAfterRename ?? false} onChange={e => updateConfig({ resortListImmediatelyAfterRename: e.target.checked })} />
                  <Checkbox label={<span>Set archive attribute on <span className="underline decoration-1 underline-offset-[3px]">f</span>older rename</span>} checked={config.setArchiveAttributeOnFolderRename ?? false} onChange={e => updateConfig({ setArchiveAttributeOnFolderRename: e.target.checked })} />
              </div>
            </TabsContent>

            <TabsContent value="Refresh, Icons, History" className="m-0 border-0 p-0 outline-none">
              <h1 className="text-[20px] font-bold text-white mb-6 leading-tight">Refresh, Icons, History</h1>
              
              <SectionHeader title="Auto-Refresh" />
              <div className="ml-2 mb-4 space-y-[6px]">
                 <Checkbox label={<span>Auto-<span className="underline decoration-1 underline-offset-[3px]">r</span>efresh</span>} checked={config.autoRefresh ?? false} onChange={e => updateConfig({ autoRefresh: e.target.checked })} />
                 <div className="ml-[20px] space-y-[6px]">
                    <Checkbox label={<span>Include removable <span className="underline decoration-1 underline-offset-[3px]">d</span>rives</span>} checked={config.includeRemovableDrives ?? false} onChange={e => updateConfig({ includeRemovableDrives: e.target.checked })} disabled={!config.autoRefresh} />
                    <Checkbox label={<span>Include <span className="underline decoration-1 underline-offset-[3px]">v</span>irtual folders</span>} checked={config.includeVirtualFolders ?? false} onChange={e => updateConfig({ includeVirtualFolders: e.target.checked })} disabled={!config.autoRefresh} />
                    <Checkbox label={<span>Include network <span className="underline decoration-1 underline-offset-[3px]">l</span>ocations</span>} checked={config.includeNetworkLocations ?? false} onChange={e => updateConfig({ includeNetworkLocations: e.target.checked })} disabled={!config.autoRefresh} />
                    <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">R</span>efresh during file operations</span>} checked={config.refreshDuringFileOperations ?? false} onChange={e => updateConfig({ refreshDuringFileOperations: e.target.checked })} disabled={!config.autoRefresh} />
                    <Checkbox label={<span>Respond to file system <span className="underline decoration-1 underline-offset-[3px]">n</span>otifications</span>} checked={config.respondToFileSystemNotifications ?? false} onChange={e => updateConfig({ respondToFileSystemNotifications: e.target.checked })} disabled={!config.autoRefresh} />
                    <div className="ml-[20px]">
                       <Checkbox label={<span>Detect portable devices</span>} checked={config.detectPortableDevices ?? false} onChange={e => updateConfig({ detectPortableDevices: e.target.checked })} disabled={!config.autoRefresh || !config.respondToFileSystemNotifications} />
                    </div>
                 </div>
              </div>

              <SectionHeader title="Icons" />
              <div className="ml-2 mb-4 space-y-[6px]">
                 <Checkbox label={<span>Draw selected list icons <span className="underline decoration-1 underline-offset-[3px]">d</span>immed</span>} checked={config.drawSelectedListIconsDimmed ?? false} onChange={e => updateConfig({ drawSelectedListIconsDimmed: e.target.checked })} />
                 <Checkbox label={<span>Draw hidden icons ghosted</span>} checked={config.drawHiddenIconsGhosted ?? false} onChange={e => updateConfig({ drawHiddenIconsGhosted: e.target.checked })} />
                 <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">C</span>ache specific icons</span>} checked={config.cacheSpecificIcons ?? false} onChange={e => updateConfig({ cacheSpecificIcons: e.target.checked })} />
                 
                 <Checkbox label={<span>Use generic icons for super-fast <span className="underline decoration-1 underline-offset-[3px]">b</span>rowsing</span>} checked={config.useGenericIconsForSuperFastBrowsing ?? false} onChange={e => updateConfig({ useGenericIconsForSuperFastBrowsing: e.target.checked })} />
                 <div className="ml-[20px] space-y-[6px]">
                    <Checkbox label={<span>But only in network <span className="underline decoration-1 underline-offset-[3px]">l</span>ocations</span>} checked={config.butOnlyInNetworkLocations ?? false} onChange={e => updateConfig({ butOnlyInNetworkLocations: e.target.checked })} disabled={!config.useGenericIconsForSuperFastBrowsing} />
                    <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">A</span>pply to all controls</span>} checked={config.applyToAllControls ?? false} onChange={e => updateConfig({ applyToAllControls: e.target.checked })} disabled={!config.useGenericIconsForSuperFastBrowsing} />
                 </div>
                 
                 <Checkbox label={<span>Show <span className="underline decoration-1 underline-offset-[3px]">i</span>con overlays</span>} checked={config.showIconOverlays ?? false} onChange={e => updateConfig({ showIconOverlays: e.target.checked })} />
                 <div className="ml-[20px] space-y-[6px]">
                    <Checkbox label={<span>In <span className="underline decoration-1 underline-offset-[3px]">t</span>ree as well</span>} checked={config.inTreeAsWell ?? false} onChange={e => updateConfig({ inTreeAsWell: e.target.checked })} disabled={!config.showIconOverlays} />
                    <Checkbox label={<span>In networ<span className="underline decoration-1 underline-offset-[3px]">k</span> locations as well</span>} checked={config.inNetworkLocationsAsWell ?? false} onChange={e => updateConfig({ inNetworkLocationsAsWell: e.target.checked })} disabled={!config.showIconOverlays} />
                 </div>

                 <Checkbox label={<span>Show shortcu<span className="underline decoration-1 underline-offset-[3px]">t</span> overlays</span>} checked={config.showShortcutOverlays ?? false} onChange={e => updateConfig({ showShortcutOverlays: e.target.checked })} />
                 <Checkbox label={<span>Show <span className="underline decoration-1 underline-offset-[3px]">s</span>hared folder overlays</span>} checked={config.showSharedFolderOverlays ?? false} onChange={e => updateConfig({ showSharedFolderOverlays: e.target.checked })} />
                 <Checkbox label={<span>Show embedded icons on <span className="underline decoration-1 underline-offset-[3px]">P</span>roperties tab</span>} checked={config.showEmbeddedIconsOnPropertiesTab ?? false} onChange={e => updateConfig({ showEmbeddedIconsOnPropertiesTab: e.target.checked })} />
                 <Checkbox label={<span>Show c<span className="underline decoration-1 underline-offset-[3px]">u</span>stom file icons</span>} checked={config.showCustomFileIcons ?? false} onChange={e => updateConfig({ showCustomFileIcons: e.target.checked })} />
              </div>

              <SectionHeader title="History" />
              <div className="ml-2 mb-4 space-y-[6px]">
                 <Checkbox label={<span>History <span className="underline decoration-1 underline-offset-[3px]">w</span>ithout duplicates</span>} checked={config.historyWithoutDuplicates ?? false} onChange={e => updateConfig({ historyWithoutDuplicates: e.target.checked })} />
                 <Checkbox label={<span>History p<span className="underline decoration-1 underline-offset-[3px]">e</span>r tab</span>} checked={config.historyPerTab ?? false} onChange={e => updateConfig({ historyPerTab: e.target.checked })} />
                 <Checkbox label={<span>History retains selections</span>} checked={config.historyRetainsSelections ?? false} onChange={e => updateConfig({ historyRetainsSelections: e.target.checked })} />
                 <Checkbox label={<span>History retains sort <span className="underline decoration-1 underline-offset-[3px]">o</span>rder</span>} checked={config.historyRetainsSortOrder ?? false} onChange={e => updateConfig({ historyRetainsSortOrder: e.target.checked })} />
              </div>
              
              <SectionHeader title="Scripting" />
              <div className="ml-2 mb-4 space-y-[6px]">
                 <Checkbox label={<span>Remember permanent <span className="underline decoration-1 underline-offset-[3px]">v</span>ariables</span>} checked={config.rememberPermanentVariables ?? false} onChange={e => updateConfig({ rememberPermanentVariables: e.target.checked })} />
              </div>
            </TabsContent>

            <TabsContent value="Menus, Mouse, Usability" className="m-0 border-0 p-0 outline-none">
              <h1 className="text-[20px] font-bold text-white mb-6 leading-tight">Menus, Mouse, Usability</h1>
              
              <SectionHeader title="Context Menus" />
              <div className="ml-2 mb-4 space-y-[6px]">
                 <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">N</span>ative context menu</span>} checked={config.nativeContextMenu ?? false} onChange={e => updateConfig({ nativeContextMenu: e.target.checked })} />
                 <div className="ml-[20px]">
                    <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">H</span>old Ctrl to invert the above selection</span>} checked={config.holdCtrlToInvertTheAboveSelection ?? false} onChange={e => updateConfig({ holdCtrlToInvertTheAboveSelection: e.target.checked })} />
                 </div>
                 <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">C</span>ustom items in the context menu</span>} checked={config.customItemsInTheContextMenu ?? false} onChange={e => updateConfig({ customItemsInTheContextMenu: e.target.checked })} />
                 <div className="ml-[20px] flex gap-2 mt-4 mb-4">
                    <ActionBtn label="Folder Tree..." className="w-[150px]" />
                    <ActionBtn label="File List..." className="w-[150px]" />
                 </div>
                 
                 <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">H</span>ide shell extensions from shell context menu</span>} checked={config.hideShellExtensionsFromShellContextMenu ?? false} onChange={e => updateConfig({ hideShellExtensionsFromShellContextMenu: e.target.checked })} />
                 <Checkbox label={<span>Native drag and drop context me<span className="underline decoration-1 underline-offset-[3px]">n</span>u</span>} checked={config.nativeDragAndDropContextMenu ?? false} onChange={e => updateConfig({ nativeDragAndDropContextMenu: e.target.checked })} />
                 <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">N</span>avigation commands in List context menu</span>} checked={config.navigationCommandsInListContextMenu ?? false} onChange={e => updateConfig({ navigationCommandsInListContextMenu: e.target.checked })} />
                 <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">F</span>ind Files commands in List context menu</span>} checked={config.findFilesCommandsInListContextMenu ?? false} onChange={e => updateConfig({ findFilesCommandsInListContextMenu: e.target.checked })} />
              </div>
              
              <SectionHeader title="Cell Context Menu" />
              <div className="ml-2 mb-4 space-y-[6px]">
                 <Checkbox label={<span>Hold Ctrl to show c<span className="underline decoration-1 underline-offset-[3px]">e</span>ll context menu</span>} checked={config.holdCtrlToShowCellContextMenu ?? false} onChange={e => updateConfig({ holdCtrlToShowCellContextMenu: e.target.checked })} />
                 <Checkbox label={<span>Use localized search and filter patterns</span>} checked={config.useLocalizedSearchAndFilterPatterns ?? false} onChange={e => updateConfig({ useLocalizedSearchAndFilterPatterns: e.target.checked })} />
              </div>

              <SectionHeader title="Mouse" />
              <div className="ml-2 mb-4 space-y-[6px]">
                 <Checkbox label={<span>Single-clic<span className="underline decoration-1 underline-offset-[3px]">k</span> to open an item</span>} checked={config.singleClickToOpenAnItem ?? false} onChange={e => updateConfig({ singleClickToOpenAnItem: e.target.checked })} />
                 <div className="ml-[20px] space-y-[6px]">
                    <Checkbox label={<span>On the <span className="underline decoration-1 underline-offset-[3px]">i</span>con only</span>} checked={config.onTheIconOnly ?? false} onChange={e => updateConfig({ onTheIconOnly: e.target.checked })} disabled={!config.singleClickToOpenAnItem} />
                    <Checkbox label={<span>Folder<span className="underline decoration-1 underline-offset-[3px]">s</span> only</span>} checked={config.foldersOnly ?? false} onChange={e => updateConfig({ foldersOnly: e.target.checked })} disabled={!config.singleClickToOpenAnItem} />
                 </div>
                 
                 <Checkbox label={<span>Po<span className="underline decoration-1 underline-offset-[3px]">i</span>nt to select</span>} checked={config.pointToSelect ?? false} onChange={e => updateConfig({ pointToSelect: e.target.checked })} />
                 <div className="ml-[20px]">
                    <Checkbox label={<span>To the i<span className="underline decoration-1 underline-offset-[3px]">c</span>on only</span>} checked={config.toTheIconOnly ?? false} onChange={e => updateConfig({ toTheIconOnly: e.target.checked })} disabled={!config.pointToSelect} />
                 </div>
                 
                 <Checkbox label={<span>Full <span className="underline decoration-1 underline-offset-[3px]">n</span>ame column select</span>} checked={config.fullNameColumnSelect ?? false} onChange={e => updateConfig({ fullNameColumnSelect: e.target.checked })} />
                 <Checkbox label={<span>Allow dragging from a <span className="underline decoration-1 underline-offset-[3px]">b</span>ackground window</span>} checked={config.allowDraggingFromABackgroundWindow ?? false} onChange={e => updateConfig({ allowDraggingFromABackgroundWindow: e.target.checked })} />
                 <Checkbox label={<span>Shift+<span className="underline decoration-1 underline-offset-[3px]">W</span>heel scrolls horizontally</span>} checked={config.shiftWheelScrollsHorizontally ?? false} onChange={e => updateConfig({ shiftWheelScrollsHorizontally: e.target.checked })} />
                 <Checkbox label={<span>Ctrl+<span className="underline decoration-1 underline-offset-[3px]">W</span>heel scrolls through the list views</span>} checked={config.ctrlWheelScrollsThroughTheListViews ?? false} onChange={e => updateConfig({ ctrlWheelScrollsThroughTheListViews: e.target.checked })} />
              </div>

              <SectionHeader title="Usability" />
              <div className="ml-2 mb-4 space-y-[6px]">
                 <Checkbox label={<span>Highlight ho<span className="underline decoration-1 underline-offset-[3px]">v</span>ered items</span>} checked={config.highlightHoveredItems ?? false} onChange={e => updateConfig({ highlightHoveredItems: e.target.checked })} />
                 <Checkbox label={<span>Show tooltip<span className="underline decoration-1 underline-offset-[3px]">s</span></span>} checked={config.showTooltips ?? false} onChange={e => updateConfig({ showTooltips: e.target.checked })} />
                 <div className="ml-[20px] mb-[10px]">
                    <Checkbox label={<span>Show verbati<span className="underline decoration-1 underline-offset-[3px]">m</span> tooltips</span>} checked={config.showVerbatimTooltips ?? false} onChange={e => updateConfig({ showVerbatimTooltips: e.target.checked })} disabled={!config.showTooltips} />
                 </div>
                 
                 <div className="flex flex-col gap-2 pt-2">
                    <div className="flex items-center gap-2">
                       <input type="number" 
                          value={config.tooltipZoom} 
                          onChange={(e) => updateConfig({tooltipZoom: parseInt(e.target.value) || 100})} 
                          className="w-[60px] h-6 bg-transparent border border-[#555] text-white text-[12px] px-1 text-right outline-none"
                       />
                       <span className="text-[12px] text-[#e0e0e0]">Tooltip <span className="underline decoration-1 underline-offset-[3px]">z</span>oom (%)</span>
                    </div>
                    <div className="flex items-center gap-2">
                       <input type="number" 
                          value={config.scrollMargin} 
                          onChange={(e) => updateConfig({scrollMargin: parseInt(e.target.value) || 0})} 
                          className="w-[60px] h-6 bg-transparent border border-[#555] text-white text-[12px] px-1 text-right outline-none"
                       />
                       <span className="text-[12px] text-[#e0e0e0]"><span className="underline decoration-1 underline-offset-[3px]">S</span>croll margin</span>
                    </div>
                    <div className="flex items-center gap-2">
                       <input type="text" 
                          value={config.wheelScrollLines === 0 ? '' : config.wheelScrollLines} 
                          onChange={(e) => updateConfig({wheelScrollLines: parseInt(e.target.value) || 0})} 
                          className="w-[60px] h-6 bg-transparent border border-[#555] text-white text-[12px] px-1 text-right outline-none placeholder-[#666]"
                       />
                       <span className="text-[12px] text-[#e0e0e0]">Wheel scroll lines</span>
                    </div>
                 </div>
              </div>
            </TabsContent>

            <TabsContent value="Custom Event Actions" className="m-0 border-0 p-0 outline-none">
              <h1 className="text-[20px] font-bold text-white mb-6 leading-tight">Custom Event Actions</h1>
              <p className="text-[12px] text-[#e0e0e0] mb-[12px] mt-1 ml-[2px]">To edit actions and scripts click into the cells.</p>
              
              <div className="border border-[#444] rounded-sm overflow-hidden mb-6 h-[460px] bg-[#111]">
                 {/* Table Header */}
                 <div className="flex bg-[#2a2a2a] text-[#ddd] text-[12px] py-1 border-b border-[#444] border-t border-[#444] pr-[14px]">
                    <div className="flex-[3] pl-2">Event</div>
                    <div className="flex-[2] pl-2 border-l border-[#444]">Action</div>
                    <div className="flex-[2] pl-2 border-l border-[#444]">Script</div>
                 </div>
                 
                 {/* Table Body - Placeholder Data Matching Screenshot */}
                 <div className="overflow-y-auto h-full text-[12px] styled-scrollbar">
                    <div className="bg-[#1e1e1e] text-white font-bold px-2 py-1">Clicking on White</div>
                    {[
                       { event: "Double-click on white in folder tree", action: "Go up" },
                       { event: "Double-click on white in file list", action: "Go up" },
                       { event: "Double-click on white in tab bar", action: "New tab" },
                       { event: "Double-click on white in breadcrumb bar", action: "None" },
                       { event: "Middle-click on white in folder tree", action: "None" },
                       { event: "Middle-click on white in file list", action: "None" },
                       { event: "Middle-click on white in tab bar", action: "None" },
                       { event: "Middle-click on white in breadcrumb bar", action: "None" },
                       { event: "Right-click on white in folder tree", action: "Pop up favorite folders" },
                       { event: "Right-click on white in file list", action: "Pop up Edit menu" },
                    ].map((row, i) => (
                       <div key={i} className="flex hover:bg-[#264f78] text-[#ccc]">
                          <div className="flex-[3] pl-6 py-0.5 whitespace-nowrap">{row.event}</div>
                          <div className="flex-[2] pl-2 py-0.5 border-l border-[#222] whitespace-nowrap">{row.action}</div>
                          <div className="flex-[2] pl-2 py-0.5 border-l border-[#222] whitespace-nowrap"></div>
                       </div>
                    ))}
                    
                    <div className="bg-[#1e1e1e] text-white font-bold px-2 py-1 mt-1">Clicking on Line Numbers</div>
                    {[
                       { event: "Double-click on line number", action: "None" },
                       { event: "Left-click on line number", action: "None" },
                       { event: "Middle-click on line number", action: "None" },
                       { event: "Right-click on line number", action: "None" },
                       { event: "Double-click on line numbers header", action: "Autosize columns now" },
                    ].map((row, i) => (
                       <div key={i} className="flex hover:bg-[#264f78] text-[#ccc]">
                          <div className="flex-[3] pl-6 py-0.5 whitespace-nowrap">{row.event}</div>
                          <div className="flex-[2] pl-2 py-0.5 border-l border-[#222] whitespace-nowrap">{row.action}</div>
                          <div className="flex-[2] pl-2 py-0.5 border-l border-[#222] whitespace-nowrap"></div>
                       </div>
                    ))}
                    
                    <div className="bg-[#1e1e1e] text-white font-bold px-2 py-1 mt-1">Clicking on Tabs</div>
                    {[
                       { event: "Double-click on tab", action: "None" },
                       { event: "Middle-click on tab", action: "Close tab" },
                       { event: "Right-click on tab", action: "Small menu" },
                    ].map((row, i) => (
                       <div key={i} className="flex hover:bg-[#264f78] text-[#ccc]">
                          <div className="flex-[3] pl-6 py-0.5 whitespace-nowrap">{row.event}</div>
                          <div className="flex-[2] pl-2 py-0.5 border-l border-[#222] whitespace-nowrap">{row.action}</div>
                          <div className="flex-[2] pl-2 py-0.5 border-l border-[#222] whitespace-nowrap"></div>
                       </div>
                    ))}
                    
                    <div className="bg-[#1e1e1e] text-white font-bold px-2 py-1 mt-1">Clicking on Status Bar</div>
                    {[
                       { event: "Double-click on status bar", action: "None" },
                       { event: "Left-click on status bar", action: "None" },
                       { event: "Middle-click on status bar", action: "None" },
                    ].map((row, i) => (
                       <div key={i} className="flex hover:bg-[#264f78] text-[#ccc]">
                          <div className="flex-[3] pl-6 py-0.5 whitespace-nowrap">{row.event}</div>
                          <div className="flex-[2] pl-2 py-0.5 border-l border-[#222] whitespace-nowrap">{row.action}</div>
                          <div className="flex-[2] pl-2 py-0.5 border-l border-[#222] whitespace-nowrap"></div>
                       </div>
                    ))}
                    
                    <div className="bg-[#1e1e1e] text-white font-bold px-2 py-1 mt-1">Clicking on Items</div>
                    {[
                       { event: "Middle-click on folder", action: "Open in new background tab" },
                    ].map((row, i) => (
                       <div key={i} className="flex hover:bg-[#264f78] text-[#ccc]">
                          <div className="flex-[3] pl-6 py-0.5 whitespace-nowrap">{row.event}</div>
                          <div className="flex-[2] pl-2 py-0.5 border-l border-[#222] whitespace-nowrap">{row.action}</div>
                          <div className="flex-[2] pl-2 py-0.5 border-l border-[#222] whitespace-nowrap"></div>
                       </div>
                    ))}
                 </div>
              </div>
            </TabsContent>

            <TabsContent value="Safety Belts, Network" className="m-0 border-0 p-0 outline-none">
              <h1 className="text-[20px] font-bold text-white mb-6 leading-tight">Safety Belts, Network</h1>
              
              <SectionHeader title="Safety Belts" />
              <div className="ml-2 mb-4 space-y-[6px]">
                  <Checkbox label={<span>Show <span className="underline decoration-1 underline-offset-[3px]">d</span>rag status box</span>} checked={config.showDragStatusBox ?? false} onChange={e => updateConfig({ showDragStatusBox: e.target.checked })} />
                  <Checkbox label={<span>Disallow left-dragging from folder tree</span>} checked={config.disallowLeftDraggingFromFolderTree ?? false} onChange={e => updateConfig({ disallowLeftDraggingFromFolderTree: e.target.checked })} />
                  <Checkbox label={<span>Disallo<span className="underline decoration-1 underline-offset-[3px]">w</span> left-dragging from file list</span>} checked={config.disallowLeftDraggingFromFileList ?? false} onChange={e => updateConfig({ disallowLeftDraggingFromFileList: e.target.checked })} />
                  
                  <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">C</span>onfirm drag and drop</span>} checked={config.confirmDragAndDrop ?? false} onChange={e => updateConfig({ confirmDragAndDrop: e.target.checked })} />
                  <Checkbox label={<span>C<span className="underline decoration-1 underline-offset-[3px]">o</span>nfirm copy and move operations</span>} checked={config.confirmCopyAndMoveOperations ?? false} onChange={e => updateConfig({ confirmCopyAndMoveOperations: e.target.checked })} />
                  <Checkbox label={<span>Confirm <span className="underline decoration-1 underline-offset-[3px]">d</span>elete operations</span>} checked={config.confirmDeleteOperations ?? false} onChange={e => updateConfig({ confirmDeleteOperations: e.target.checked })} />
                  <Checkbox label={<span>Delete on key <span className="underline decoration-1 underline-offset-[3px]">u</span>p</span>} checked={config.deleteOnKeyUp ?? false} onChange={e => updateConfig({ deleteOnKeyUp: e.target.checked })} />
                  <Checkbox label={<span>Disallow delete by <span className="underline decoration-1 underline-offset-[3px]">k</span>ey in folder tree</span>} checked={config.disallowDeleteByKeyInFolderTree ?? false} onChange={e => updateConfig({ disallowDeleteByKeyInFolderTree: e.target.checked })} />
                  <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">T</span>reat portable devices as read-only</span>} checked={config.treatPortableDevicesAsReadOnly ?? false} onChange={e => updateConfig({ treatPortableDevicesAsReadOnly: e.target.checked })} />
                  <Checkbox label={<span>Directional formatting codes protection</span>} checked={config.directionalFormattingCodesProtection ?? false} onChange={e => updateConfig({ directionalFormattingCodesProtection: e.target.checked })} />
              </div>
              
              <SectionHeader title="Network" />
              <div className="ml-2 mb-4 space-y-[6px]">
                  <Checkbox label={<span>Assume that se<span className="underline decoration-1 underline-offset-[3px]">r</span>vers are available</span>} checked={config.assumeThatServersAreAvailable ?? false} onChange={e => updateConfig({ assumeThatServersAreAvailable: e.target.checked })} />
                  <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">C</span>ache network servers</span>} checked={config.cacheNetworkServers ?? false} onChange={e => updateConfig({ cacheNetworkServers: e.target.checked })} />
                  <Checkbox label={<span>Assume that <span className="underline decoration-1 underline-offset-[3px]">m</span>apped network drives are available</span>} checked={config.assumeThatMappedNetworkDrivesAreAvailable ?? false} onChange={e => updateConfig({ assumeThatMappedNetworkDrivesAreAvailable: e.target.checked })} />
                  <Checkbox label={<span>Skip calculation of free disk space for mapped <span className="underline decoration-1 underline-offset-[3px]">n</span>etwork drives</span>} checked={config.skipCalculationOfFreeDiskSpaceForMappedNetworkDriv ?? false} onChange={e => updateConfig({ skipCalculationOfFreeDiskSpaceForMappedNetworkDriv: e.target.checked })} />
              </div>
            </TabsContent>

            <TabsContent value="Controls & More" className="m-0 border-0 p-0 outline-none">
              <h1 className="text-[20px] font-bold text-white mb-6 leading-tight">Controls & More</h1>
              
              <SectionHeader title="Drop-Down Lists" />
              <div className="ml-2 mb-4 space-y-[6px]">
                  <Checkbox label={<span>A<span className="underline decoration-1 underline-offset-[3px]">u</span>to-complete recently used items</span>} checked={config.autoCompleteRecentlyUsedItems ?? false} onChange={e => updateConfig({ autoCompleteRecentlyUsedItems: e.target.checked })} />
                  <Checkbox label={<span>Move last <span className="underline decoration-1 underline-offset-[3px]">u</span>sed item to top</span>} checked={config.moveLastUsedItemToTop ?? false} onChange={e => updateConfig({ moveLastUsedItemToTop: e.target.checked })} />
                  <Checkbox label={<span>Select list items on mouse h<span className="underline decoration-1 underline-offset-[3px]">o</span>ver</span>} checked={config.selectListItemsOnMouseHover ?? false} onChange={e => updateConfig({ selectListItemsOnMouseHover: e.target.checked })} />
                  <Checkbox label={<span>Select all on focus by <span className="underline decoration-1 underline-offset-[3px]">k</span>ey</span>} checked={config.selectAllOnFocusByKey ?? false} onChange={e => updateConfig({ selectAllOnFocusByKey: e.target.checked })} />
                  <Checkbox label={<span>Select all on focu<span className="underline decoration-1 underline-offset-[3px]">s</span> by mouse</span>} checked={config.selectAllOnFocusByMouse ?? false} onChange={e => updateConfig({ selectAllOnFocusByMouse: e.target.checked })} />
                  <Checkbox label={<span>Select all on item change</span>} checked={config.selectAllOnItemChange ?? false} onChange={e => updateConfig({ selectAllOnItemChange: e.target.checked })} />
                  <Checkbox label={<span>Select matc<span className="underline decoration-1 underline-offset-[3px]">h</span> on drop down</span>} checked={config.selectMatchOnDropDown ?? false} onChange={e => updateConfig({ selectMatchOnDropDown: e.target.checked })} />
              </div>

              <SectionHeader title="Auto-Complete Path Names" />
              <div className="ml-2 mb-4 space-y-[6px] relative">
                  <div className="flex items-center gap-[42px] absolute right-4 top-2">
                     <span className="text-[12px] text-[#e0e0e0]"><span className="underline decoration-1 underline-offset-[3px]">F</span>ilter:</span>
                     <select className="bg-[#1e1e1e] border border-[#666] text-[#e0e0e0] text-[12px] px-2 py-[2px] rounded-sm w-[200px] outline-none" value={config.autoCompleteFilter} onChange={e => updateConfig({ autoCompleteFilter: e.target.value })}>
                        <option>Folders only</option>
                        <option>Files only</option>
                        <option>Files and folders</option>
                     </select>
                  </div>
                  <Checkbox label={<span>Address <span className="underline decoration-1 underline-offset-[3px]">B</span>ar</span>} checked={config.addressBar ?? false} onChange={e => updateConfig({ addressBar: e.target.checked })} />
                  <Checkbox label={<span>Find Files Loca<span className="underline decoration-1 underline-offset-[3px]">t</span>ion</span>} checked={config.findFilesLocation ?? false} onChange={e => updateConfig({ findFilesLocation: e.target.checked })} />
              </div>

              <SectionHeader title="Miscellaneous" />
              <div className="ml-2 mb-4 space-y-[6px]">
                  <Checkbox label={<span>Support overlong <span className="underline decoration-1 underline-offset-[3px]">f</span>ilenames</span>} checked={config.supportOverlongFilenames ?? false} onChange={e => updateConfig({ supportOverlongFilenames: e.target.checked })} />
                  <Checkbox label={<span>Convert overlong paths to 8.3 format when opening files</span>} checked={config.convertOverlongPathsTo83FormatWhenOpeningFiles ?? false} onChange={e => updateConfig({ convertOverlongPathsTo83FormatWhenOpeningFiles: e.target.checked })} />
                  <Checkbox label={<span>Support <span className="underline decoration-1 underline-offset-[3px]">v</span>olume labels in paths</span>} checked={config.supportVolumeLabelsInPaths ?? false} onChange={e => updateConfig({ supportVolumeLabelsInPaths: e.target.checked })} />
                  <Checkbox label={<span>Copy paths to the clipboard with a trailing slash</span>} checked={config.copyPathsToTheClipboardWithATrailingSlash ?? false} onChange={e => updateConfig({ copyPathsToTheClipboardWithATrailingSlash: e.target.checked })} />
                  <Checkbox label={<span>Resol<span className="underline decoration-1 underline-offset-[3px]">v</span>e junctions</span>} checked={config.resolveJunctions ?? false} onChange={e => updateConfig({ resolveJunctions: e.target.checked })} />
                  <Checkbox label={<span>Open favorite files <span className="underline decoration-1 underline-offset-[3px]">d</span>irectly</span>} checked={config.openFavoriteFilesDirectly ?? false} onChange={e => updateConfig({ openFavoriteFilesDirectly: e.target.checked })} />
                  <Checkbox label={<span>Allow zombies in the Mini Tree</span>} checked={config.allowZombiesInTheMiniTree ?? false} onChange={e => updateConfig({ allowZombiesInTheMiniTree: e.target.checked })} />
                  <Checkbox label={<span>Paste to selected list folder</span>} checked={config.pasteToSelectedListFolder ?? false} onChange={e => updateConfig({ pasteToSelectedListFolder: e.target.checked })} />
                  <Checkbox label={<span>Show <span className="underline decoration-1 underline-offset-[3px]">m</span>essage when list is empty</span>} checked={config.showMessageWhenListIsEmpty ?? false} onChange={e => updateConfig({ showMessageWhenListIsEmpty: e.target.checked })} />
                  <Checkbox label={<span>Sho<span className="underline decoration-1 underline-offset-[3px]">w</span> version information in the Status Bar</span>} checked={config.showVersionInformationInTheStatusBar ?? false} onChange={e => updateConfig({ showVersionInformationInTheStatusBar: e.target.checked })} />
                  <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">S</span>unday is the first day of the week</span>} checked={config.sundayIsTheFirstDayOfTheWeek ?? false} onChange={e => updateConfig({ sundayIsTheFirstDayOfTheWeek: e.target.checked })} />
                  <Checkbox label={<span>Play a soun<span className="underline decoration-1 underline-offset-[3px]">d</span> on certain events</span>} checked={config.playASoundOnCertainEvents ?? false} onChange={e => updateConfig({ playASoundOnCertainEvents: e.target.checked })} />
                  <Checkbox label={<span>Enable surround selection</span>} checked={config.enableSurroundSelection ?? false} onChange={e => updateConfig({ enableSurroundSelection: e.target.checked })} />
              </div>
            </TabsContent>

            <TabsContent value="Startup & Exit" className="m-0 border-0 p-0 outline-none">
              <h1 className="text-[20px] font-bold text-white mb-6 leading-tight">Startup & Exit</h1>
              
              <div className="flex flex-col gap-1 ml-2 mb-4 mt-2">
                 <span className="text-[12px] text-[#e0e0e0]">Permanent start<span className="underline decoration-1 underline-offset-[3px]">u</span>p path:</span>
                 <div className="flex items-center gap-2">
                    <input type="text" className="w-[500px] h-6 bg-transparent border border-[#555] text-white text-[12px] px-1 outline-none" value={config.permanentStartupPath} onChange={e => updateConfig({ permanentStartupPath: e.target.value })} />
                    <button className="h-6 w-8 bg-[#2a2d2e] border border-[#555] text-white flex items-center justify-center hover:bg-[#3a3d3e]">...</button>
                 </div>
                 <div className="mt-1">
                    <Checkbox label={<span>Expand in <span className="underline decoration-1 underline-offset-[3px]">t</span>ree</span>} checked={config.expandInTree ?? false} onChange={e => updateConfig({ expandInTree: e.target.checked })} />
                 </div>
              </div>

              <div className="grid grid-cols-[140px_200px] gap-2 ml-2 mb-4 mt-4 items-center">
                 <span className="text-[12px] text-[#e0e0e0]">Startup pane:</span>
                 <select className="bg-[#1e1e1e] border border-[#666] text-[#e0e0e0] text-[12px] px-2 py-[2px] rounded-sm w-full outline-none" value={config.startupPane} onChange={e => updateConfig({ startupPane: e.target.value })}>
                    <option>Last pane</option>
                 </select>
                 
                 <span className="text-[12px] text-[#e0e0e0]">Startup <span className="underline decoration-1 underline-offset-[3px]">w</span>indow state:</span>
                 <select className="bg-[#1e1e1e] border border-[#666] text-[#e0e0e0] text-[12px] px-2 py-[2px] rounded-sm w-full outline-none" value={config.startupWindowState} onChange={e => updateConfig({ startupWindowState: e.target.value })}>
                    <option>Last state</option>
                    <option>Minimized</option>
                    <option>Normal</option>
                    <option>Maximized</option>
                    <option>Tray</option>
                 </select>
              </div>

              <div className="ml-2 mb-4 space-y-[6px]">
                  <Checkbox label={<span>Open <span className="underline decoration-1 underline-offset-[3px]">c</span>ommand line start path in new tab</span>} checked={config.openCommandLineStartPathInNewTab ?? false} onChange={e => updateConfig({ openCommandLineStartPathInNewTab: e.target.checked })} />
                  <Checkbox label={<span>Allow <span className="underline decoration-1 underline-offset-[3px]">m</span>ultiple instances</span>} checked={config.allowMultipleInstances ?? false} onChange={e => updateConfig({ allowMultipleInstances: e.target.checked })} />
                  <div className="ml-[20px]">
                     <Checkbox label={<span>Open <span className="underline decoration-1 underline-offset-[3px]">n</span>ew instance always</span>} checked={config.openNewInstanceAlways ?? false} onChange={e => updateConfig({ openNewInstanceAlways: e.target.checked })} disabled={!config.allowMultipleInstances} />
                  </div>
                  
                  <Checkbox label={<span>Minimize to tray</span>} checked={config.minimizeToTray ?? false} onChange={e => updateConfig({ minimizeToTray: e.target.checked })} />
                  <Checkbox label={<span>Minimize to tray on <span className="underline decoration-1 underline-offset-[3px]">X</span> close</span>} checked={config.minimizeToTrayOnXClose ?? false} onChange={e => updateConfig({ minimizeToTrayOnXClose: e.target.checked })} />
                  
                  <div className="h-2"></div>
                  <Checkbox label={<span>Show <span className="underline decoration-1 underline-offset-[3px]">s</span>plash screen while loading</span>} checked={config.showSplashScreenWhileLoading ?? false} onChange={e => updateConfig({ showSplashScreenWhileLoading: e.target.checked })} />
                  <Checkbox label={<span>Chec<span className="underline decoration-1 underline-offset-[3px]">k</span> for updates at startup</span>} checked={config.checkForUpdatesAtStartup ?? false} onChange={e => updateConfig({ checkForUpdatesAtStartup: e.target.checked })} />
                  <div className="ml-[20px]">
                     <Checkbox label={<span>Include <span className="underline decoration-1 underline-offset-[3px]">b</span>eta versions</span>} checked={config.includeBetaVersions ?? false} onChange={e => updateConfig({ includeBetaVersions: e.target.checked })} disabled={!config.checkForUpdatesAtStartup} />
                  </div>
                  <Checkbox label={<span>Check for <span className="underline decoration-1 underline-offset-[3px]">l</span>anguage updates at startup</span>} checked={config.checkForLanguageUpdatesAtStartup ?? false} onChange={e => updateConfig({ checkForLanguageUpdatesAtStartup: e.target.checked })} />
                  
                  <div className="h-2"></div>
                  <Checkbox label={<span>No network <span className="underline decoration-1 underline-offset-[3px]">b</span>rowsing at startup</span>} checked={config.noNetworkBrowsingAtStartup ?? false} onChange={e => updateConfig({ noNetworkBrowsingAtStartup: e.target.checked })} />
                  <Checkbox label={<span>Reconnect mapped network <span className="underline decoration-1 underline-offset-[3px]">d</span>rives at startup</span>} checked={config.reconnectMappedNetworkDrivesAtStartup ?? false} onChange={e => updateConfig({ reconnectMappedNetworkDrivesAtStartup: e.target.checked })} />
                  <Checkbox label={<span>Adjust to OS lig<span className="underline decoration-1 underline-offset-[3px]">h</span>t/dark mode at startup</span>} checked={config.adjustToOsLightDarkModeAtStartup ?? false} onChange={e => updateConfig({ adjustToOsLightDarkModeAtStartup: e.target.checked })} />
              </div>
              
              <SectionHeader title="Save Settings" />
              <div className="ml-2 mb-4 space-y-[6px]">
                  <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">S</span>ave settings on exit</span>} checked={config.saveSettingsOnExit ?? false} onChange={e => updateConfig({ saveSettingsOnExit: e.target.checked })} />
                  <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">I</span>nclude most-recently-used lists on save</span>} checked={config.includeMostRecentlyUsedListsOnSave ?? false} onChange={e => updateConfig({ includeMostRecentlyUsedListsOnSave: e.target.checked })} />
                  <div className="ml-[24px] mb-2">
                     <ActionBtn label="Apply to..." className="px-6 py-[2px] bg-[#1a1a1a]" />
                  </div>
                  <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">B</span>ackup settings on save</span>} checked={config.backupSettingsOnSave ?? false} onChange={e => updateConfig({ backupSettingsOnSave: e.target.checked })} />
                  <Checkbox label={<span>Save changes to disk immediately</span>} checked={config.saveChangesToDiskImmediately ?? false} onChange={e => updateConfig({ saveChangesToDiskImmediately: e.target.checked })} />
                  <div className="ml-[24px] mb-[20px]">
                     <ActionBtn label="Apply to..." className="px-6 py-[2px] bg-[#1a1a1a]" />
                  </div>
              </div>
            </TabsContent>

            <TabsContent value="File Operations" className="m-0 border-0 p-0 outline-none">
              <h1 className="text-[20px] font-bold text-white mb-6 leading-tight">File Operations</h1>
              <SectionHeader title="Background Processing" />
              <div className="ml-2">
                 <div className="flex items-center justify-between w-[350px]">
                   <Checkbox label="Enable background processing" checked={config.enableBackgroundProcessing ?? false} onChange={e => updateConfig({ enableBackgroundProcessing: e.target.checked })} />
                   <ActionBtn label="Apply to..." />
                 </div>
                 <Checkbox label="Queue file operations" checked={config.queueFileOperations ?? false} onChange={e => updateConfig({ queueFileOperations: e.target.checked })} />
                 <p className="text-[11px] text-gray-400 mt-1">Background Copy Handler: BNDZcopy.exe v2.20.0037 (64-bit)</p>
              </div>
            </TabsContent>

            <TabsContent value="Shell Integration" className="m-0 border-0 p-0 outline-none mt-1">
              <h1 className="text-[22px] font-bold text-white mb-6 tracking-tight">Shell Integration</h1>
              
              <SectionHeader title="Default File Manager" />
              <p className="text-[12px] text-[#e0e0e0] mb-[22px] mt-1 ml-[8px]">Note that changes will take immediate effect and modify the registry of the host system.</p>

              <div className="flex items-center gap-[42px] ml-[24px] mb-8 mt-[10px]">
                 <span className="text-[12px] text-[#e0e0e0]">Scope:</span>
                 <select className="bg-[#1e1e1e] border border-[#666] text-[#e0e0e0] text-[12px] px-2 py-[2px] rounded-sm w-[355px] outline-none" value={config.selectConfig1 || ""} onChange={e => updateConfig({selectConfig1: e.target.value})}>
                    <option>Only for the current user</option>
                 </select>
              </div>

              <div className="ml-[8px] mb-8 space-y-[10px] mt-6">
                 <div>
                    <Checkbox label={<span>BNDZ in shell <span className="underline decoration-1 underline-offset-[3px]">c</span>ontext menu</span>} checked={config.bndzInShellContextMenu ?? false} onChange={e => updateConfig({ bndzInShellContextMenu: e.target.checked })} />
                    <p className="text-[12px] text-[#e0e0e0] mt-[2px] ml-[22px]">Adds the item "BNDZ" to the shell context menu for drives and directories.</p>
                 </div>

                 <div className="ml-[20px] pt-1">
                    <Checkbox label={<span>BNDZ is <span className="underline decoration-1 underline-offset-[3px]">d</span>efault file manager</span>} checked={config.bndzIsDefaultFileManager ?? false} onChange={e => updateConfig({ bndzIsDefaultFileManager: e.target.checked })} disabled={!config.inContextMenu} />
                    <p className={`text-[12px] mt-[2px] ml-[22px] ${!config.inContextMenu ? 'text-[#888]' : 'text-[#888]'}`}>Double-clicking drives or directories will open them in BNDZ.</p>
                 </div>
              </div>

              <SectionHeader title="Drag and Drop" />
              <div className="ml-[8px] mb-8 space-y-[12px] mt-2">
                 <div>
                    <span className="text-[12px] text-[#e0e0e0] block mb-1">Default action on drag and drop to same drive:</span>
                    <select className="bg-[#1e1e1e] border border-[#666] text-[#e0e0e0] text-[12px] px-2 py-[2px] rounded-sm w-[360px] outline-none hover:border-[#888]" value={config.selectConfig2 || ""} onChange={e => updateConfig({selectConfig2: e.target.value})}>
                       <option>Move (Windows Standard)</option>
                    </select>
                 </div>
                 <div className="pt-2">
                    <span className="text-[12px] text-[#e0e0e0] block mb-1">Default action on drag and drop to different drive:</span>
                    <select className="bg-[#1e1e1e] border border-[#666] text-[#e0e0e0] text-[12px] px-2 py-[2px] rounded-sm w-[360px] outline-none hover:border-[#888]" value={config.selectConfig3 || ""} onChange={e => updateConfig({selectConfig3: e.target.value})}>
                       <option>Copy (Windows Standard)</option>
                    </select>
                 </div>
                 <div className="text-white mt-5 pt-3">
                    <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">E</span>xtended compatibility for clipboard and drag and drop</span>} checked={config.extendedCompatibilityForClipboardAndDragAndDrop ?? false} onChange={e => updateConfig({ extendedCompatibilityForClipboardAndDragAndDrop: e.target.checked })} />
                 </div>
              </div>

            </TabsContent>

            <TabsContent value="Features" className="m-0 border-0 p-0 outline-none">
              <h1 className="text-[20px] font-bold text-white mb-6 leading-tight">Features</h1>
              
              <SectionHeader title="EverythingNet Global Search" />
              <div className="ml-2 mb-4">
                 <Checkbox label="Enable zero-latency global file search" checked={config.enableZeroLatencyGlobalFileSearch ?? false} onChange={e => updateConfig({ enableZeroLatencyGlobalFileSearch: e.target.checked })} />
                 <p className="text-[11px] text-gray-400 mt-1 mb-2 ml-[22px]">Uses the Everything search engine backend for instant results.</p>
              </div>
              
              <SectionHeader title="Native OS Thumbnails" />
              <div className="ml-2 mb-4">
                 <Checkbox label="Enable high-performance native thumbnails" checked={config.enableHighPerformanceNativeThumbnails ?? false} onChange={e => updateConfig({ enableHighPerformanceNativeThumbnails: e.target.checked })} />
                 <p className="text-[11px] text-gray-400 mt-1 mb-2 ml-[22px]">Leverages Vanara & WindowsAPICodePack for rich metadata.</p>
              </div>
            </TabsContent>

            <TabsContent value="Colors" className="m-0 border-0 p-0 outline-none">
              <h1 className="text-[20px] font-bold text-white mb-[8px] leading-tight">Colors</h1>
              <p className="text-[12px] text-[#e0e0e0] mb-[24px]">Left-click the labels to set colors via a dialog, or paste RGB hex values into the text fields. Right-click the labels to reset to default colors.</p>
              
              <div className="grid grid-cols-2 gap-x-[32px] gap-y-4">
                 <div>
                    <span className="text-[12px] font-bold text-white mb-2 block">Tree</span>
                    <div className="border border-[#444] bg-[#1a1a1a]">
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center text-white py-[2px] bg-white text-black">Text</div>
                          <ColorPicker value={config.colorConfig1 || "#000000"} onChange={(val) => updateConfig({colorConfig1: val})} />
                       </div>
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center py-[2px]">Background</div>
                          <ColorPicker value={config.colorConfig2 || "#FFFFFF"} onChange={(val) => updateConfig({colorConfig2: val})} />
                       </div>
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center text-black bg-[#FFFF80] py-[2px]">Highlighted</div>
                          <ColorPicker value={config.colorConfig3 || "#FFFF80"} onChange={(val) => updateConfig({colorConfig3: val})} />
                       </div>
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center text-[#555] bg-[#F7F7F7] py-[2px]">Boxed Branch</div>
                          <ColorPicker value={config.colorConfig4 || "#F7F7F7"} onChange={(val) => updateConfig({colorConfig4: val})} />
                       </div>
                       <div className="flex">
                          <div className="flex-1 text-[12px] text-center text-[#555] bg-[#F7F7F7] py-[2px]">Locked Tree</div>
                          <ColorPicker value={config.colorConfig5 || "#F7F7F7"} onChange={(val) => updateConfig({colorConfig5: val})} />
                       </div>
                    </div>
                 </div>

                 <div>
                    <span className="text-[12px] font-bold text-white mb-2 block">Tabs</span>
                    <div className="border border-[#444] bg-[#1a1a1a] mb-2">
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center text-black bg-white py-[2px]">Selected Tab Text</div>
                          <ColorPicker value={config.colorConfig6 || "#000000"} onChange={(val) => updateConfig({colorConfig6: val})} />
                       </div>
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center py-[2px]">Background</div>
                          <ColorPicker value={config.colorConfig7 || "#FFFFFF"} onChange={(val) => updateConfig({colorConfig7: val})} />
                       </div>
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center text-black bg-white py-[2px]">Other Tabs Text</div>
                          <ColorPicker value={config.colorConfig8 || "#000000"} onChange={(val) => updateConfig({colorConfig8: val})} />
                       </div>
                       <div className="flex">
                          <div className="flex-1 text-[12px] text-center text-[#555] bg-[#F0F0F0] py-[2px]">Background</div>
                          <ColorPicker value={config.colorConfig9 || "#F0F0F0"} onChange={(val) => updateConfig({colorConfig9: val})} />
                       </div>
                    </div>
                    <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">A</span>pply colors</span>} checked={config.applyColors ?? false} onChange={e => updateConfig({ applyColors: e.target.checked })} />
                    <Checkbox label={<span>Match selected tab with <span className="underline decoration-1 underline-offset-[3px]">b</span>readcrumb bar</span>} checked={config.matchSelectedTabWithBreadcrumbBar ?? false} onChange={e => updateConfig({ matchSelectedTabWithBreadcrumbBar: e.target.checked })} />
                    <div className="ml-5">
                       <Checkbox label={<span>Preserve c<span className="underline decoration-1 underline-offset-[3px]">u</span>stom colors</span>} checked={config.preserveCustomColors ?? false} onChange={e => updateConfig({ preserveCustomColors: e.target.checked })} />
                    </div>
                 </div>
                 
                 <div>
                    <span className="text-[12px] font-bold text-white mb-[2px] block">List</span>
                    <select className="bg-[#1e1e1e] border border-[#666] text-[#e0e0e0] text-[12px] px-2 py-[1px] w-full mb-1" value={config.selectConfig4 || ""} onChange={e => updateConfig({selectConfig4: e.target.value})}>
                       <option>Drives</option>
                    </select>
                    <div className="border border-[#444] bg-[#1a1a1a]">
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center text-black bg-white py-[2px]">Text</div>
                          <ColorPicker value={config.colorConfig10 || "#000000"} onChange={(val) => updateConfig({colorConfig10: val})} />
                       </div>
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center py-[2px]">Background</div>
                          <ColorPicker value={config.colorConfig11 || "#FFFFFF"} onChange={(val) => updateConfig({colorConfig11: val})} />
                       </div>
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center py-[2px]">Sorted Column</div>
                          <ColorPicker value={config.colorConfig12 || "#FDFDFD"} onChange={(val) => updateConfig({colorConfig12: val})} />
                       </div>
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center py-[2px]">Focused Item</div>
                          <ColorPicker value={config.colorConfig13 || "#F5F8FA"} onChange={(val) => updateConfig({colorConfig13: val})} />
                       </div>
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center py-[2px]">Selected Rows</div>
                          <ColorPicker value={config.colorConfig14 || "#EAEAEA"} onChange={(val) => updateConfig({colorConfig14: val})} />
                       </div>
                       <div className="flex">
                          <div className="flex-1 text-[12px] text-center py-[2px]">Grid</div>
                          <ColorPicker value={config.colorConfig15 || "#F5F9FE"} onChange={(val) => updateConfig({colorConfig15: val})} />
                       </div>
                    </div>
                 </div>

                 <div>
                    <span className="text-[12px] font-bold text-white mb-2 block">Other</span>
                    <div className="border border-[#444] bg-[#1a1a1a] mb-[20px] mt-[26px]">
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center text-[#106FCD] py-[2px]">Marked Text 1</div>
                          <ColorPicker value={config.colorConfig16 || "#106FCD"} onChange={(val) => updateConfig({colorConfig16: val})} />
                       </div>
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center text-[#106FCD] py-[2px]">Marked Text 2</div>
                          <ColorPicker value={config.colorConfig17 || "#106FCD"} onChange={(val) => updateConfig({colorConfig17: val})} />
                       </div>
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center text-[#9A9A9A] bg-[#F9F9F9] py-[2px]">Inactive Pane</div>
                          <ColorPicker value={config.colorConfig18 || "#F9F9F9"} onChange={(val) => updateConfig({colorConfig18: val})} />
                       </div>
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center text-[#9A9A9A] bg-[#FAFAFA] py-[2px]">Line Num Text</div>
                          <ColorPicker value={config.colorConfig19 || "#9A9A9A"} onChange={(val) => updateConfig({colorConfig19: val})} />
                       </div>
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center bg-[#FAFAFA] py-[2px]">Line Num Back</div>
                          <ColorPicker value={config.colorConfig20 || "#FAFAFA"} onChange={(val) => updateConfig({colorConfig20: val})} />
                       </div>
                       <div className="flex">
                          <div className="flex-1 text-[12px] text-center text-white bg-[#588FC6] py-[2px]">Selection Box</div>
                          <ColorPicker value={config.colorConfig21 || "#588FC6"} onChange={(val) => updateConfig({colorConfig21: val})} />
                       </div>
                    </div>
                 </div>
              </div>
              
              <div className="grid grid-cols-2 gap-[32px] mt-4">
                 <div>
                    <span className="text-[12px] font-bold text-white mb-2 block">Breadcrumb Bar 1</span>
                    <div className="border border-[#444] bg-[#1a1a1a] mb-2">
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center text-white bg-[#588FC6] py-[2px]">Active Text</div>
                          <ColorPicker value={config.colorConfig22 || "#FFFFFF"} onChange={(val) => updateConfig({colorConfig22: val})} />
                       </div>
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center text-white bg-[#588FC6] font-bold py-[2px]">Active Back</div>
                          <ColorPicker value={config.colorConfig23 || "#588FC6"} onChange={(val) => updateConfig({colorConfig23: val})} />
                       </div>
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center text-white bg-[#B1B6BC] py-[2px]">Inactive Text</div>
                          <ColorPicker value={config.colorConfig24 || "#FFFFFF"} onChange={(val) => updateConfig({colorConfig24: val})} />
                       </div>
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center text-white bg-[#B1B6BC] font-bold py-[2px]">Inactive Back</div>
                          <ColorPicker value={config.colorConfig25 || "#B1B6BC"} onChange={(val) => updateConfig({colorConfig25: val})} />
                       </div>
                    </div>
                    <Checkbox label={<span>Match breadcrumb bar with custom colored <span className="underline decoration-1 underline-offset-[3px]">t</span>ab</span>} checked={config.matchBreadcrumbBarWithCustomColoredTab ?? false} onChange={e => updateConfig({ matchBreadcrumbBarWithCustomColoredTab: e.target.checked })} />
                 </div>
                 
                 <div>
                    <span className="text-[12px] font-bold text-white mb-2 block">Breadcrumb Bar 2</span>
                    <div className="border border-[#444] bg-[#1a1a1a] mb-[28px]">
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center text-white bg-[#A97369] py-[2px]">Active Text</div>
                          <ColorPicker value={config.colorConfig26 || "#FFFFFF"} onChange={(val) => updateConfig({colorConfig26: val})} />
                       </div>
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center text-white bg-[#A97369] font-bold py-[2px]">Active Back</div>
                          <ColorPicker value={config.colorConfig27 || "#A97369"} onChange={(val) => updateConfig({colorConfig27: val})} />
                       </div>
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center text-white bg-[#BAB1AF] py-[2px]">Inactive Text</div>
                          <ColorPicker value={config.colorConfig28 || "#FFFFFF"} onChange={(val) => updateConfig({colorConfig28: val})} />
                       </div>
                       <div className="flex border-b border-[#444]">
                          <div className="flex-1 text-[12px] text-center text-white bg-[#BAB1AF] font-bold py-[2px]">Inactive Back</div>
                          <ColorPicker value={config.colorConfig29 || "#BAB1AF"} onChange={(val) => updateConfig({colorConfig29: val})} />
                       </div>
                    </div>
                    <div className="flex justify-end pr-1 text-right mt-1">
                        <ActionBtn label="Reset Colors..." className="px-6!" />
                    </div>
                 </div>
              </div>
            </TabsContent>

            <TabsContent value="Highlights & Dark Mode" className="m-0 border-0 p-0 outline-none">
              <h1 className="text-[20px] font-bold text-white mb-6 leading-tight">Highlights & Dark Mode</h1>
              
              <div className="space-y-[8px] mb-8">
                 <div className="flex items-center gap-[42px]">
                    <span className="text-[12px] text-[#e0e0e0] w-[140px]">Grid st<span className="underline decoration-1 underline-offset-[3px]">y</span>le:</span>
                    <select className="bg-[#1e1e1e] border border-[#666] text-[#e0e0e0] text-[12px] px-2 py-[2px] rounded-sm w-[360px] outline-none" value={config.selectConfig5 || ""} onChange={e => updateConfig({selectConfig5: e.target.value})}>
                       <option>Zebra Stripes: Alternate Rows (1)</option>
                    </select>
                 </div>
                 <div className="flex items-center gap-[42px]">
                    <span className="text-[12px] text-[#e0e0e0] w-[140px]">B<span className="underline decoration-1 underline-offset-[3px]">o</span>rders:</span>
                    <select className="bg-[#1e1e1e] border border-[#666] text-[#e0e0e0] text-[12px] px-2 py-[2px] rounded-sm w-[360px] outline-none" value={config.selectConfig6 || ""} onChange={e => updateConfig({selectConfig6: e.target.value})}>
                       <option>No border</option>
                    </select>
                 </div>
                 <div className="flex items-center gap-[42px]">
                    <span className="text-[12px] text-[#e0e0e0] w-[140px]">Se<span className="underline decoration-1 underline-offset-[3px]">l</span>ections:</span>
                    <select className="bg-[#1e1e1e] border border-[#666] text-[#e0e0e0] text-[12px] px-2 py-[2px] rounded-sm w-[360px] outline-none" value={config.selectConfig7 || ""} onChange={e => updateConfig({selectConfig7: e.target.value})}>
                       <option>BNDZ Style (Rounded)</option>
                    </select>
                 </div>
                 <div className="flex items-center gap-[42px]">
                    <span className="text-[12px] text-[#e0e0e0] w-[140px]">Focu<span className="underline decoration-1 underline-offset-[3px]">s</span> rectangle:</span>
                    <select className="bg-[#1e1e1e] border border-[#666] text-[#e0e0e0] text-[12px] px-2 py-[2px] rounded-sm w-[360px] outline-none" value={config.selectConfig8 || ""} onChange={e => updateConfig({selectConfig8: e.target.value})}>
                       <option>Solid</option>
                    </select>
                 </div>
              </div>

              <span className="text-[12px] text-[#e0e0e0] mb-[4px] block">Selections in f<span className="underline decoration-1 underline-offset-[3px]">o</span>cused controls (BNDZ Style only):</span>
              <div className="flex items-start gap-4 mb-6">
                 <div className="mt-1"><Checkbox label="Use" checked={config.use ?? false} onChange={e => updateConfig({ use: e.target.checked })} /></div>
                 <div className="border border-[#444] bg-[#1a1a1a] flex-1 max-w-[400px]">
                    <div className="flex border-b border-[#444]">
                       <div className="flex-1 text-[12px] text-center text-white bg-[#5096E2] py-[2px]">Selection Text</div>
                       <ColorPicker value={config.colorConfig30 || "#FFFFFF"} onChange={(val) => updateConfig({colorConfig30: val})} />
                    </div>
                    <div className="flex">
                       <div className="flex-1 text-[12px] text-center text-black bg-[#5096E2] py-[2px]">Selection Background</div>
                       <ColorPicker value={config.colorConfig31 || "#5096E2"} onChange={(val) => updateConfig({colorConfig31: val})} />
                    </div>
                 </div>
              </div>

              <span className="text-[12px] text-[#e0e0e0] mb-[4px] block">Selections in n<span className="underline decoration-1 underline-offset-[3px]">o</span>n-focused controls:</span>
              <div className="flex items-start gap-4 mb-6">
                 <div className="mt-1"><Checkbox label="Use" checked={config.use ?? false} onChange={e => updateConfig({ use: e.target.checked })} /></div>
                 <div className="border border-[#444] bg-[#1a1a1a] flex-1 max-w-[400px]">
                    <div className="flex border-b border-[#444]">
                       <div className="flex-1 text-[12px] text-center text-black bg-[#D0DBE6] py-[2px]">Selection Text</div>
                       <ColorPicker value={config.colorConfig32 || "#000000"} onChange={(val) => updateConfig({colorConfig32: val})} />
                    </div>
                    <div className="flex">
                       <div className="flex-1 text-[12px] text-center text-black bg-[#D0DBE6] py-[2px]">Selection Background</div>
                       <ColorPicker value={config.colorConfig33 || "#D0DBE6"} onChange={(val) => updateConfig({colorConfig33: val})} />
                    </div>
                 </div>
              </div>
              
              <span className="text-[12px] text-[#e0e0e0] mb-[4px] block">Tree path tracing:</span>
              <div className="ml-[65px] mb-6 space-y-[6px]">
                 <div className="border border-[#444] bg-[#1a1a1a] max-w-[340px]">
                    <div className="flex">
                       <div className="flex-1 text-[12px] text-center text-black font-medium bg-[#B6E956] py-[2px]">Current Tree Path</div>
                       <ColorPicker value={config.colorConfig34 || "#B6E956"} onChange={(val) => updateConfig({colorConfig34: val})} />
                    </div>
                 </div>
                 <Checkbox label={<span>Match color with <span className="underline decoration-1 underline-offset-[3px]">b</span>readcrumb bar</span>} checked={config.matchColorWithBreadcrumbBar ?? false} onChange={e => updateConfig({ matchColorWithBreadcrumbBar: e.target.checked })} />
                 <Checkbox label={<span>Mark i<span className="underline decoration-1 underline-offset-[3px]">n</span>termediate nodes</span>} checked={config.markIntermediateNodes ?? false} onChange={e => updateConfig({ markIntermediateNodes: e.target.checked })} />
                 <div className="flex items-center gap-2 mt-1">
                    <select className="bg-[#1e1e1e] border border-[#666] text-[#e0e0e0] text-[12px] px-1 py-[1px] w-[50px]" value={config.selectConfig9 || ""} onChange={e => updateConfig({selectConfig9: e.target.value})}><option>1</option></select>
                    <span className="text-[12px] text-[#e0e0e0]">Width of trace in pixels</span>
                 </div>
              </div>

              <span className="text-[12px] text-[#e0e0e0] mb-[4px] block"><span className="underline decoration-1 underline-offset-[3px]">R</span>ecent location pins:</span>
              <div className="ml-[65px] mb-6 space-y-[6px]">
                 <div className="border border-[#444] bg-[#1a1a1a] max-w-[340px]">
                    <div className="flex">
                       <div className="flex-1 text-[12px] text-center text-white bg-[#E956B6] py-[2px]">Pins</div>
                       <ColorPicker value={config.colorConfig35 || "#E956B6"} onChange={(val) => updateConfig({colorConfig35: val})} />
                    </div>
                 </div>
                 <Checkbox label={<span>Match color with <span className="underline decoration-1 underline-offset-[3px]">t</span>ree path tracing</span>} checked={config.matchColorWithTreePathTracing ?? false} onChange={e => updateConfig({ matchColorWithTreePathTracing: e.target.checked })} />
                 <div className="flex items-center gap-2 mt-1">
                    <select className="bg-[#1e1e1e] border border-[#666] text-[#e0e0e0] text-[12px] px-1 py-[1px] w-[50px]" value={config.selectConfig10 || ""} onChange={e => updateConfig({selectConfig10: e.target.value})}><option>12</option></select>
                    <span className="text-[12px] text-[#e0e0e0]">Maximum number of pin<span className="underline decoration-1 underline-offset-[3px]">s</span></span>
                 </div>
              </div>
              
              <div className="flex mt-8 mb-4">
                 <span className="text-[12px] text-[#e0e0e0] w-[140px]">Dark mode:</span>
                 <div className="flex items-center gap-4">
                    <div className="flex flex-col gap-2">
                       <button className="bg-[#2B579A] text-white px-5 py-[5px] text-[14px]">ABC</button>
                       <button className="bg-[#1A1A1A] text-white border border-[#444] px-5 py-[5px] text-[14px]">ABC</button>
                    </div>
                    <div className="flex flex-col gap-2">
                       <div className="flex items-center gap-2">
                          <select className="bg-[#1e1e1e] border border-[#666] text-[#e0e0e0] text-[12px] px-1 py-[1px] w-[50px]" value={config.selectConfig11 || ""} onChange={e => updateConfig({selectConfig11: e.target.value})}><option>20</option></select>
                          <span className="text-[12px] text-[#e0e0e0]"><span className="underline decoration-1 underline-offset-[3px]">L</span>evel of darkness (0 is darkest)</span>
                       </div>
                       <div className="flex items-center gap-2">
                          <select className="bg-[#1e1e1e] border border-[#666] text-[#e0e0e0] text-[12px] px-1 py-[1px] w-[50px]" value={config.selectConfig12 || ""} onChange={e => updateConfig({selectConfig12: e.target.value})}><option>15</option></select>
                          <span className="text-[12px] text-[#e0e0e0]">Te<span className="underline decoration-1 underline-offset-[3px]">x</span>t contrast</span>
                       </div>
                       <div className="flex items-center gap-2">
                          <select className="bg-[#1e1e1e] border border-[#666] text-[#e0e0e0] text-[12px] px-1 py-[1px] w-[50px]" value={config.selectConfig13 || ""} onChange={e => updateConfig({selectConfig13: e.target.value})}><option>0</option></select>
                          <span className="text-[12px] text-[#e0e0e0]">Color <span className="underline decoration-1 underline-offset-[3px]">t</span>int (0 is neutral)</span>
                       </div>
                       <div className="mt-1"><Checkbox label="Adaptive colors" checked={config.adaptiveColors ?? false} onChange={e => updateConfig({ adaptiveColors: e.target.checked })} /></div>
                    </div>
                 </div>
              </div>
            </TabsContent>

            <TabsContent value="Styles" className="m-0 border-0 p-0 outline-none">
              <h1 className="text-[20px] font-bold text-white mb-6 leading-tight">Styles</h1>
              <div className="space-y-[6px] mb-8">
                 <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">A</span>pply list styles globally</span>} checked={config.applyListStylesGlobally ?? false} onChange={e => updateConfig({ applyListStylesGlobally: e.target.checked })} />
                 <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">R</span>emember list settings per tab</span>} checked={config.rememberListSettingsPerTab ?? false} onChange={e => updateConfig({ rememberListSettingsPerTab: e.target.checked })} />
                 <div className="ml-[20px] mb-4">
                    <ActionBtn label="Apply to..." className="px-6 py-[2px] bg-[#1a1a1a]" />
                 </div>
                 
                 <Checkbox label={<span>Mirror tree bo<span className="underline decoration-1 underline-offset-[3px]">x</span> color in list</span>} checked={config.mirrorTreeBoxColorInList ?? false} onChange={e => updateConfig({ mirrorTreeBoxColorInList: e.target.checked })} />
                 <Checkbox label={<span>Semi-<span className="underline decoration-1 underline-offset-[3px]">t</span>ransparent grid color</span>} checked={config.semiTransparentGridColor ?? false} onChange={e => updateConfig({ semiTransparentGridColor: e.target.checked })} />
                 <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">U</span>nderline selected ro<span className="underline decoration-1 underline-offset-[3px]">w</span>s</span>} checked={config.underlineSelectedRows ?? false} onChange={e => updateConfig({ underlineSelectedRows: e.target.checked })} />
                 <Checkbox label={<span>Sticky c<span className="underline decoration-1 underline-offset-[3px]">h</span>eckbox selection</span>} checked={config.stickyCheckboxSelection ?? false} onChange={e => updateConfig({ stickyCheckboxSelection: e.target.checked })} />
                 <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">T</span>ranslucent selection b<span className="underline decoration-1 underline-offset-[3px]">o</span>x</span>} checked={config.translucentSelectionBox ?? false} onChange={e => updateConfig({ translucentSelectionBox: e.target.checked })} />
              </div>
              
              <div className="flex items-center gap-[42px] mb-8">
                 <div className="flex items-center gap-2">
                    <select className="bg-[#1e1e1e] border border-[#666] text-[#e0e0e0] text-[12px] px-1 py-[1px] w-[50px]" value={config.selectConfig14 || ""} onChange={e => updateConfig({selectConfig14: e.target.value})}><option>2</option></select>
                    <span className="text-[12px] text-[#e0e0e0]">Line sp<span className="underline decoration-1 underline-offset-[3px]">a</span>cing</span>
                 </div>
                 <div className="flex items-center gap-2">
                    <select className="bg-[#1e1e1e] border border-[#666] text-[#e0e0e0] text-[12px] px-1 py-[1px] w-[50px]" value={config.selectConfig15 || ""} onChange={e => updateConfig({selectConfig15: e.target.value})}><option>6</option></select>
                    <span className="text-[12px] text-[#e0e0e0]">Overall sp<span className="underline decoration-1 underline-offset-[3px]">a</span>cing</span>
                 </div>
              </div>
              
              <div className="flex items-center gap-2 mb-6 ml-[18px]">
                  <input type="text" className="w-[50px] h-[22px] bg-transparent border border-[#555] text-white text-[12px] px-1 text-right outline-none" />
                  <span className="text-[12px] text-[#e0e0e0]">Show Age maximum hours (0 = unlimited)</span>
              </div>
              
              <SectionHeader title="Clipboard Markers" />
              <div className="ml-2 mb-6 space-y-[6px]">
                  <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">D</span>immed icons</span>} checked={config.dimmedIcons ?? false} onChange={e => updateConfig({ dimmedIcons: e.target.checked })} />
                  <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">C</span>olored lines</span>} checked={config.coloredLines ?? false} onChange={e => updateConfig({ coloredLines: e.target.checked })} />
              </div>
              
              <SectionHeader title="Columns" />
              <div className="ml-2 mb-4 space-y-[6px]">
                  <Checkbox label={<span>Lig<span className="underline decoration-1 underline-offset-[3px]">h</span>ter te<span className="underline decoration-1 underline-offset-[3px]">x</span>t in details columns</span>} checked={config.lighterTextInDetailsColumns ?? false} onChange={e => updateConfig({ lighterTextInDetailsColumns: e.target.checked })} />
                  <Checkbox label={<span>Vertical grid lines in details vi<span className="underline decoration-1 underline-offset-[3px]">e</span>w</span>} checked={config.verticalGridLinesInDetailsView ?? false} onChange={e => updateConfig({ verticalGridLinesInDetailsView: e.target.checked })} />
                  <Checkbox label={<span>T<span className="underline decoration-1 underline-offset-[3px]">r</span>uncate filenames in the middle</span>} checked={config.truncateFilenamesInTheMiddle ?? false} onChange={e => updateConfig({ truncateFilenamesInTheMiddle: e.target.checked })} />
                  <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">A</span>utofit the width of the Name column</span>} checked={config.autofitTheWidthOfTheNameColumn ?? false} onChange={e => updateConfig({ autofitTheWidthOfTheNameColumn: e.target.checked })} />
                  
                  <div className="ml-[20px] flex items-center gap-2">
                     <input type="text" defaultValue="175" className="w-[45px] h-[22px] bg-transparent border border-[#555] text-white text-[12px] px-1 text-right outline-none" />
                     <input type="text" defaultValue="0" className="w-[45px] h-[22px] bg-transparent border border-[#555] text-white text-[12px] px-1 text-right outline-none" />
                     <span className="text-[12px] text-[#e0e0e0]">Minimum / Maximum Name column w<span className="underline decoration-1 underline-offset-[3px]">i</span>dth</span>
                  </div>
                  
                  <div className="h-2"></div>
                  <Checkbox label={<span>Always autosize the Si<span className="underline decoration-1 underline-offset-[3px]">z</span>e column</span>} checked={config.alwaysAutosizeTheSizeColumn ?? false} onChange={e => updateConfig({ alwaysAutosizeTheSizeColumn: e.target.checked })} />
                  <Checkbox label={<span>On autosize disregard the column <span className="underline decoration-1 underline-offset-[3px]">h</span>eaders</span>} checked={config.onAutosizeDisregardTheColumnHeaders ?? false} onChange={e => updateConfig({ onAutosizeDisregardTheColumnHeaders: e.target.checked })} />
                  
                  <div className="flex items-center gap-2 mt-1">
                     <input type="text" defaultValue="1000" className="w-[45px] h-[22px] bg-transparent border border-[#555] text-white text-[12px] px-1 text-right outline-none" />
                     <span className="text-[12px] text-[#e0e0e0]">Autosize columns m<span className="underline decoration-1 underline-offset-[3px]">a</span>ximum width (0 = unlimited)</span>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                     <input type="text" defaultValue="200" className="w-[45px] h-[22px] bg-transparent border border-[#555] text-white text-[12px] px-1 text-right outline-none" />
                     <span className="text-[12px] text-[#e0e0e0]">Autosize Name column mi<span className="underline decoration-1 underline-offset-[3px]">n</span>imum width (0 = unlimited)</span>
                  </div>
                  <div className="flex items-center gap-2 mt-1 mb-[12px]">
                     <input type="text" defaultValue="0" className="w-[45px] h-[22px] bg-transparent border border-[#555] text-white text-[12px] px-1 text-right outline-none" />
                     <span className="text-[12px] text-[#e0e0e0]">Autosize Name column right margin (0 = none)</span>
                  </div>
                  
                  <Checkbox label={<span>Use empty cell defaults</span>} checked={config.useEmptyCellDefaults ?? false} onChange={e => updateConfig({ useEmptyCellDefaults: e.target.checked })} />
                  <div className="ml-[20px] mt-1">
                     <ActionBtn label="Configure..." className="px-6 py-[2px] bg-[#1a1a1a]" />
                  </div>
              </div>
            </TabsContent>
            
            <TabsContent value="Color Filters" className="m-0 border-0 p-0 outline-none flex flex-col h-full">
              <h1 className="text-[20px] font-bold text-white mb-2 leading-tight">Color Filters</h1>
              <p className="text-[12px] text-[#e0e0e0] mb-[20px]">Color-code files and folders by name, attributes, size, date, age, or properties.</p>
              
              <div className="mb-4">
                 <Checkbox label={<span>Enable c<span className="underline decoration-1 underline-offset-[3px]">o</span>lor filters</span>} checked={config.enableColorFilters ?? false} onChange={e => updateConfig({ enableColorFilters: e.target.checked })} />
                 <div className="ml-[20px] space-y-[6px] mt-1">
                    <Checkbox label={<span>Apply color filters to the <span className="underline decoration-1 underline-offset-[3px]">L</span>ist</span>} checked={config.applyColorFiltersToTheList ?? false} onChange={e => updateConfig({ applyColorFiltersToTheList: e.target.checked })} />
                    <Checkbox label={<span>Apply color filters to the <span className="underline decoration-1 underline-offset-[3px]">T</span>ree</span>} checked={config.applyColorFiltersToTheTree ?? false} onChange={e => updateConfig({ applyColorFiltersToTheTree: e.target.checked })} />
                    <Checkbox label={<span><span className="underline decoration-1 underline-offset-[3px]">I</span>gnore diacritics</span>} checked={config.ignoreDiacritics ?? false} onChange={e => updateConfig({ ignoreDiacritics: e.target.checked })} />
                    <Checkbox label={<span>Apply text colors to the <span className="underline decoration-1 underline-offset-[3px]">N</span>ame column only</span>} checked={config.applyTextColorsToTheNameColumnOnly ?? false} onChange={e => updateConfig({ applyTextColorsToTheNameColumnOnly: e.target.checked })} />
                    <Checkbox label={<span>Draw background colors as r<span className="underline decoration-1 underline-offset-[3px]">o</span>unded rectangles</span>} checked={config.drawBackgroundColorsAsRoundedRectangles ?? false} onChange={e => updateConfig({ drawBackgroundColorsAsRoundedRectangles: e.target.checked })} />
                    <Checkbox label={<span>Draw background colors in distin<span className="underline decoration-1 underline-offset-[3px]">c</span>tive shapes</span>} checked={config.drawBackgroundColorsInDistinctiveShapes ?? false} onChange={e => updateConfig({ drawBackgroundColorsInDistinctiveShapes: e.target.checked })} />
                    <Checkbox label={<span>Draw background colors as wide as the c<span className="underline decoration-1 underline-offset-[3px]">o</span>lumn</span>} checked={config.drawBackgroundColorsAsWideAsTheColumn ?? false} onChange={e => updateConfig({ drawBackgroundColorsAsWideAsTheColumn: e.target.checked })} />
                 </div>
              </div>
              
              <div className="flex gap-4 flex-1 overflow-hidden min-h-[300px]">
                 <div className="flex-1 border border-[#444] bg-[#111] overflow-y-auto w-full p-2 text-[13px] font-mono leading-tight space-y-[2px]">
                    {[
                      {i: 1, c: true, t: "len:>260 //overlong filenames", style: "bg-[#E05B5B] text-white px-1"},
                      {i: 2, c: true, t: "attr:junction", style: "text-[#8F66D6] px-1"},
                      {i: 3, c: true, t: "attr:system", style: "bg-[#F4D03F] text-black px-1"},
                      {i: 4, c: true, t: "attr:encrypted", style: "text-[#2ECC71] px-1"},
                      {i: 5, c: true, t: "attr:compressed", style: "text-[#3498DB] px-1"},
                      {i: 6, c: true, t: "ageM: <= 30 n //modified in the last 30 mins", style: "bg-[#82E05B] text-black px-1"},
                      {i: 7, c: true, t: "ageM: d //modified today", style: "bg-[#82E05B] text-white px-1"},
                      {i: 8, c: true, t: "attr:d", style: "text-[#B6B6B6] px-1"},
                      {i: 9, c: true, t: "size:0 //empty files", style: "bg-[#FDFDFD] text-[#3498DB] px-1"},
                      {i: 10, c: true, t: "B:prop:#empty:2|f-s //empty folders", style: "bg-transparent text-white px-1 border border-white"},
                      {i: 11, c: true, t: "L:prop:#nosubs:2 //folders without subs", style: "text-[#3498DB] px-1"},
                      {i: 12, c: true, t: "*.exe;*.bat", style: "text-[#E74C3C] px-1"},
                      {i: 13, c: true, t: "*.htm;*.html;*.php", style: "text-[#3498DB] px-1"},
                      {i: 14, c: true, t: "*.txt;*.ini", style: "text-[#3498DB] px-1"},
                      {i: 15, c: true, t: "*.png;*.jpg;*.gif;*.bmp", style: "text-[#9B59B6] px-1"},
                      {i: 16, c: true, t: "*.zip;*.rar", style: "text-[#F39C12] px-1"},
                      {i: 17, c: true, t: "*.dll;*.ocx", style: "text-[#E74C3C] px-1"},
                      {i: 18, c: true, t: "*.mp3;*.wav", style: "text-[#3498DB] px-1"}
                    ].map(row => (
                       <div key={row.i} className="flex gap-2 items-center">
                          <span className="w-[18px] text-right text-gray-500">{row.i}</span>
                          <input type="checkbox" defaultChecked={row.c} className="accent-[#555] w-[13px] h-[13px]" />
                          <span className={`${row.style}`}>{row.t}</span>
                       </div>
                    ))}
                 </div>
                 <div className="w-[100px] flex flex-col gap-2 relative">
                    <ActionBtn label="New" className="w-full text-center py-[4px]" />
                    <ActionBtn label="Edit" className="w-full text-center py-[4px]" />
                    <ActionBtn label="Delete" className="w-full text-center py-[4px]" />
                    <div className="h-4"></div>
                    <ActionBtn label="Up" className="w-full text-center py-[4px]" />
                    <ActionBtn label="Down" className="w-full text-center py-[4px]" />
                    
                    <div className="absolute bottom-0 left-0 w-full space-y-2">
                       <span className="text-[12px] text-white">Define colors:</span>
                       <div className="flex gap-1 w-full">
                          <ActionBtn label="Text..." className="flex-1 py-[4px]" />
                          <ActionBtn label="Clear" className="px-2 py-[4px]" />
                       </div>
                       <div className="flex gap-1 w-full">
                          <ActionBtn label="Back..." className="flex-1 py-[4px]" />
                          <ActionBtn label="Clear" className="px-2 py-[4px]" />
                       </div>
                    </div>
                 </div>
              </div>
            </TabsContent>

            <TabsContent value="Fonts" className="m-0 border-0 p-0 outline-none">
               <h1 className="text-[20px] font-bold text-white mb-6 leading-tight">Fonts</h1>
               
               <div className="space-y-[24px]">
                  <div>
                     <span className="text-[12px] text-[#e0e0e0] mb-[4px] block"><span className="underline decoration-1 underline-offset-[3px]">M</span>ain Contents:</span>
                     <div className="flex items-center gap-3">
                        <input type="text" readOnly value="Segoe UI 9" className="w-[300px] bg-[#222] border border-[#555] text-white text-[12px] px-3 py-[4px] rounded-sm text-center outline-none" />
                        <ActionBtn label="Choose..." className="px-6 py-[2px]" />
                        <ActionBtn label="Apply to..." className="px-6 py-[2px]" />
                     </div>
                  </div>
                  <div>
                     <span className="text-[12px] text-[#e0e0e0] mb-[4px] block"><span className="underline decoration-1 underline-offset-[3px]">B</span>uttons and Labels:</span>
                     <div className="flex items-center gap-3">
                        <input type="text" readOnly value="Segoe UI 9" className="w-[300px] bg-[#222] border border-[#555] text-white text-[12px] px-3 py-[4px] rounded-sm text-center outline-none" />
                        <ActionBtn label="Choose..." className="px-6 py-[2px]" />
                     </div>
                  </div>
                  <div>
                     <span className="text-[12px] text-[#e0e0e0] mb-[4px] block"><span className="underline decoration-1 underline-offset-[3px]">R</span>egular Expressions:</span>
                     <div className="flex items-center gap-3">
                        <input type="text" readOnly value="Courier New 9.75" className="w-[300px] bg-[#222] border border-[#555] text-white text-[12px] px-3 py-[4px] rounded-sm text-center font-mono outline-none" />
                        <ActionBtn label="Choose..." className="px-6 py-[2px]" />
                     </div>
                  </div>
                  <div>
                     <span className="text-[12px] text-[#e0e0e0] mb-[4px] block"><span className="underline decoration-1 underline-offset-[3px]">E</span>dit Text:</span>
                     <div className="flex items-center gap-3">
                        <input type="text" readOnly value="Courier New 9.75" className="w-[300px] bg-[#222] border border-[#555] text-white text-[12px] px-3 py-[4px] rounded-sm text-center font-mono outline-none" />
                        <ActionBtn label="Choose..." className="px-6 py-[2px]" />
                     </div>
                  </div>
               </div>
               
               <div className="mt-[48px]">
                  <Checkbox label={<span>Ena<span className="underline decoration-1 underline-offset-[3px]">b</span>le zoom by Ctrl+mouse wheel</span>} checked={config.enableZoomByCtrlMouseWheel ?? false} onChange={e => updateConfig({ enableZoomByCtrlMouseWheel: e.target.checked })} />
               </div>
            </TabsContent>

            <TabsContent value="Templates" className="m-0 border-0 p-0 outline-none flex flex-col h-full">
               <h1 className="text-[20px] font-bold text-white mb-6 leading-tight">Templates</h1>
               
               <div className="max-w-[550px] space-y-[24px]">
                  <div>
                     <span className="text-[12px] font-bold text-white mb-[8px] block">Filename Affixes</span>
                     <div className="flex gap-2 items-center mb-1">
                        <input type="text" defaultValue="-01" className="w-[200px] bg-[#1e1e1e] border border-[#555] text-white text-[12px] px-2 py-[2px] outline-none" />
                        <span className="text-[12px] text-[#e0e0e0]"><span className="underline decoration-1 underline-offset-[3px]">I</span>ncremental affix (e.g. -01, (b), _000, or Copy of *-01)</span>
                     </div>
                     <div className="flex gap-2 items-center">
                        <input type="text" defaultValue="*-<date yyyymmdd>" className="w-[200px] bg-[#1e1e1e] border border-[#555] text-white text-[12px] px-2 py-[2px] outline-none" />
                        <span className="text-[12px] text-[#e0e0e0]"><span className="underline decoration-1 underline-offset-[3px]">D</span>ate affix (e.g. *-&lt;date yyyymmdd&gt;)</span>
                     </div>
                  </div>
                  
                  <div>
                     <span className="text-[12px] font-bold text-white mb-[8px] block">Dropped Messages</span>
                     <input type="text" defaultValue="<from>_<to>_<subject>_<date yyyy-mm-dd_hh-nn-ss>" className="w-full bg-[#1e1e1e] border border-[#555] text-white text-[12px] px-2 py-[4px] outline-none mb-1 font-mono" />
                     <p className="text-[12px] text-[#e0e0e0] mb-[8px]">Filename templa<span className="underline decoration-1 underline-offset-[3px]">t</span>e, e.g. &lt;from&gt;_&lt;to&gt;_&lt;subject&gt;?_&lt;date&gt;.</p>
                     
                     <div className="flex gap-2 items-center mb-1 mt-3">
                        <input type="text" className="w-[45px] bg-[#1e1e1e] border border-[#555] text-white text-[12px] px-2 py-[2px] outline-none" />
                        <span className="text-[12px] text-[#e0e0e0]"><span className="underline decoration-1 underline-offset-[3px]">C</span>haracter to replace invalid characters in dropped messages</span>
                     </div>
                     <div className="flex gap-2 items-center mb-2">
                        <input type="text" defaultValue="0" className="w-[45px] bg-[#1e1e1e] border border-[#555] text-white text-[12px] px-2 py-[2px] outline-none" />
                        <span className="text-[12px] text-[#e0e0e0]"><span className="underline decoration-1 underline-offset-[3px]">M</span>aximum length of generated filenames (0 = unlimited)</span>
                     </div>
                     <Checkbox label={<span>Auto-in<span className="underline decoration-1 underline-offset-[3px]">c</span>rement filenames on collision</span>} checked={config.autoIncrementFilenamesOnCollision ?? false} onChange={e => updateConfig({ autoIncrementFilenamesOnCollision: e.target.checked })} />
                  </div>
                  
                  <div>
                     <span className="text-[12px] font-bold text-white mb-[8px] block">Title Bar</span>
                     <input type="text" defaultValue="<path> - <app> <ver>" className="w-full bg-[#1e1e1e] border border-[#555] text-white text-[12px] px-2 py-[4px] outline-none mb-1 font-mono" />
                     <p className="text-[12px] text-[#e0e0e0] mb-[4px]">Ti<span className="underline decoration-1 underline-offset-[3px]">t</span>le bar template, e.g. &lt;path&gt; - &lt;app&gt; @ &lt;ini&gt; - &lt;ver&gt;. &lt;app&gt; is mandatory.</p>
                  </div>
                  
                  <div>
                     <span className="text-[12px] font-bold text-white mb-[8px] block">Status Bar</span>
                     <input type="text" defaultValue="<s:dimension> <s:duration>" className="w-full bg-[#1e1e1e] border border-[#555] text-white text-[12px] px-2 py-[4px] outline-none mb-[6px] font-mono" />
                     <Checkbox label={<span>Use status <span className="underline decoration-1 underline-offset-[3px]">b</span>ar template</span>} checked={config.useStatusBarTemplate ?? false} onChange={e => updateConfig({ useStatusBarTemplate: e.target.checked })} />
                  </div>
                  
                  <div>
                     <span className="text-[12px] font-bold text-white mb-[8px] block">Command Line Interpreter</span>
                     <Checkbox label={<span>Use custom <span className="underline decoration-1 underline-offset-[3px]">c</span>ommand line interpreter (else default to cmd.exe):</span>} checked={config.useCustomCommandLineInterpreterElseDefaultToCmdExe ?? false} onChange={e => updateConfig({ useCustomCommandLineInterpreterElseDefaultToCmdExe: e.target.checked })} />
                     <div className="ml-[20px] mt-[6px] space-y-[4px]">
                        <span className="text-[12px] text-[#e0e0e0] block">E<span className="underline decoration-1 underline-offset-[3px]">x</span>ecutable:</span>
                        <input type="text" className="w-[450px] bg-[#1e1e1e] border border-[#555] text-white text-[12px] px-2 py-[4px] outline-none mb-1" />
                        <span className="text-[12px] text-[#e0e0e0] block mt-1">Ar<span className="underline decoration-1 underline-offset-[3px]">g</span>uments:</span>
                        <input type="text" className="w-[450px] bg-[#1e1e1e] border border-[#555] text-white text-[12px] px-2 py-[4px] outline-none mb-1" />
                     </div>
                     <p className="text-[12px] text-[#e0e0e0] ml-[20px] mt-1">Use &lt;command&gt; as placeholder for address bar input (!-escape).</p>
                  </div>
               </div>
            </TabsContent>

            {categories.flatMap(c => c.items).filter(item => !["Tree and List", "Sort and Rename", "Refresh, Icons, History", "Menus, Mouse, Usability", "Custom Event Actions", "Safety Belts, Network", "Controls & More", "Startup & Exit", "File Operations", "Shell Integration", "Features", "Colors", "Highlights & Dark Mode", "Styles", "Color Filters", "Fonts", "Templates"].includes(item)).map(item => (
               <TabsContent key={item} value={item} className="m-0 border-0 p-0 outline-none">
                  <h1 className="text-[20px] font-bold text-white mb-6 leading-tight">{item}</h1>
                  <p className="text-[#a0a0a0] text-[13px]">Configuration options for this section are disabled in the current preview.</p>
               </TabsContent>
            ))}
         </div>
      </Tabs>

      {/* Footer */}
      <div className="bg-[#1a1a1a] border-t border-[#333] px-3 py-[10px] flex justify-between shrink-0">
         <div className="flex gap-2">
           <ActionBtn label="Help" className="px-5 py-[4px]" />
           <ActionBtn label="Jump to Setting..." className="px-5 py-[4px]" />
         </div>
         <div className="flex gap-3 pr-[4px]">
           <ActionBtn label="Apply" className="px-[22px] py-[3px] bg-[#333] border-[#666]" disabled />
           <ActionBtn label="OK" className="px-[22px] py-[3px] bg-[#333] border-[#666]" onClick={onClose} />
           <ActionBtn label="Cancel" className="px-[22px] py-[3px] bg-[#333] border-[#666]" onClick={onClose} />
         </div>
      </div>

    </div>
  )
}
