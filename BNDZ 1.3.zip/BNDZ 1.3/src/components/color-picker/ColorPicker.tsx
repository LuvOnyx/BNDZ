import React, { useState, useEffect } from 'react';

export default function ColorPicker({ value, onChange }: { value: string, onChange: (color: string) => void }) {
  const [localColor, setLocalColor] = useState(value || '#000000');

  useEffect(() => {
    if (value) {
      setLocalColor(value);
    }
  }, [value]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setLocalColor(e.target.value);
    onChange(e.target.value);
  };

  return (
    <div className="flex items-center gap-2 group cursor-pointer relative w-max rounded overflow-hidden shadow-sm border border-[#555] focus-within:border-[#22c55e] focus-within:ring-1 focus-within:ring-[#22c55e]/50 transition-all bg-[#1a1a1a]">
        <input 
            type="color" 
            value={localColor}
            onChange={handleChange}
            className="w-[28px] h-[28px] p-0 border-none rounded-none cursor-pointer bg-transparent appearance-none block"
            style={{ padding: 0 }}
        />
        <div className="flex items-center px-2 pr-3 py-1 bg-[#1a1a1a]">
          <span className="text-[#888] pr-1">#</span>
          <input 
              type="text" 
              value={localColor.replace('#', '').toUpperCase()}
              onChange={(e) => {
                  let val = e.target.value.replace(/[^0-9A-Fa-f]/g, '').slice(0, 6);
                  setLocalColor('#' + val);
                  if (val.length === 6) {
                      onChange('#' + val);
                  }
              }}
              className="bg-transparent text-[#e0e0e0] text-[12px] font-mono outline-none w-[50px] uppercase placeholder-[#555]"
              placeholder="000000"
              maxLength={6}
          />
        </div>
    </div>
  );
}
