import {ColorPicker} from './ColorPicker';

export default function Example() {
  return (
    <ColorPicker
      label="Fill"
      defaultValue="#5100FF" />
  );
}
