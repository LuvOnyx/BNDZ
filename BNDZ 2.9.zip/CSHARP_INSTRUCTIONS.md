# BNDZ Phase 20 - C# Bridge Updates

The React frontend has been successfully updated to support dynamic Toolbar arrays, inline renaming (delayed double-click + F2 Focustrap), deduplicated context menus, and proper tree interop.

You must apply these C# changes locally to your WinUI 3 backend to complete Phase 20:

## 1. The .ini Bootstrapper
Ensure your C# backend explicitly checks for the `bndz_config.ini` in the `AppData` folder on startup.

```csharp
// Inside App.xaml.cs or your ConfigurationManager.cs initialization
string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
string configPath = Path.Combine(appData, "BNDZ", "bndz_config.ini");

if (!File.Exists(configPath))
{
    Directory.CreateDirectory(Path.GetDirectoryName(configPath));
    // Auto-generate safe default configuration prepopulating WorkspaceLayout and ToolbarProfiles
    string defaultConfig = @"[General]
ShowHidden=false
[Layout]
SidebarOrder=storage,quick,tree
[ToolbarProfile_0]
Items=nav_back,nav_forward,nav_up,separator,go_home,spacer,cut,copy,paste,delete,separator,undo,redo,spacer,view_details,separator,refresh,spacer,config,wrench
";
    File.WriteAllText(configPath, defaultConfig);
}
```

## 2. Dynamic Context Menus & Verb Execution
Our React frontend now passes the exact underlying verb for context menus. You must implement `EXECUTE_CONTEXT_MENU_VERB` in the IPC bridge receiver:

```csharp
// Inside your ShellIntegrationService or IPC Event Handler
switch (message.Type)
{
    case "EXECUTE_CONTEXT_MENU_VERB":
        string path = message.Payload.path.ToString();
        string verb = message.Payload.verb.ToString();
        // Use Win32 IContextMenu pointer invocation or ProcessStartInfo
        ExecuteShellVerb(path, verb);
        break;
}

private void ExecuteShellVerb(string path, string verb)
{
    var startInfo = new ProcessStartInfo
    {
        FileName = path,
        Verb = verb,
        UseShellExecute = true
    };
    
    // Elevate admin where required (e.g., regedit)
    if (verb == "runas") 
        startInfo.Verb = "runas";

    try
    {
        Process.Start(startInfo);
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Failed to execute shell verb: {ex.Message}");
    }
}
```

## 3. Safe External Process Spawning
The React toolbar map uses `launch-cmd`, `launch-ps`, `launch-taskmgr`, etc., sent through the `SHELL_EXECUTE` event:

```csharp
case "SHELL_EXECUTE":
    string action = message.Payload.action.ToString();
    if (action.StartsWith("launch-"))
    {
        string cmd = action.Split('-')[1];
        ProcessStartInfo pInfo = new ProcessStartInfo { UseShellExecute = true };
        switch(cmd)
        {
            case "cmd": pInfo.FileName = "cmd.exe"; break;
            case "ps": pInfo.FileName = "powershell.exe"; break;
            case "taskmgr": pInfo.FileName = "taskmgr.exe"; break;
            case "regedit": 
                pInfo.FileName = "regedit.exe"; 
                pInfo.Verb = "runas"; 
                break;
        }
        Process.Start(pInfo);
    }
    break;
```

## 4. Context Menu Tree Interop 
The left navigation tree now explicitly requests native context menu fetching for paths rather than falling back to default custom contexts. Ensure the `GET_CONTEXT_MENU_ITEMS` or `SHOW_CONTEXT_MENU` functions in C# securely parse the full directory path passed from React to retrieve the IContextMenu implementation instead of standard local disk implementations only.

## 5. Phase 22: Local Virtual Host Mapping (Anti-Crash Protocol)

To support the Universal Preview Engine without crashing the WebView2 bridge on huge Base64 payloads (e.g., massive videos or logs), you must implement virtual host name mapping in the `CoreWebView2` environment. This allows the React app to pull local drives as if they were a web server.

```csharp
// Wait for CoreWebView2 initialization (e.g., inside _CoreWebView2Initialized event)
// Note: Map everything or specific drive letters. Here, mapping a root virtual host:
string hostName = "bndz.local";
// Mapping root of C to test, ideally map dynamically based on drives
webView.CoreWebView2.SetVirtualHostNameToFolderMapping(
    hostName, 
    "C:\\", 
    CoreWebView2HostResourceAccessKind.Allow
);

// If mapping multiple drives or a broader scope isn't native, you might have to map them individually.
// For dynamic requests to standard files, the React app will now use:
// <video src="https://bndz.local/Users/Me/Video.mp4" /> 
```
