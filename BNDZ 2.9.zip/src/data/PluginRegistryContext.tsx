import React, { createContext, useContext, ReactNode } from 'react';
import { useAppConfig } from './configContext';

export interface PluginManifest {
    id: string;
    name: string;
    description: string;
    targetPanel: "bottom" | "sidebar";
    isNative: boolean;
    isInstalled: boolean;
}

const defaultPlugins: PluginManifest[] = [
    { id: 'properties', name: 'File Properties', description: 'View and edit core file attributes and NTFS alternate data streams.', targetPanel: 'bottom', isNative: true, isInstalled: true },
    { id: 'find', name: 'Rapid Find', description: 'High-speed index-based search utilizing Master File Table (MFT) scanning.', targetPanel: 'bottom', isNative: true, isInstalled: true },
    { id: 'filters', name: 'Visual Filters', description: 'Advanced color-coding rules and regex exclusion patterns.', targetPanel: 'bottom', isNative: true, isInstalled: true },
    { id: 'metadata', name: 'EXIF & Media metadata', description: 'Extraction and batch-stripping of image and video tags.', targetPanel: 'bottom', isNative: true, isInstalled: true },
    { id: 'drop-stack', name: 'Drop Stack', description: 'Temporary staging area for dragging files before batch moving or packing.', targetPanel: 'bottom', isNative: true, isInstalled: true },
    { id: 'batch-rename', name: 'Batch Rename', description: 'Powerful multi-file renaming utility supporting regex, counters, and pattern replacements.', targetPanel: 'bottom', isNative: true, isInstalled: true }
];

interface PluginRegistryContextType {
    pluginRegistry: PluginManifest[];
    togglePluginInstall: (id: string) => void;
    addPluginToRegistry: (plugin: PluginManifest) => void;
}

const PluginRegistryContext = createContext<PluginRegistryContextType>({
    pluginRegistry: [],
    togglePluginInstall: () => {},
    addPluginToRegistry: () => {},
});

export const PluginRegistryProvider = ({ children }: { children: ReactNode }) => {
    const { config, updateConfig } = useAppConfig();

    // Merge default plugins with potentially outdated config.pluginRegistry to ensure built-in ones appear
    const pluginRegistry: PluginManifest[] = (() => {
        let registry: PluginManifest[] = config.pluginRegistry ? [...config.pluginRegistry] : [...defaultPlugins];
        defaultPlugins.forEach(dp => {
            if (!registry.find(p => p.id === dp.id)) {
                registry.push(dp);
            }
        });
        return registry;
    })();

    const togglePluginInstall = (id: string) => {
        const nextRegistry = pluginRegistry.map(p => 
            p.id === id ? { ...p, isInstalled: !p.isInstalled } : p
        );
        updateConfig({ pluginRegistry: nextRegistry });
    };

    const addPluginToRegistry = (plugin: PluginManifest) => {
        if (!pluginRegistry.find(p => p.id === plugin.id)) {
            updateConfig({ pluginRegistry: [...pluginRegistry, plugin] });
        }
    };

    return (
        <PluginRegistryContext.Provider value={{ pluginRegistry, togglePluginInstall, addPluginToRegistry }}>
            {children}
        </PluginRegistryContext.Provider>
    );
};

export const usePluginRegistry = () => useContext(PluginRegistryContext);
