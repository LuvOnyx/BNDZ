import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { IPC } from '../lib/ipcBridge';
import { useModal } from '../components/ModalProvider';
import { FSEntity } from '../types';

export type ClipboardAction = 'copy' | 'cut' | null;

export interface ClipboardPayload {
  action: ClipboardAction;
  sourcePath: string;
  items: { id: string, name: string, path?: string, type: 'file' | 'directory' }[];
}

interface ClipboardContextType {
  clipboard: ClipboardPayload | null;
  setClipboardState: (action: ClipboardAction, sourcePath: string, items: { id: string, name: string, path?: string, type: 'file' | 'directory' }[]) => void;
  executePaste: (targetPath: string) => void;
  clearClipboard: () => void;
}

const ClipboardContext = createContext<ClipboardContextType | undefined>(undefined);

export const useClipboard = () => {
  const context = useContext(ClipboardContext);
  if (!context) {
    throw new Error('useClipboard must be used within a ClipboardProvider');
  }
  return context;
};

export const ClipboardProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [clipboard, setClipboard] = useState<ClipboardPayload | null>(null);

  const setClipboardState = (action: ClipboardAction, sourcePath: string, items: { id: string, name: string, path?: string, type: 'file' | 'directory' }[]) => {
    setClipboard({ action, sourcePath, items });
  };

  const clearClipboard = () => {
    setClipboard(null);
  };

  const executePaste = (targetPath: string) => {
    if (!clipboard || !clipboard.items || clipboard.items.length === 0) return;
    
    // We send this to IPC Bridge which will trigger FileOperationService over the Win32 bridge
    if (clipboard.action === 'copy' || clipboard.action === 'cut') {
         const fullPaths = clipboard.items.map(i => {
           if (i.path) return i.path; // Absolute paths from search maybe
           return `${clipboard.sourcePath}/${i.name}`.replace(/\/\//g, '/');
         });
         
         IPC.executeFsOperation(
           `paste-${Date.now()}`,
           clipboard.action === 'copy' ? 'copy' : 'move',
           fullPaths.length === 1 ? fullPaths[0] : fullPaths,
           targetPath
         );

         if (clipboard.action === 'cut') {
            clearClipboard();
         }
    }
  };

  return (
    <ClipboardContext.Provider value={{ clipboard, setClipboardState, executePaste, clearClipboard }}>
      {children}
    </ClipboardContext.Provider>
  );
};
