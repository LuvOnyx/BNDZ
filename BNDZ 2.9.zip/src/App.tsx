/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import BNDZUI from './components/BNDZUI';
import { ConfigProvider } from './data/configContext';
import { PluginRegistryProvider } from './data/PluginRegistryContext';
import { ModalProvider } from './components/ModalProvider';
import { ClipboardProvider } from './data/ClipboardContext';

export default function App() {
  return (
    <ConfigProvider>
      <PluginRegistryProvider>
        <ModalProvider>
          <ClipboardProvider>
            <div style={{ width: '100vw', height: '100vh', overflow: 'hidden', display: 'flex', flexDirection: 'column', backgroundColor: 'black' }}>
              <BNDZUI />
            </div>
          </ClipboardProvider>
        </ModalProvider>
      </PluginRegistryProvider>
    </ConfigProvider>
  );
}
