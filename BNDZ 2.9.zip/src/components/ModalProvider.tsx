import React, { createContext, useContext, useState, ReactNode } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { AlertTriangle, Info, Trash2 } from "lucide-react";

export type ModalType = "destructive" | "conflict" | "info";

export interface ModalAction {
  label: string;
  action: () => void;
  style?: "primary" | "secondary" | "destructive";
}

export interface ModalPayload {
  type: ModalType;
  title: string;
  message: string | ReactNode;
  icon?: ReactNode;
  actions?: ModalAction[];
}

interface ModalContextType {
  showModal: (payload: ModalPayload) => void;
  hideModal: () => void;
}

const ModalContext = createContext<ModalContextType | undefined>(undefined);

export const useModal = () => {
  const context = useContext(ModalContext);
  if (!context) {
    throw new Error("useModal must be used within a ModalProvider");
  }
  return context;
};

export const ModalProvider: React.FC<{ children: ReactNode }> = ({
  children,
}) => {
  const [modal, setModal] = useState<ModalPayload | null>(null);

  const showModal = (payload: ModalPayload) => setModal(payload);
  const hideModal = () => setModal(null);

  const getIcon = (type: ModalType, customIcon?: ReactNode) => {
    if (customIcon) return customIcon;
    switch (type) {
      case "destructive":
        return (
          <div className="p-4 bg-gradient-to-b from-red-500/20 to-red-500/5 rounded-full border border-red-500/20 mb-2 shadow-[0_0_15px_rgba(239,68,68,0.2)]">
            <Trash2 size={36} className="text-[#FF453A] drop-shadow-lg" />
          </div>
        );
      case "conflict":
        return (
          <div className="p-4 bg-gradient-to-b from-yellow-500/20 to-yellow-500/5 rounded-full border border-yellow-500/20 mb-2 shadow-[0_0_15px_rgba(234,179,8,0.2)]">
            <AlertTriangle
              size={36}
              className="text-[#FFD60A] drop-shadow-lg"
            />
          </div>
        );
      default:
        return (
          <div className="p-4 bg-gradient-to-b from-blue-500/20 to-blue-500/5 rounded-full border border-blue-500/20 mb-2 shadow-[0_0_15px_rgba(59,130,246,0.2)]">
            <Info size={36} className="text-[#0A84FF] drop-shadow-lg" />
          </div>
        );
    }
  };

  return (
    <ModalContext.Provider value={{ showModal, hideModal }}>
      {children}
      <AnimatePresence>
        {modal && (
          <motion.div
            className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/60 backdrop-blur-xl"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15, ease: "easeOut" }}
          >
            <motion.div
              className="bg-black border border-white/10 rounded-2xl shadow-2xl p-6 w-[400px] max-w-[90vw] flex flex-col items-center text-center relative"
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.85, opacity: 0 }}
              transition={{
                type: "spring",
                damping: 22,
                stiffness: 400,
                mass: 0.8,
              }}
            >
              <div className="mb-4">{getIcon(modal.type, modal.icon)}</div>
              <h2 className="text-white text-xl font-semibold mb-2">
                {modal.title}
              </h2>
              <div className="text-gray-400 text-[14px] mb-6 leading-relaxed whitespace-pre-wrap">
                {modal.message}
              </div>

              <div className="flex flex-col w-full gap-2">
                {modal.actions?.map((btn, idx) => (
                  <button
                    key={idx}
                    onClick={(e) => {
                      e.stopPropagation();
                      btn.action();
                      hideModal();
                    }}
                    className={`w-full py-[12px] rounded-xl font-semibold transition-all text-[15px] select-none shadow-sm ${
                      btn.style === "destructive"
                        ? "bg-[#FF3B30] text-white hover:bg-[#FF453A] active:bg-[#D70015]"
                        : btn.style === "primary"
                          ? "bg-[#0A84FF] text-white hover:bg-[#148EFF] active:bg-[#007AFF]"
                          : "bg-[#2C2C2E] text-white hover:bg-[#3A3A3C] active:bg-[#1C1C1E]"
                    }`}
                  >
                    {btn.label}
                  </button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </ModalContext.Provider>
  );
};
