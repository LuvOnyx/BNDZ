import React, { useState } from 'react';
import { Filter, Plus, Trash2, Edit2 } from 'lucide-react';
import { useAppConfig, VisualFilter } from '../../data/configContext';

export default function FiltersPlugin() {
    const { config, updateConfig } = useAppConfig();
    const [editingFilter, setEditingFilter] = useState<VisualFilter | null>(null);

    const visualFilters: VisualFilter[] = config.visualFilters || [];

    const handleSaveRule = (e: React.FormEvent) => {
        e.preventDefault();
        if (editingFilter) {
            const nextFilters = [...visualFilters];
            const existingIndex = nextFilters.findIndex(f => f.id === editingFilter.id);
            if (existingIndex >= 0) {
                nextFilters[existingIndex] = editingFilter;
            } else {
                nextFilters.push(editingFilter);
            }
            updateConfig({ visualFilters: nextFilters });
            setEditingFilter(null);
        }
    };

    const toggleRuleActive = (id: string, active: boolean) => {
        updateConfig({
            visualFilters: visualFilters.map(f => f.id === id ? { ...f, isActive: active } : f)
        });
    };

    const deleteRule = (id: string) => {
        updateConfig({
            visualFilters: visualFilters.filter(f => f.id !== id)
        });
    };

    return (
        <div className="w-full h-full p-4 flex flex-col text-[12px] bg-[#111] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
                <span className="text-[14px] font-bold text-gray-200 flex items-center gap-2"><Filter size={16}/> Visual Filters</span>
                <button onClick={() => setEditingFilter({ id: Date.now().toString(), isActive: true, name: 'New Rule', matchType: 'extension', matchValue: '', hexColor: '#007acc' })} className="flex items-center gap-1 bg-[#222] hover:bg-[#333] border border-[#444] rounded px-3 py-1 text-gray-200">
                    <Plus size={12} /> Create New Rule
                </button>
            </div>
            
            {editingFilter && (
                <form onSubmit={handleSaveRule} className="bg-[#1a1a1a] border border-[#333] p-4 rounded mb-4 flex flex-col gap-3">
                    <div className="flex gap-4">
                        <div className="flex-1 flex flex-col gap-1">
                            <label className="text-gray-400">Rule Name</label>
                            <input type="text" value={editingFilter.name} onChange={e => setEditingFilter({...editingFilter, name: e.target.value})} className="bg-[#222] border border-[#444] rounded px-2 py-1 text-white w-full outline-none focus:border-sky-500" required />
                        </div>
                        <div className="flex flex-col gap-1">
                            <label className="text-gray-400">Match Type</label>
                            <select value={editingFilter.matchType} onChange={e => setEditingFilter({...editingFilter, matchType: e.target.value as any})} className="bg-[#222] border border-[#444] rounded px-2 py-1 text-white outline-none focus:border-sky-500">
                                <option value="extension">Extension</option>
                                <option value="regex">Regex</option>
                                <option value="age">Age (days)</option>
                                <option value="size">Size (MB)</option>
                            </select>
                        </div>
                        <div className="flex-1 flex flex-col gap-1">
                            <label className="text-gray-400">Match Value {editingFilter.matchType === 'age' ? '(e.g. <1, >7)' : editingFilter.matchType === 'size' ? '(e.g. >10)' : ''}</label>
                            <input type="text" value={editingFilter.matchValue} onChange={e => setEditingFilter({...editingFilter, matchValue: e.target.value})} className="bg-[#222] border border-[#444] rounded px-2 py-1 text-white w-full outline-none focus:border-sky-500" required placeholder={editingFilter.matchType === 'extension' ? 'e.g. pdf' : editingFilter.matchType === 'regex' ? 'e.g. ^temp_' : ''} />
                        </div>
                        <div className="flex flex-col gap-1 w-20">
                            <label className="text-gray-400">Color</label>
                            <input type="color" value={editingFilter.hexColor} onChange={e => setEditingFilter({...editingFilter, hexColor: e.target.value})} className="bg-[#222] border border-[#444] p-0 rounded w-full h-[26px] outline-none cursor-pointer" />
                        </div>
                    </div>
                    <div className="flex justify-end gap-2 mt-2">
                        <button type="button" onClick={() => setEditingFilter(null)} className="px-3 py-1 bg-transparent hover:bg-[#333] border border-[#444] rounded text-gray-300">Cancel</button>
                        <button type="submit" className="px-3 py-1 bg-sky-600 hover:bg-sky-500 text-white rounded">Save Rule</button>
                    </div>
                </form>
            )}

            <div className="flex-1 overflow-auto rounded border border-[#222] bg-[#141414]">
                <table className="w-full text-left border-collapse">
                    <thead className="bg-[#1a1a1a] text-gray-400 border-b border-[#2a2a2a] sticky top-0">
                        <tr>
                            <th className="px-3 py-2 font-normal w-12 text-center">Active</th>
                            <th className="px-3 py-2 font-normal">Name</th>
                            <th className="px-3 py-2 font-normal">Type</th>
                            <th className="px-3 py-2 font-normal">Value</th>
                            <th className="px-3 py-2 font-normal">Preview Color</th>
                            <th className="px-3 py-2 font-normal text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-[#2a2a2a]">
                        {visualFilters.map(filter => (
                            <tr key={filter.id} className="hover:bg-[#1a1a1a] group">
                                <td className="px-3 py-2 text-center">
                                    <input type="checkbox" checked={filter.isActive} onChange={(e) => toggleRuleActive(filter.id, e.target.checked)} className="cursor-pointer" />
                                </td>
                                <td className="px-3 py-2 text-gray-200">{filter.name}</td>
                                <td className="px-3 py-2 text-gray-400 capitalize">{filter.matchType}</td>
                                <td className="px-3 py-2 text-gray-400">{filter.matchValue}</td>
                                <td className="px-3 py-2">
                                    <div className="flex items-center gap-2">
                                        <div className="w-4 h-4 rounded-full border border-[#444]" style={{ backgroundColor: filter.hexColor }}></div>
                                        <span style={{ color: filter.hexColor }}>{filter.hexColor}</span>
                                    </div>
                                </td>
                                <td className="px-3 py-2 text-right opacity-0 group-hover:opacity-100 transition-opacity">
                                    <button onClick={() => setEditingFilter(filter)} className="p-1 hover:bg-[#333] rounded text-gray-400 hover:text-white mr-1" title="Edit"><Edit2 size={14} /></button>
                                    <button onClick={() => deleteRule(filter.id)} className="p-1 hover:bg-[#4a1a1a] rounded text-gray-400 hover:text-red-400" title="Delete"><Trash2 size={14} /></button>
                                </td>
                            </tr>
                        ))}
                        {visualFilters.length === 0 && (
                            <tr>
                                <td colSpan={6} className="px-3 py-8 text-center text-gray-500">No visual rules active.</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
