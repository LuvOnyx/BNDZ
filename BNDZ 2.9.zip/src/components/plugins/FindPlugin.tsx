import React, { useState } from 'react';
import { Search, FolderSearch, Settings2, Clock, Calendar, CheckSquare, Square } from 'lucide-react';
import { IPC } from '../../lib/ipcBridge';

export default function FindPlugin({ config, focusedPath, selectedItems }: any) {
    const [query, setQuery] = useState('');
    const [searching, setSearching] = useState(false);
    
    const handleSearch = () => {
        if (!query) return;
        setSearching(true);
        IPC.performGlobalSearch(query, 100).then((res) => {
           setTimeout(() => setSearching(false), 800);
        });
    };

    return (
        <div className="w-full h-full p-4 flex flex-col text-[12px] overflow-hidden">
            <div className="flex justify-between items-center mb-3">
                <span className="text-[14px] font-bold text-gray-200 flex items-center gap-2"><Search size={16} className="text-sky-400" /> Rapid Find (MFT)</span>
                {searching && <span className="text-sky-400 font-mono text-[10px] animate-pulse">Scanning Master File Table...</span>}
            </div>

            <div className="flex gap-4">
                <div className="flex-1 flex flex-col">
                    <label className="text-gray-400 mb-1">Search Query (Regex Supported)</label>
                    <div className="flex bg-[#111] border border-[#333] focus-within:border-sky-500 rounded overflow-hidden">
                        <div className="p-2 text-gray-500"><Search size={14}/></div>
                        <input 
                            type="text" 
                            value={query}
                            onChange={(e) => setQuery(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                            placeholder="*.docx OR report_2026"
                            className="bg-transparent border-none text-white w-full outline-none pr-3" 
                        />
                    </div>
                </div>
                <div className="w-[180px] flex flex-col justify-end">
                     <button onClick={handleSearch} className="h-[34px] bg-[#007acc] hover:bg-[#005c99] rounded text-white font-medium flex items-center justify-center transition-colors">
                        Execute Search
                     </button>
                </div>
            </div>

            <div className="grid grid-cols-3 gap-6 mt-5 flex-1 relative">
                <div className="flex flex-col gap-3">
                     <div className="text-[11px] font-bold text-gray-500 uppercase tracking-wide border-b border-[#333] pb-1">Filters</div>
                     <label className="flex items-center gap-2 text-gray-300 cursor-pointer hover:text-white"><CheckSquare size={14} className="text-sky-500" /> Match Case</label>
                     <label className="flex items-center gap-2 text-gray-300 cursor-pointer hover:text-white"><Square size={14} className="text-gray-500" /> Match Whole Word</label>
                     <label className="flex items-center gap-2 text-gray-300 cursor-pointer hover:text-white"><CheckSquare size={14} className="text-sky-500" /> Use Regular Expressions</label>
                     <label className="flex items-center gap-2 text-gray-300 cursor-pointer hover:text-white"><Square size={14} className="text-gray-500" /> Ignore Hidden Files</label>
                </div>
                
                <div className="flex flex-col gap-3">
                     <div className="text-[11px] font-bold text-gray-500 uppercase tracking-wide border-b border-[#333] pb-1">Location</div>
                     <div className="bg-[#111] border border-[#333] rounded p-2 text-gray-400 break-all select-all flex items-start gap-2">
                         <FolderSearch size={14} className="mt-[2px] shrink-0 text-amber-500" />
                         <span>{focusedPath || 'C:\\'}</span>
                     </div>
                     <label className="flex items-center gap-2 text-gray-300 cursor-pointer hover:text-white mt-1"><CheckSquare size={14} className="text-sky-500" /> Include Subdirectories</label>
                </div>

                <div className="flex flex-col gap-3">
                     <div className="text-[11px] font-bold text-gray-500 uppercase tracking-wide border-b border-[#333] pb-1">Metadata Bounds</div>
                     <div className="flex items-center gap-2 text-gray-300"><Calendar size={14} className="text-gray-500" /> Modified: Any Time</div>
                     <div className="flex items-center gap-2 text-gray-300"><Clock size={14} className="text-gray-500" /> Size: Any</div>
                </div>
            </div>
        </div>
    );
}
