import React, { useState, useEffect } from 'react';
import { Database } from 'lucide-react';
import { IPC } from '../../lib/ipcBridge';

export default function MetadataPlugin({ entity, focusedPath }: any) {
    const [metadata, setMetadata] = useState<Record<string, string> | null>(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (entity && entity.type !== 'directory') {
            setLoading(true);
            const fullPath = entity.path || `${focusedPath}/${entity.name}`;
            IPC.getExtendedMetadata(fullPath).then(meta => {
                setMetadata(meta);
            }).finally(() => {
                setLoading(false);
            });
        } else {
            setMetadata(null);
        }
    }, [entity, focusedPath]);

    return (
        <div className="w-full h-full p-4 flex flex-col text-[12px] bg-[#111]">
            <div className="flex justify-between items-center mb-4">
                <span className="text-[13px] font-bold text-gray-200 flex items-center gap-2"><Database size={14}/> System Metadata Engine</span>
            </div>
            
            <div className="flex-1 overflow-y-auto">
                {!entity ? (
                    <div className="flex items-center justify-center h-full text-gray-500 italic">Select a file to view deep metadata</div>
                ) : entity.type === 'directory' ? (
                    <div className="flex items-center justify-center h-full text-gray-500 italic">Extended metadata only available for files</div>
                ) : loading ? (
                    <div className="flex items-center justify-center h-full text-sky-500">Querying Native Shell...</div>
                ) : metadata && Object.keys(metadata).length > 0 ? (
                    <div className="grid grid-cols-2 gap-px bg-[#333] border border-[#333]">
                        {Object.entries(metadata).map(([key, value]) => (
                            <React.Fragment key={key}>
                                <div className="bg-[#1a1a1a] p-2 text-gray-400 font-medium">{key}</div>
                                <div className="bg-[#111] p-2 text-gray-200 break-all">{value}</div>
                            </React.Fragment>
                        ))}
                    </div>
                ) : (
                    <div className="flex items-center justify-center h-full text-gray-500 italic">No extended metadata available for this file type</div>
                )}
            </div>
        </div>
    );
}
