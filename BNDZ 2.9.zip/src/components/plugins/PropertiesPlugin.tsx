import React, { useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { Check, Settings, HardDrive, File as FileIcon } from 'lucide-react';
import { FSEntity } from '../../types';

export default function PropertiesPlugin({ entity, config, drives = [], focusedPath = "" }: { entity: FSEntity | null, config: any, drives?: any[], focusedPath?: string }) {
    const data = useMemo(() => [
        { name: 'Mon', accesses: 1530 },
        { name: 'Tue', accesses: 2100 },
        { name: 'Wed', accesses: 800 },
        { name: 'Thu', accesses: 3400 },
        { name: 'Fri', accesses: 4367 },
        { name: 'Sat', accesses: 121 },
        { name: 'Sun', accesses: 450 },
    ], []);

    const driveInfo = useMemo(() => {
       return drives.find(d => d.name === focusedPath || d.name === focusedPath + '/');
    }, [drives, focusedPath]);

    const formatSize = (bytes: number) => {
        if (bytes === 0) return "0 B";
        const k = 1024, sizes = ["B", "KB", "MB", "GB", "TB"];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
    };

    const allocationData = useMemo(() => {
        if (driveInfo) {
            return [
                { name: 'Used Space', value: driveInfo.totalSpace - driveInfo.freeSpace, color: '#0ea5e9' },
                { name: 'Free Space', value: driveInfo.freeSpace, color: '#333333' }
            ];
        } else if (entity && entity.type === 'directory' && entity.children) {
            // Group by extension or just files vs folders if children size is not populated
            let filesSize = 0;
            let dirsCount = 0;
            Object.values(entity.children).forEach((child: any) => {
                if (child.type === 'file') filesSize += child.size || 0;
                else dirsCount++;
            });
            if (filesSize === 0) return [{ name: 'Empty / Uncalculated', value: 1, color: '#333' }];
            return [
                { name: 'Contained Files', value: filesSize, color: '#0ea5e9' },
                { name: 'Other', value: filesSize * 0.1, color: '#555' } // mock buffer
            ];
        } else if (entity && entity.type === 'file') {
            return [
                { name: 'File Size', value: (entity as any).size || 0, color: '#0ea5e9' },
                { name: 'Remaining Block', value: 4096 - (((entity as any).size || 0) % 4096), color: '#333333' } // cluster slack mock
            ];
        }
        return [
            { name: 'Used', value: 40, color: '#0ea5e9' },
            { name: 'Free', value: 60, color: '#333333' }
        ];
    }, [driveInfo, entity]);

    return (
        <div className="flex-1 w-full flex gap-6 p-4">
            <div className="w-[30%] min-w-[300px] flex flex-col gap-4">
                {/* General / Security / Detailed Stats Tables */}
                <div className="border border-[#333] rounded-[4px] bg-[#181818] overflow-hidden shadow-inner flex shrink-0 flex-col">
                <div className="bg-[#222] px-2 py-1.5 flex justify-between items-center text-[11px] font-bold uppercase tracking-wider text-gray-300 border-b border-[#333]">
                    <div className="flex items-center"><span className="mr-2 text-[8px]">▲</span> General</div>
                    <button 
                        className="px-2 py-0.5 bg-[#333] hover:bg-[#444] rounded text-white flex items-center gap-1 transition-colors cursor-pointer"
                        onClick={(e) => {
                            e.stopPropagation();
                            if (focusedPath) {
                                import('../../lib/ipcBridge').then(({ IPC }) => {
                                    IPC.shellExecute('properties', focusedPath);
                                });
                            }
                        }}
                    >
                        <Settings size={10} /> Native
                    </button>
                </div>
                <div className="p-3 text-[12px] grid grid-cols-[100px_1fr] gap-x-2 gap-y-2 text-gray-400">
                    <div>Type</div><div className="text-white">{driveInfo ? 'Local Disk' : (entity?.type === 'directory' ? 'File Folder' : 'File')}</div>
                    <div>Location</div><div className="text-white">{driveInfo ? driveInfo.name : (focusedPath || '--')}</div>
                    {driveInfo && (
                       <>
                           <div>File System</div><div className="text-white">{driveInfo.fileSystem || 'NTFS'}</div>
                       </>
                    )}
                    {!driveInfo && (
                        <>
                            <div>Creation Date</div><div className="text-white">{entity?.created ? new Date(entity.created).toLocaleString(undefined, {year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit'}) : '01/15/2026 11:23 PM'}</div>
                            <div>Modified Date</div><div className="text-white">{entity?.modified ? new Date(entity.modified).toLocaleString(undefined, {year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit'}) : '05/31/2026 09:40 PM'}</div>
                        </>
                    )}
                </div>
                </div>
                <div className="border border-[#333] rounded-[4px] bg-[#181818] overflow-hidden shadow-inner flex shrink-0 flex-col">
                <div className="bg-[#222] px-2 py-1.5 flex items-center text-[11px] font-bold uppercase tracking-wider text-gray-300 border-b border-[#333]">
                    <span className="mr-2 text-[8px]">▲</span> Security
                </div>
                <div className="p-2">
                    <table className="w-full text-[11px] text-left text-gray-400 border-collapse">
                        <thead>
                            <tr className="border-b border-[#333]">
                            <th className="pb-1.5 font-medium">Owner</th>
                            <th className="pb-1.5 font-medium" colSpan={4}>System</th>
                            </tr>
                            <tr className="border-b border-[#333]">
                            <th className="py-2 text-[10px] uppercase font-bold text-gray-500 tracking-tight">Permissions Grid</th>
                            <th className="py-2 text-[10px] uppercase font-bold text-gray-500 text-center tracking-tight">Read</th>
                            <th className="py-2 text-[10px] uppercase font-bold text-gray-500 text-center tracking-tight">Write</th>
                            <th className="py-2 text-[10px] uppercase font-bold text-gray-500 text-center tracking-tight">Hidden</th>
                            <th className="py-2 text-[10px] uppercase font-bold text-gray-500 text-center tracking-tight">Manage</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                            <td className="py-2">System</td>
                            <td className="py-2 text-center"><div className="w-[14px] h-[14px] rounded-[2px] bg-sky-500/20 border border-sky-500 mx-auto flex items-center justify-center"><Check size={10} className="text-sky-400" /></div></td>
                            <td className="py-2 text-center"><div className="w-[14px] h-[14px] rounded-[2px] bg-transparent border border-[#555] mx-auto"></div></td>
                            <td className="py-2 text-center"><div className="w-[14px] h-[14px] rounded-[2px] bg-sky-500/20 border border-sky-500 mx-auto flex items-center justify-center"><Check size={10} className="text-sky-400" /></div></td>
                            <td className="py-2 text-center"><div className="w-[14px] h-[14px] rounded-[2px] bg-sky-500/20 border border-sky-500 mx-auto flex items-center justify-center"><Check size={10} className="text-sky-400" /></div></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                </div>
            </div>

            <div className="w-[30%] min-w-[300px] flex flex-col gap-4">
                <div className="border border-[#333] rounded-[4px] bg-[#181818] overflow-hidden shadow-inner flex shrink-0 flex-col">
                <div className="bg-[#222] px-2 py-1.5 flex items-center text-[11px] font-bold uppercase tracking-wider text-gray-300 border-b border-[#333]">
                    <span className="mr-2 text-[8px]">▲</span> Detailed Stats
                </div>
                <div className="p-3 text-[12px] grid grid-cols-[100px_1fr] gap-x-2 gap-y-2 text-gray-400">
                    {driveInfo ? (
                        <>
                            <div>Total Space</div><div className="text-white">{formatSize(driveInfo.totalSpace)}</div>
                            <div>Used Space</div><div className="text-white">{formatSize(driveInfo.totalSpace - driveInfo.freeSpace)}</div>
                            <div>Free Space</div><div className="text-white">{formatSize(driveInfo.freeSpace)}</div>
                        </>
                    ) : (
                        <>
                            <div>Size on disk</div><div className="text-white">{(entity as any)?.size != null ? formatSize((entity as any)?.size) : '4.20 GB'}</div>
                            <div>Total Files</div><div className="text-white">4,587</div>
                            <div>Total Folders</div><div className="text-white">125</div>
                        </>
                    )}
                </div>
                </div>

                <div className="border border-[#333] rounded-[4px] bg-[#181818] overflow-hidden flex-1 relative flex flex-col p-3 shadow-inner">
                    <div className="text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-3 ml-1">Security Attributes</div>
                    <div className="grid grid-cols-2 gap-x-12 gap-y-3 px-1 mt-1">
                    <div className="flex items-center justify-between text-[11px]"><span className="text-gray-300">System</span><div className="w-8 h-[16px] rounded-full bg-[#333] border border-[#555] relative"><div className="absolute left-[1px] top-[1px] w-3 h-3 rounded-full bg-gray-500"></div></div></div>
                    <div className="flex items-center justify-between text-[11px]"><span className="text-gray-300">Read/Write</span><div className="w-8 h-[16px] rounded-full bg-sky-600/50 border border-sky-500 relative"><div className="absolute right-[1px] top-[1px] w-3 h-3 rounded-full bg-sky-400"></div></div></div>
                    <div className="flex items-center justify-between text-[11px]"><span className="text-gray-300">Full Control</span><div className="w-8 h-[16px] rounded-full bg-[#333] border border-[#555] relative"><div className="absolute left-[1px] top-[1px] w-3 h-3 rounded-full bg-gray-500"></div></div></div>
                    <div className="flex items-center justify-between text-[11px]"><span className="text-gray-300">Restricted</span><div className="w-8 h-[16px] rounded-full bg-[#333] border border-[#555] relative"><div className="absolute left-[1px] top-[1px] w-3 h-3 rounded-full bg-gray-500"></div></div></div>
                    </div>
                </div>
            </div>
            
            <div className="flex-1 min-w-[200px] flex flex-col gap-4">
                <div className="border border-[#333] rounded-[4px] bg-[#181818] overflow-hidden flex-1 relative p-3 shadow-inner flex flex-col">
                <div className="text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-2 ml-1">Access Time</div>
                <div className="w-full flex-1 relative mt-2 text-white">
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                            <defs>
                                <linearGradient id="colorAccesses" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.8}/>
                                    <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0}/>
                                </linearGradient>
                            </defs>
                            <XAxis dataKey="name" stroke="#555" tick={{ fill: '#888', fontSize: 10 }} tickLine={false} axisLine={true} />
                            <YAxis stroke="#555" tick={{ fill: '#888', fontSize: 10 }} tickLine={false} axisLine={true} />
                            <Tooltip contentStyle={{ backgroundColor: '#222', border: '1px solid #444', borderRadius: '4px', fontSize: '11px', color: '#fff' }} />
                            <Area type="monotone" dataKey="accesses" stroke="#0ea5e9" fillOpacity={1} fill="url(#colorAccesses)" />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
                </div>
            </div>
        </div>
    );
}
