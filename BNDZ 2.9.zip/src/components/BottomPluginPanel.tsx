import React, { useState, Suspense, useEffect } from 'react';
import { Settings, Search, Filter, Database, Check, X, Plus, Puzzle, Layers, Replace } from 'lucide-react';
import { FSEntity } from '../types';
import { usePluginRegistry } from '../data/PluginRegistryContext';
import { PluginStoreDialog } from './PluginStoreDialog';
import { DialogTrigger } from './ui/dialog';

// Lazy loaded plugins
const PropertiesPlugin = React.lazy(() => import('./plugins/PropertiesPlugin'));
const FindPlugin = React.lazy(() => import('./plugins/FindPlugin'));
const FiltersPlugin = React.lazy(() => import('./plugins/FiltersPlugin'));
const MetadataPlugin = React.lazy(() => import('./plugins/MetadataPlugin'));
const DropStackPlugin = React.lazy(() => import('./plugins/DropStackPlugin'));
const BatchRenamePlugin = React.lazy(() => import('./plugins/BatchRenamePlugin'));

// Hardcoded components map for now since dynamically downloaded components need eval.
const builtinComponents: Record<string, React.LazyExoticComponent<any>> = {
   'properties': PropertiesPlugin,
   'find': FindPlugin,
   'filters': FiltersPlugin,
   'metadata': MetadataPlugin,
   'drop-stack': DropStackPlugin,
   'batch-rename': BatchRenamePlugin,
};

export default function BottomPluginPanel({ entity, config, drives = [], focusedPath = "", selectedItems = [], onFilterChange }: { entity: FSEntity | null, config: any, drives?: any[], focusedPath?: string, selectedItems?: string[], onFilterChange?: (filters: any) => void }) {
   const { pluginRegistry } = usePluginRegistry();
   const [activeTab, setActiveTab] = useState('properties');

   // Fallback to first installed if active is uninstalled
   useEffect(() => {
      const activeObj = pluginRegistry.find(p => p.id === activeTab && p.targetPanel === 'bottom');
      if (!activeObj || !activeObj.isInstalled) {
         const firstInstalled = pluginRegistry.find(p => p.isInstalled && p.targetPanel === 'bottom');
         if (firstInstalled) setActiveTab(firstInstalled.id);
      }
   }, [pluginRegistry, activeTab]);

   const installedBottomPlugins = pluginRegistry.filter(p => p.targetPanel === 'bottom' && p.isInstalled);

   const renderPluginContent = () => {
      const pluginManifest = pluginRegistry.find(p => p.id === activeTab);
      if (!pluginManifest) return null;

      if (!pluginManifest.isInstalled) {
         return (
            <div className="flex-1 flex flex-col items-center justify-center text-[#555] font-sans text-[13px] bg-[#181818] border border-[#333] rounded-[4px] shadow-inner relative">
               <div className="w-[80px] h-[80px] border border-[#333] rounded-full flex items-center justify-center mb-4 bg-[#111]">
                  <Puzzle size={24} className="text-[#444]" />
               </div>
               <span className="text-gray-400 font-bold tracking-tight mb-1 text-[16px]">Module "{pluginManifest.name}" Offline</span>
               <span className="text-[12px] text-[#555]">This plugin module is unloaded in the store.</span>
            </div>
         );
      }

      const PluginComponent = builtinComponents[pluginManifest.id] as React.ElementType;
      if (!PluginComponent) {
         return (
            <div className="flex-1 p-4 flex items-center justify-center text-red-500 text-xs">
               Component not found for {pluginManifest.id}
            </div>
         );
      }

      return (
         <Suspense fallback={<div className="flex-1 p-4 flex items-center justify-center text-gray-500 text-xs">Loading {pluginManifest.name}...</div>}>
            <PluginComponent entity={entity} config={config} drives={drives} focusedPath={focusedPath} selectedItems={selectedItems} onFilterChange={onFilterChange} />
         </Suspense>
      );
   };

   return (
      <div className="w-full h-full bg-[#181818] flex flex-col border-t border-[#333] shadow-[0_-4px_15px_rgba(0,0,0,0.4)] text-[#e0e0e0] select-none rounded-t-lg">
         {/* Tabs */}
         <div className="flex bg-[#0a0a0a] border-b border-[#333] justify-between items-center pr-2 shrink-0 h-[32px]">
            <div className="flex h-full overflow-x-auto no-scrollbar styled-scrollbar">
               {installedBottomPlugins.map((tab) => {
                  // Dynamically resolve icon if from a built-in map, otherwise use default Layers
                  const builtinInfo = [
                     { id: 'properties', icon: Settings },
                     { id: 'find', icon: Search },
                     { id: 'filters', icon: Filter },
                     { id: 'metadata', icon: Database },
                     { id: 'drop-stack', icon: Layers },
                     { id: 'batch-rename', icon: Replace },
                  ].find(b => b.id === tab.id);
                  const Icon = builtinInfo?.icon || Layers;

                  return (
                     <div 
                        key={tab.id}
                        className={`flex items-center gap-2 px-4 h-full text-[12px] cursor-pointer border-t-[3px] transition-colors group relative ${
                           activeTab === tab.id 
                              ? 'border-t-sky-500 bg-[#151515] text-white' 
                              : 'border-t-transparent text-gray-400 hover:text-white hover:bg-[#222]'
                        }`}
                        onClick={() => setActiveTab(tab.id)}
                     >
                        <Icon size={12} />
                        <span>{tab.name}</span>
                     </div>
                  );
               })}
               {installedBottomPlugins.length === 0 && (
                  <div className="px-4 py-1.5 text-[12px] text-gray-500 italic">No plugins installed</div>
               )}
            </div>
            
            <div className="flex gap-2 shrink-0">
               <PluginStoreDialog>
                  <DialogTrigger render={
                     <button className="flex items-center gap-1.5 px-2 py-0.5 text-[11px] rounded-sm transition-colors border bg-[#222] text-gray-400 border-[#333] hover:text-white hover:bg-[#333]">
                        <Plus size={12} /> Plugin Marketplace
                     </button>
                  } />
               </PluginStoreDialog>
            </div>
         </div>
         
         {/* Content */}
         <div className="flex-1 overflow-y-auto p-0 flex gap-6 min-h-0 bg-[#111] styled-scrollbar">
            {renderPluginContent()}
         </div>
      </div>
   );
}
