import React, { useState, useMemo, useEffect, useRef } from 'react';
import { 
  ArrowLeft, ArrowRight, ArrowUp, Monitor, FolderSearch, File, 
  Scissors, Copy, Clipboard, Undo, Redo, Search, RefreshCw, 
  Filter, Settings, Wrench, Menu, HardDrive, Network,
  FolderOpen, Server, Star, Tag, Database, PlayCircle, Folder, ArrowDownCircle, Sparkles, Wand2, Columns, X, AlertTriangle, Archive, Trash2, Eye, FileText, ChevronDown, ChevronRight, PanelBottom } from 'lucide-react';
import Fuse from 'fuse.js';
import { createInitialFileSystem, getDirContents, getEntityByPath, updateFileSystem } from '../data/initialFS';
import { VirtualDirectory, FSEntity, DriveInfo, ShortcutInfo } from '../types';
import { useModal } from './ModalProvider';
import { useClipboard } from '../data/ClipboardContext';
import SmartToolsDialog from './SmartToolsDialog';
import RightPreviewPanel from './RightPreviewPanel';
import BottomPluginPanel from './BottomPluginPanel';
import { LeftSidebar } from './LeftSidebar';
import { ThumbnailIcon } from './ThumbnailIcon';
import ToolbarConfigurator, { AVAILABLE_ITEMS } from './ToolbarConfigurator';
import ConfigurationDialog from './ConfigurationDialog';
import CommandPalette from './CommandPalette';
import { RenameOperation } from '../lib/ipcBridge';
import { useAppConfig, VisualFilter } from '../data/configContext';
import { motion, AnimatePresence } from 'framer-motion';

const applyVisualFilters = (entity: any, filters?: VisualFilter[]): string | null => {
    if (!filters || !filters.length) return null;
    const now = Date.now();
    for (const rule of filters) {
        if (!rule.isActive) continue;
        
        switch (rule.matchType) {
            case 'extension':
                if (entity.extension && entity.extension.toLowerCase() === rule.matchValue.toLowerCase().replace('.', '')) {
                    return rule.hexColor;
                }
                break;
            case 'regex':
                try {
                    const regex = new RegExp(rule.matchValue, 'i');
                    if (regex.test(entity.name)) return rule.hexColor;
                } catch { }
                break;
            case 'size':
                if (entity.type !== 'directory') {
                    const sizeMB = entity.size / (1024 * 1024);
                    const val = parseFloat(rule.matchValue.replace(/[^0-9.]/g, ''));
                    if (!isNaN(val)) {
                        if (rule.matchValue.includes('>') && sizeMB > val) return rule.hexColor;
                        if (rule.matchValue.includes('<') && sizeMB < val) return rule.hexColor;
                    }
                }
                break;
            case 'age':
                if (entity.modified) {
                    const fileTime = new Date(entity.modified).getTime();
                    const daysDiff = (now - fileTime) / (1000 * 3600 * 24);
                    const ageVal = parseFloat(rule.matchValue.replace(/[^0-9.]/g, ''));
                    if (!isNaN(ageVal)) {
                        if (rule.matchValue.includes('>') && daysDiff > ageVal) return rule.hexColor;
                        if (rule.matchValue.includes('<') && daysDiff < ageVal) return rule.hexColor;
                    }
                }
                break;
        }
    }
    return null;
};
import { ResizablePanel, ResizablePanelGroup, ResizableHandle } from "./ui/resizable";

const ToolbarButton = ({ icon: Icon, icon3d, color, onClick, className = '', title }: any) => {
  const [imgError, setImgError] = React.useState(false);
  return (
    <button title={title} className={`p-[4px] hover:bg-[#333] rounded mx-[1px] flex items-center justify-center ${className}`} onClick={onClick}>
      {icon3d && !imgError ? (
        <img src={icon3d} alt={title} className="w-5 h-5 object-contain drop-shadow-md pointer-events-none" onError={() => setImgError(true)} />
      ) : (
        <Icon size={16} color={color || "#ccc"} />
      )}
    </button>
  );
};

const TreeItem = ({ label, icon: Icon, iconColor, indent = 0, selected = false, expanded = false, childrenItems = [], onClick, onToggle, isDynamic, path, currentPath, config, onContextMenuClick, inlineRename = null, setInlineRename }: any) => {
  const [dynExpanded, setDynExpanded] = useState(false);
  const [dynChildren, setDynChildren] = useState<any[] | null>(null);

  const isExpanded = isDynamic ? dynExpanded : expanded;
  const childList = isDynamic ? (dynChildren || []) : childrenItems;

  const handleToggle = () => {
    if (isDynamic) {
        const next = !dynExpanded;
        setDynExpanded(next);
        if (next && !dynChildren) {
             import('../lib/ipcBridge').then(({ IPC }) => {
                 IPC.getSubDirectories(path, config?.showHiddenSystemFoldersInTree).then(dirs => {
                     setDynChildren(dirs.sort((a,b) => a.name.localeCompare(b.name)));
                 });
             });
        }
    } else {
        onToggle?.();
    }
  };

  const handleContext = (e: React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      if (!config?.useCustomContextMenu && path) {
          import('../lib/ipcBridge').then(({ IPC }) => {
              IPC.showNativeContextMenu(path, e.screenX, e.screenY);
          });
      } else if (onContextMenuClick) {
          onContextMenuClick(e, path, label);
      }
  };

  const isRenaming = inlineRename?.entityId === 'TREE' && inlineRename?.path === path;

  return (
    <div>
      <div 
        className={`flex items-center py-[2px] px-1 cursor-pointer whitespace-nowrap ${selected || (isDynamic && currentPath === path) ? 'bg-[#264f78]' : 'hover:bg-[#2a2d2e]'}`} 
        style={{ paddingLeft: `${indent * 12 + 4}px` }}
        onClick={(e) => { 
            e.stopPropagation(); 
            if (isDynamic) onClick?.(path); else onClick?.(); 
            // Delayed double click for inline rename on tree node
            if (currentPath === path && !e.ctrlKey && !e.shiftKey) {
                setTimeout(() => {
                    setInlineRename?.({ path, entityId: 'TREE', currentName: label });
                }, 500);
            }
        }}
        onDoubleClick={(e) => { e.stopPropagation(); handleToggle(); }}
        onContextMenu={handleContext}
      >
        {(childList.length > 0 || isDynamic) ? (
          <span 
            className="w-3 text-gray-500 text-[10px] mr-[2px] flex justify-center hover:text-white"
            onClick={(e) => { e.stopPropagation(); handleToggle(); }}
          >
            {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
          </span>
        ) : (
          <span className="w-3 mr-[2px] flex justify-center"></span>
        )}
        {Icon && <Icon size={14} color={iconColor || "#dcb67a"} className="mr-[6px] shrink-0" />}
        {isRenaming ? (
            <input 
               type="text"
               autoFocus
               className="bg-[#111] text-white border border-[#007acc] px-1 outline-none text-[12px] w-[140px]"
               value={inlineRename.currentName}
               onChange={e => setInlineRename?.({ ...inlineRename, currentName: e.target.value })}
               onBlur={() => {
                   if (inlineRename.currentName !== label) {
                       const parentPath = path.substring(0, path.lastIndexOf('/'));
                       import('../lib/ipcBridge').then(({ IPC }) => IPC.executeFsOperation(`rename-${Date.now()}`, 'move', path, `${parentPath}/${inlineRename.currentName}`));
                   }
                   setInlineRename?.(null);
               }}
               onKeyDown={e => {
                   if (e.key === 'Enter') e.currentTarget.blur();
                   else if (e.key === 'Escape') setInlineRename?.(null);
               }}
               onClick={e => e.stopPropagation()}
               onDoubleClick={e => e.stopPropagation()}
            />
        ) : (
            <span className="text-[12px] select-none">{label}</span>
        )}
      </div>
      {isExpanded && childList && childList.map((child: any, i: number) => (
        <TreeItem 
            key={isDynamic ? child.path : i} 
            {...child} 
            label={isDynamic ? child.name : child.label}
            icon={Folder}
            iconColor="#dcb67a"
            indent={indent + 1} 
            isDynamic={isDynamic}
            path={isDynamic ? child.path : undefined}
            currentPath={currentPath}
            config={config}
            onClick={onClick}
            onContextMenuClick={onContextMenuClick}
            inlineRename={inlineRename}
            setInlineRename={setInlineRename}
        />
      ))}
    </div>
  );
};

function formatSize(bytes: number) {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}

interface TabState {
  id: string;
  path: string;
  history: string[];
  historyIndex: number;
  selectedItems: string[];
  viewMode?: 'details' | 'grid' | 'list';
}

interface PaneState {
  id: string;
  tabs: TabState[];
  activeTabIndex: number;
  sortColumn?: 'name' | 'type' | 'size' | 'modified';
  sortDirection?: 'asc' | 'desc';
  filterRegex?: string;
}

const Spinner = () => (
  <div className="flex justify-center items-center w-full h-full p-4 relative min-w-[50px] min-h-[50px]">
    <div className="w-[40px] h-[40px] border-[3.5px] border-[#333] rounded-full absolute" />
    <div className="w-[40px] h-[40px] border-[3.5px] border-transparent border-t-[#22c55e] border-r-[#22c55e] rounded-full animate-[spin_1s_cubic-bezier(0.5,0,0.5,1)_infinite] absolute" />
    <div className="w-[40px] h-[40px] border-[3.5px] border-transparent border-b-[#22c55e] border-l-[#22c55e] rounded-full animate-[spin_1.5s_cubic-bezier(0.5,0,0.5,1)_infinite_reverse] absolute opacity-70" />
  </div>
);

const Toast = ({ message, onClose }: { message: string, onClose: () => void }) => {
  useEffect(() => {
    const timer = setTimeout(onClose, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed bottom-6 right-6 bg-[#1e1e20] overflow-hidden shadow-[0_8px_30px_rgba(0,0,0,0.8)] border border-[#333] rounded-[8px] p-4 pr-10 flex flex-col gap-1 z-[100] animate-[slide-in-right_0.4s_cubic-bezier(0,0.5,0.2,1)_forwards] select-none">
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center p-[6px] bg-green-500/10 rounded-full text-green-400">
           <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7"></path></svg>
        </div>
        <div className="flex flex-col pr-2">
           <span className="text-[14px] font-semibold text-gray-100 leading-none">Success</span>
           <span className="text-[12px] text-gray-400 pt-[4px]">{message}</span>
        </div>
        <button onClick={onClose} className="absolute right-3 top-3 text-gray-500 hover:text-gray-300 transition-colors pointer-events-auto cursor-pointer"><X size={14} /></button>
      </div>
      <div className="absolute bottom-0 left-0 h-[3px] bg-green-500/80" style={{ width: '100%', transformOrigin: 'left', animation: 'progress 3s linear forwards' }} />
    </div>
  );
};

export default function BNDZUI() {
  const { showModal } = useModal();
  const { clipboard, setClipboardState, executePaste } = useClipboard();
  const { config, updateConfig } = useAppConfig();
  const [isSaveTabsetOpen, setIsSaveTabsetOpen] = useState(false);
  const [tabsetNameInput, setTabsetNameInput] = useState('');
  const [isLoadTabsetOpen, setIsLoadTabsetOpen] = useState(false);
  const [marquee, setMarquee] = useState<{ activePane: string, startX: number, startY: number, currX: number, currY: number } | null>(null);
  const [drives, setDrives] = useState<DriveInfo[]>([]);
  const [shortcuts, setShortcuts] = useState<ShortcutInfo[]>([]);
  const [fileSystem, setFileSystem] = useState<VirtualDirectory>(() => createInitialFileSystem());
  const [isSyncMode, setIsSyncMode] = useState(false);
  const [syncResults, setSyncResults] = useState<{ [path: string]: { id: string, statusA?: string, statusB?: string, status?: string } }>({});
  const [isSyncing, setIsSyncing] = useState(false);

  useEffect(() => {
    let unsubDrives: (() => void) | undefined;
    import('../lib/ipcBridge').then(({ IPC }) => {
      IPC.getSystemDrives().then(setDrives);
      IPC.getSystemShortcuts().then(setShortcuts);
      unsubDrives = IPC.onDrivesChanged((newDrives) => {
          setDrives(newDrives);
      });
    });
    return () => { if (unsubDrives) unsubDrives(); };
  }, []);

  const [expandedPaths, setExpandedPaths] = useState<Set<string>>(new Set(["/C:", "/C:/Users", "/C:/Users/Developer"]));
  const [isSmartToolsOpen, setIsSmartToolsOpen] = useState(false);
  const [isPreviewPanelOpen, setIsPreviewPanelOpen] = useState(false);
  const [isBottomPanelOpen, setIsBottomPanelOpen] = useState(true);
  const [isToolbarConfigOpen, setIsToolbarConfigOpen] = useState(false);
  const [isConfigDialogOpen, setIsConfigDialogOpen] = useState(false);
  const [inlineRename, setInlineRename] = useState<{ path: string, entityId: string, currentName: string } | null>(null);
  const [lastClickData, setLastClickData] = useState<{ id: string, time: number } | null>(null);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [editingAddressBarPaneId, setEditingAddressBarPaneId] = useState<string | null>(null);
  const [addressBarInput, setAddressBarInput] = useState<string>('');
  
  // Dual Pane Architecture state
  const [isDualPane, setIsDualPane] = useState(false);
  const [pathContentsCache, setPathContentsCache] = useState<Record<string, any[]>>({});

  const [panes, setPanes] = useState<PaneState[]>([
     { 
       id: 'pane1', 
       tabs: [{ id: 't1', path: '/C:/Users/Developer/BNDZ_CSharp_Windows_App', history: ['/C:/Users/Developer/BNDZ_CSharp_Windows_App'], historyIndex: 0, selectedItems: [], viewMode: config.defaultViewMode || 'details' }],
       activeTabIndex: 0,
       sortColumn: 'name',
       sortDirection: 'asc'
     }
  ]);

  useEffect(() => {
     import('../lib/ipcBridge').then(({ IPC }) => {
         panes.forEach(pane => {
             const tab = pane.tabs[pane.activeTabIndex];
             if (tab && tab.path && tab.path !== '/' && tab.path !== '/C:' && tab.path !== '/D:') {
                 if (!pathContentsCache[tab.path]) {
                     IPC.getDirContents(tab.path).then(data => {
                         if (data && data.length > 0) {
                             setPathContentsCache(prev => ({ ...prev, [tab.path]: data }));
                         }
                     });
                 }
             }
         });
     });
  }, [panes, pathContentsCache]);

  const safeGetDirContents = (fs: any, path: string) => {
      if (pathContentsCache[path]) return pathContentsCache[path];
      return getDirContents(fs, path);
  };

  const [activePaneId, setActivePaneId] = useState('pane1');
  const [focusedItemId, setFocusedItemId] = useState<string | null>(null);

  // File Operations State
  const [transferProgress, setTransferProgress] = useState<{ [opId: string]: { percentage: number, file: string, bytesTransferred: number, totalBytes: number, speedBytesPerSecond: number, itemsCompleted: number, totalItems: number } }>({});
  const [conflict, setConflict] = useState<{ opId: string, fileName: string, srcPath: string, destPath: string } | null>(null);

  // Omni-Filter State
  const [filterText, setFilterText] = useState("");
  const [globalSearchResults, setGlobalSearchResults] = useState<any[] | null>(null);
  const [isGlobalSearchLoading, setIsGlobalSearchLoading] = useState(false);
  const omniFilterRef = useRef<HTMLInputElement>(null);

  // Trigger Global Search
  useEffect(() => {
     if (config.enableGlobalSearchPrefix && filterText.trimStart().startsWith('> ')) {
         const query = filterText.trimStart().substring(2).trim();
         if (query.length > 0) {
             setIsGlobalSearchLoading(true);
             const timer = setTimeout(() => {
                 import('../lib/ipcBridge').then(({ IPC }) => {
                     IPC.performGlobalSearch(query, config.globalSearchLimit || 1000).then(results => {
                         setGlobalSearchResults(results);
                         setIsGlobalSearchLoading(false);
                     });
                 });
             }, 300);
             return () => clearTimeout(timer);
         } else {
             setGlobalSearchResults(null);
             setIsGlobalSearchLoading(false);
         }
     } else {
         setGlobalSearchResults(null);
         setIsGlobalSearchLoading(false);
     }
  }, [filterText, config.enableGlobalSearchPrefix, config.globalSearchLimit]);

  // Focus trap for F2 rename shortcut
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isInput = e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement;

      if (e.key === 'p' && e.ctrlKey && e.shiftKey) {
         e.preventDefault();
         setIsCommandPaletteOpen(prev => !prev);
      }
      if (e.key === 'z' && e.ctrlKey && !e.shiftKey && !isInput) {
         e.preventDefault();
         import('../lib/ipcBridge').then(({ IPC }) => IPC.executeUndo());
      }
      if (((e.key === 'y' && e.ctrlKey) || (e.key === 'z' && e.ctrlKey && e.shiftKey)) && !isInput) {
         e.preventDefault();
         import('../lib/ipcBridge').then(({ IPC }) => IPC.executeRedo());
      }
      
      // Cut / Copy / Paste intercept
      if (!isInput && e.ctrlKey && (e.key === 'c' || e.key === 'x')) {
          const activePane = panes.find(p => p.id === activePaneId);
          if (activePane) {
              const tab = activePane.tabs[activePane.activeTabIndex];
              if (tab.selectedItems.length > 0) {
                 const dirContents = safeGetDirContents(fileSystem, tab.path) || [];
                 const selectedEntities = dirContents.filter((x: any) => tab.selectedItems.includes(x.id)).map((x: any) => ({
                    id: x.id,
                    name: x.name,
                    path: x.path || undefined, // Support visual search results
                    type: x.type
                 }));
                 if (selectedEntities.length > 0) {
                     setClipboardState(e.key === 'x' ? 'cut' : 'copy', tab.path, selectedEntities);
                 }
              }
          }
      }

      if (!isInput && e.ctrlKey && e.key === 'v') {
          const activePane = panes.find(p => p.id === activePaneId);
          if (activePane) {
              const tab = activePane.tabs[activePane.activeTabIndex];
              executePaste(tab.path);
          }
      }

      // Inline F2 Rename
      if (e.key === 'F2' && focusedItemId && !isToolbarConfigOpen && !isSmartToolsOpen) {
         e.preventDefault();
         const activePane = panes.find(p => p.id === activePaneId);
         if (activePane) {
             const tab = activePane.tabs[activePane.activeTabIndex];
             const entity = safeGetDirContents(fileSystem, tab.path)?.find((x: any) => x.id === focusedItemId);
             if (entity) {
                 setInlineRename({ path: tab.path, entityId: focusedItemId, currentName: entity.name });
             }
         }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [focusedItemId, panes, activePaneId, fileSystem, isToolbarConfigOpen, isSmartToolsOpen, setClipboardState, executePaste]);

  // Context Menu State
  const [contextMenu, setContextMenu] = useState<{ x: number, y: number, entityId: string | null, path: string, entityName: string | null, isDirectory: boolean, nativeContextItems?: any[], selectedPaths?: string[] } | null>(null);

  const handleContextMenuRequest = async (e: React.MouseEvent, targetPath: string, entityId: string | null, isDirectory: boolean, entityName: string | null, selectedPaths?: string[]) => {
      e.preventDefault();
      e.stopPropagation();
      setLastClickData(null);
      setInlineRename(null);

      if (!config.useCustomContextMenu) {
          import('../lib/ipcBridge').then(({ IPC }) => IPC.showNativeContextMenu(targetPath, e.screenX, e.screenY));
          return;
      }

      // Fetch native items to merge into custom menu
      let nativeItems: any[] = [];
      try {
          const { IPC } = await import('../lib/ipcBridge');
          nativeItems = await IPC.fetchNativeContextMenuItems(targetPath);
      } catch (err) {
          console.error("Failed to fetch native context menu items", err);
      }

      setContextMenu({
          x: e.clientX,
          y: e.clientY,
          entityId,
          path: targetPath,
          entityName,
          isDirectory,
          nativeContextItems: nativeItems,
          selectedPaths
      });
  };
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [dragTargetId, setDragTargetId] = useState<string | null>(null);
  const [gridFilters, setGridFilters] = useState<any>({});

  const handleDeleteRequest = (items: any[], path: string, isFromTree: boolean = false) => {
    if (items.length === 0) return;
    
    // Check tree bypass option if triggered via key
    if (isFromTree && config.disallowDeleteByKeyInFolderTree) {
      return;
    }

    showModal({
      type: 'destructive',
      title: 'Confirm Deletion',
      message: `Are you sure you want to delete ${items.length} item(s)?\n\nTarget(s):\n${items.map(x => x.name).slice(0, 3).join(', ')}${items.length > 3 ? '...' : ''}`,
      actions: [
        {
          label: `Delete ${items.length} Items`,
          style: 'destructive',
          action: () => {
             import('../lib/ipcBridge').then(({ IPC }) => {
                 items.forEach(entity => {
                     IPC.executeFsOperation(`del-${Date.now()}-${entity.name}`, 'delete', `${path}/${entity.name}`, '', config.bypassRecycleBin || false);
                 });
             });
          }
        },
        {
          label: 'Cancel',
          style: 'secondary',
          action: () => {}
        }
      ]
    });
  };

  useEffect(() => {
    const handleClickOutside = () => setContextMenu(null);
    window.addEventListener('click', handleClickOutside);
    return () => window.removeEventListener('click', handleClickOutside);
  }, []);

  const activePaneIndex = panes.findIndex(p => p.id === activePaneId);
  const activePane = panes[activePaneIndex] || panes[0];
  const activeTab = activePane?.tabs[activePane.activeTabIndex] || { path: '/', selectedItems: [] };
  const currentPath = activeTab.path;

  // --- External File System Watcher ---
  useEffect(() => {
    let unsubscribe: () => void;
    import('../lib/ipcBridge').then(({ IPC }) => {
      unsubscribe = IPC.onFsEvents((events) => {
        setFileSystem(prevFs => {
          let newFs = prevFs;
          for (const ev of events) {
            const vPath = ev.dir.replace(/\\/g, '/');
            newFs = updateFileSystem(newFs, vPath, (dir) => {
              if (ev.type === 'Created' && !dir.children[ev.name]) {
                const isFile = ev.name.includes('.');
                dir.children[ev.name] = {
                  id: `${vPath}/${ev.name}`,
                  name: ev.name,
                  type: isFile ? 'file' : 'directory',
                  size: isFile ? 1024 : 0,
                  modified: new Date().toISOString(),
                  tags: [],
                  ...(isFile ? { extension: ev.name.split('.').pop() } : { children: {} })
                } as any;
              } else if (ev.type === 'Deleted') {
                delete dir.children[ev.name];
              } else if (ev.type === 'Renamed' && ev.oldName) {
                const node = dir.children[ev.oldName];
                if (node) {
                  dir.children[ev.name] = { ...node, name: ev.name };
                  delete dir.children[ev.oldName];
                }
              }
            });
          }
          return newFs;
        });
      });
    });
    return () => unsubscribe && unsubscribe();
  }, []);

  // Monitor paths when panes change to fire native FileSystemWatcher
  useEffect(() => {
    import('../lib/ipcBridge').then(({ IPC }) => {
       panes.forEach(p => {
          p.tabs.forEach(t => {
            if (t.path && t.path.includes('/')) {
               IPC.watchDirectory(t.path);
            }
          });
       });
    });
  }, [panes]);

  // Operations Progress and Conflict Listeners
  useEffect(() => {
    let unsubProp: () => void;
    let unsubConf: () => void;
    import('../lib/ipcBridge').then(({ IPC }) => {
      unsubProp = IPC.onProgress((progressDetails) => {
        setTransferProgress(prev => ({
           ...prev,
           [progressDetails.operationId]: {
              percentage: progressDetails.percentage,
              file: progressDetails.currentFile,
              bytesTransferred: progressDetails.bytesTransferred || 0,
              totalBytes: progressDetails.totalBytes || 0,
              speedBytesPerSecond: progressDetails.speedBytesPerSecond || 0,
              itemsCompleted: progressDetails.itemsCompleted || 0,
              totalItems: progressDetails.totalItems || 0
           }
        }));
        if (progressDetails.percentage >= 100) {
           setTimeout(() => {
             setTransferProgress(prev => {
                const next = { ...prev };
                delete next[progressDetails.operationId];
                return next;
             });
           }, 1000);
        }
      });
      unsubConf = IPC.onConflictContent((conflictDetails) => {
         showModal({
           type: 'conflict',
           title: 'File Conflict Detected',
           message: `The destination already contains a file named:\n"${conflictDetails.fileName}"\n\nWhat would you like to do?`,
           actions: [
             {
               label: 'Replace the file in the destination',
               style: 'destructive',
               action: () => import('../lib/ipcBridge').then(({ IPC }) => IPC.resolveConflict(conflictDetails.opId, conflictDetails.fileName, 'replace'))
             },
             {
               label: 'Keep both (rename the copied file)',
               style: 'primary',
               action: () => import('../lib/ipcBridge').then(({ IPC }) => IPC.resolveConflict(conflictDetails.opId, conflictDetails.fileName, 'keepboth'))
             },
             {
               label: 'Skip this file',
               style: 'secondary',
               action: () => import('../lib/ipcBridge').then(({ IPC }) => IPC.resolveConflict(conflictDetails.opId, conflictDetails.fileName, 'skip'))
             }
           ]
         });
      });
    });
    return () => {
       unsubProp && unsubProp();
       unsubConf && unsubConf();
    };
  }, []);

  // --- Tree State Helpers ---
  const toggleExpand = (path: string) => {
    setExpandedPaths(prev => {
      const next = new Set(prev);
      if (next.has(path)) next.delete(path);
      else next.add(path);
      return next;
    });
  };

  const buildFSTree = (node: FSEntity, path: string): any => {
    if (node.type !== "directory") return null;
    const isExpanded = expandedPaths.has(path);
    const childrenItems = Object.keys(node.children)
      .map(k => buildFSTree(node.children[k], `${path}/${k}`))
      .filter(Boolean);

    return {
      label: node.name,
      icon: Folder,
      iconColor: "#dcb67a",
      selected: currentPath === path,
      expanded: isExpanded,
      onClick: () => { setCurrentPath(path); },
      onToggle: () => toggleExpand(path),
      childrenItems
    };
  };

  const treeData = [
    { label: "Rapid Access", icon: Star, iconColor: "#6dc2b8" },
    { 
      label: "This PC", icon: Monitor, iconColor: "#6db4e6", expanded: true, selected: currentPath === '/',
      onClick: () => setCurrentPath('/'),
      childrenItems: [
        { label: "Desktop", path: "C:/Users/Default/Desktop", isDynamic: true, icon: Monitor, iconColor: "#6db4e6" },
        { label: "Documents", path: "C:/Users/Default/Documents", isDynamic: true, icon: File, iconColor: "#dcb67a" },
        { label: "Downloads", path: "C:/Users/Default/Downloads", isDynamic: true, icon: ArrowDownCircle, iconColor: "#dcb67a" },
        ...drives.map(d => ({
           label: `${d.label} (${d.name.replace(/^\//,'')})`,
           icon: HardDrive,
           iconColor: d.name.includes("C:") ? "#6db4e6" : "#aaa",
           path: d.name,
           isDynamic: true
        }))
      ].filter(Boolean)
    },
    { label: "Network", icon: Network, iconColor: "#6db4e6" }
  ];

  // --- Multi-pane Orchestration Logic ---
  const toggleDualPane = () => {
    if (isDualPane) {
       setPanes([activePane]);
       setIsDualPane(false);
    } else {
       setPanes([panes[0], { 
         id: `pane-${Date.now()}`, 
         tabs: [{ id: `t-${Date.now()}`, path: '/D:', history: ['/D:'], historyIndex: 0, selectedItems: [], viewMode: 'details' }],
         activeTabIndex: 0,
         sortColumn: 'name',
         sortDirection: 'asc'
       }]);
       setIsDualPane(true);
    }
  };

  const addTab = (paneId: string, path: string) => {
    setPanes(prev => prev.map(p => {
      if (p.id === paneId) {
        const newTab = { id: `t-${Date.now()}`, path, history: [path], historyIndex: 0, selectedItems: [], viewMode: 'details' as const };
        return { ...p, tabs: [...p.tabs, newTab], activeTabIndex: p.tabs.length };
      }
      return p;
    }));
  };

  const closeTab = (paneId: string, tabIndex: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setPanes(prev => prev.map(p => {
      if (p.id === paneId && p.tabs.length > 1) {
        const newTabs = p.tabs.filter((_, i) => i !== tabIndex);
        const newActive = Math.min(p.activeTabIndex, newTabs.length - 1);
        return { ...p, tabs: newTabs, activeTabIndex: newActive };
      }
      return p;
    }));
  };

  const setActiveTab = (paneId: string, tabIndex: number) => {
    setActivePaneId(paneId);
    setPanes(prev => prev.map(p => p.id === paneId ? { ...p, activeTabIndex: tabIndex } : p));
  };

  const setCurrentPath = (path: string, paneId: string = activePaneId, updateHistory: boolean = true) => {
    setPanes(prev => prev.map(p => {
      if (p.id === paneId) {
        const newTabs = [...p.tabs];
        const tab = newTabs[p.activeTabIndex];
        let newHistory = tab.history;
        let newHistoryIndex = tab.historyIndex;
        if (updateHistory && tab.path !== path) {
            newHistory = newHistory.slice(0, newHistoryIndex + 1);
            newHistory.push(path);
            newHistoryIndex = newHistory.length - 1;
        }
        newTabs[p.activeTabIndex] = { ...tab, path, history: newHistory, historyIndex: newHistoryIndex, selectedItems: [] };
        return { ...p, tabs: newTabs };
      }
      return p;
    }));
  };

  const goBack = (paneId: string = activePaneId) => {
    setPanes(prev => prev.map(p => {
      if (p.id === paneId) {
         const newTabs = [...p.tabs];
         const tab = newTabs[p.activeTabIndex];
         if (tab.historyIndex > 0) {
             const newHistoryIndex = tab.historyIndex - 1;
             const path = tab.history[newHistoryIndex];
             newTabs[p.activeTabIndex] = { ...tab, path, historyIndex: newHistoryIndex, selectedItems: [] };
         }
         return { ...p, tabs: newTabs };
      }
      return p;
    }));
  };

  const goForward = (paneId: string = activePaneId) => {
    setPanes(prev => prev.map(p => {
      if (p.id === paneId) {
         const newTabs = [...p.tabs];
         const tab = newTabs[p.activeTabIndex];
         if (tab.historyIndex < tab.history.length - 1) {
             const newHistoryIndex = tab.historyIndex + 1;
             const path = tab.history[newHistoryIndex];
             newTabs[p.activeTabIndex] = { ...tab, path, historyIndex: newHistoryIndex, selectedItems: [] };
         }
         return { ...p, tabs: newTabs };
      }
      return p;
    }));
  };

  const setSelectedItems = (items: string[] | ((prev: string[]) => string[]), paneId: string = activePaneId) => {
    setPanes(prev => prev.map(p => {
      if (p.id === paneId) {
         const newTabs = [...p.tabs];
         const tab = newTabs[p.activeTabIndex];
         const newSelected = typeof items === 'function' ? items(tab.selectedItems) : items;
         newTabs[p.activeTabIndex] = { ...tab, selectedItems: newSelected };
         return { ...p, tabs: newTabs };
      }
      return p;
    }));
  };

  useEffect(() => {
     if (!marquee) return;
     const left = Math.min(marquee.startX, marquee.currX);
     const top = Math.min(marquee.startY, marquee.currY);
     const width = Math.abs(marquee.startX - marquee.currX);
     const height = Math.abs(marquee.startY - marquee.currY);
     const rect = { left, top, right: left + width, bottom: top + height };

     const elements = document.querySelectorAll(`[data-pane-id="${marquee.activePane}"] .fs-item-wrapper`);
     const selected: string[] = [];
     
     elements.forEach(el => {
         const elRect = el.getBoundingClientRect();
         if (!(elRect.right < rect.left || 
               elRect.left > rect.right || 
               elRect.bottom < rect.top || 
               elRect.top > rect.bottom)) {
             const id = el.getAttribute('data-id');
             if (id) selected.push(id);
         }
     });

     setSelectedItems(selected, marquee.activePane);
  }, [marquee?.currX, marquee?.currY]);

  const startFolderCompare = async () => {
      // Create pane 2 if it doesn't exist
      if (panes.length < 2) {
          setPanes(prev => {
              const newPane = { 
                  id: `pane${Date.now()}`,
                  tabs: [{ id: `t${Date.now()}`, path: '/', history: ['/'], historyIndex: 0, selectedItems: [], viewMode: config.defaultViewMode || 'details' }],
                  activeTabIndex: 0,
                  sortColumn: 'name' as const,
                  sortDirection: 'asc' as const
              };
              return [...prev, newPane];
          });
          setIsDualPane(true);
          // Wait for render
          setTimeout(() => executeCompare(), 300);
      } else {
          setIsDualPane(true);
          executeCompare();
      }
  };

  const executeCompare = async () => {
      const { IPC } = await import('../lib/ipcBridge');
      setIsSyncMode(true);
      setIsSyncing(true);
      
      // Get current panes
      setPanes(currentPanes => {
          if (currentPanes.length >= 2) {
             const pathA = currentPanes[0].tabs[currentPanes[0].activeTabIndex].path;
             const pathB = currentPanes[1].tabs[currentPanes[1].activeTabIndex].path;
             IPC.compareDirectories(pathA, pathB, config.syncUseHashing || false).then(res => {
                 // res is array of sync objects
                 const map: any = {};
                 res.forEach((item: any) => {
                     map[item.id] = item;
                 });
                 setSyncResults(map);
                 setIsSyncing(false);
             });
          }
          return currentPanes;
      });
  };

  const executeFolderSync = async (mode: 'mirror' | 'updateTarget') => {
      const { IPC } = await import('../lib/ipcBridge');
      if (panes.length >= 2) {
          const pathA = panes[0].tabs[panes[0].activeTabIndex].path;
          const pathB = panes[1].tabs[panes[1].activeTabIndex].path;
          IPC.executeFsOperation(`sync-${Date.now()}`, 'copy', pathA, pathB);
      }
      setToastMessage(`Executed Sync: ${mode}`);
      setIsSyncMode(false);
      setSyncResults({});
  };

  const setViewMode = (mode: 'details' | 'grid' | 'list', paneId: string = activePaneId) => {
    setPanes(prev => prev.map(p => {
      if (p.id === paneId) {
         const newTabs = [...p.tabs];
         const tab = newTabs[p.activeTabIndex];
         newTabs[p.activeTabIndex] = { ...tab, viewMode: mode };
         return { ...p, tabs: newTabs };
      }
      return p;
    }));
    updateConfig({ defaultViewMode: mode });
  };

  const toggleSort = (paneId: string, column: 'name' | 'type' | 'size' | 'modified') => {
    setPanes(prev => prev.map(p => {
      if (p.id === paneId) {
         if (p.sortColumn === column) {
            return { ...p, sortDirection: p.sortDirection === 'asc' ? 'desc' : 'asc' };
         } else {
            return { ...p, sortColumn: column, sortDirection: 'asc' };
         }
      }
      return p;
    }));
  };

  const goUp = (paneId: string = activePaneId) => {
    const p = panes.find(x => x.id === paneId);
    if (!p) return;
    const cPath = p.tabs[p.activeTabIndex].path;
    if (cPath === "/C:" || cPath === "/D:") {
      setCurrentPath("/", paneId);
    } else if (cPath.includes("/")) {
      setCurrentPath(cPath.substring(0, cPath.lastIndexOf("/")), paneId);
    }
    setSelectedItems([], paneId);
  };

  // Keyboard state
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isInput = e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement;

      if (e.key === '/') {
          if (document.activeElement !== omniFilterRef.current && !isInput) {
              e.preventDefault();
              omniFilterRef.current?.focus();
              return;
          }
      }
      
      if (e.key === 'Escape') {
          if (document.activeElement === omniFilterRef.current) {
              e.preventDefault();
              omniFilterRef.current?.blur();
              setFilterText('');
              return;
          }
      }

      if (e.altKey && e.key === 'ArrowLeft') {
         e.preventDefault();
         goBack(activePaneId);
      } else if (e.altKey && e.key === 'ArrowRight') {
         e.preventDefault();
         goForward(activePaneId);
      } else if ((e.altKey && e.key === 'ArrowUp') || (e.key === 'Backspace' && !isInput)) {
         e.preventDefault();
         goUp(activePaneId);
      }

      // Ignore other keys if user is typing in another input (like Smart Tools)
      if (isInput && document.activeElement !== omniFilterRef.current) return;

      // Allow typing in OmniFilter to proceed normally, but handle specific keys like Down/Up/Enter
      if (document.activeElement === omniFilterRef.current && !['ArrowDown', 'ArrowUp', 'Enter'].includes(e.key)) {
          return;
      }

      if (e.key === 'Tab') {
        e.preventDefault();
        if (isDualPane) {
           const nextIdx = (activePaneIndex + 1) % panes.length;
           setActivePaneId(panes[nextIdx].id);
        }
      } else if (e.key === 't' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        addTab(activePaneId, activeTab.path);
      } else if (e.key === 'F2') {
        e.preventDefault();
        if (activeTab.selectedItems.length > 0) {
           setIsSmartToolsOpen(true);
        }
      } else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        const isGlobal = config.enableGlobalSearchPrefix && filterText.trimStart().startsWith('> ');
        let paneContents = activeTab.path === '/' || activeTab.path === '/D:' ? [] : getDirContents(fileSystem, activeTab.path) || [];
        
        if (isGlobal) {
            paneContents = globalSearchResults || [];
        } else if (filterText.trim() !== '') {
            try {
                const regex = new RegExp(filterText, 'i');
                paneContents = paneContents.filter((item: any) => regex.test(item.name)) as any;
            } catch (err) {
                paneContents = paneContents.filter((item: any) => item.name.toLowerCase().includes(filterText.toLowerCase())) as any;
            }
        }

        if (paneContents.length === 0) return;
        
        let idx = paneContents.findIndex((c: any) => c.id === focusedItemId || (activeTab.selectedItems.length > 0 && c.id === activeTab.selectedItems[0]));
        
        if (e.key === 'ArrowDown') {
           idx = idx === -1 ? 0 : Math.min(idx + 1, paneContents.length - 1);
        } else {
           idx = idx === -1 ? paneContents.length - 1 : Math.max(idx - 1, 0);
        }
        
        const nextItem = paneContents[idx] as any;
        if (nextItem) {
           setFocusedItemId(nextItem.id);
           setSelectedItems([nextItem.id], activePaneId);
           const el = document.getElementById(`fs-item-${nextItem.id}`);
           if (el) el.scrollIntoView({ block: 'nearest' });
        }
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (activeTab.selectedItems.length > 0) {
           const isGlobal = config.enableGlobalSearchPrefix && filterText.trimStart().startsWith('> ');
           let paneContents = activeTab.path === '/' || activeTab.path === '/D:' ? [] : safeGetDirContents(fileSystem, activeTab.path) || [];
           if (isGlobal) {
               paneContents = globalSearchResults || [];
           } else if (filterText.trim() !== '') {
               try {
                   const regex = new RegExp(filterText, 'i');
                   paneContents = paneContents.filter((item: any) => regex.test(item.name)) as any;
               } catch (err) {
                   paneContents = paneContents.filter((item: any) => item.name.toLowerCase().includes(filterText.toLowerCase())) as any;
               }
           }
           const selectedItem = paneContents?.find((c: any) => c.id === activeTab.selectedItems[0]) as any;
           if (selectedItem?.type === 'directory') {
               const newPath = selectedItem.path || `${activeTab.path}/${selectedItem.name}`;
               setCurrentPath(newPath, activePaneId);
               setFilterText(''); // Clear filter when opening directory
               omniFilterRef.current?.blur();
           } else if (selectedItem?.type === 'file') {
               // Optional: If it's a file, execute it or open directory (if the path is known)
               if (isGlobal && selectedItem.path) {
                    const dirPath = selectedItem.path.substring(0, selectedItem.path.lastIndexOf('/'));
                    setCurrentPath(dirPath, activePaneId);
                    setFilterText('');
                    omniFilterRef.current?.blur();
                    // maybe focus this item?
                    setTimeout(() => {
                        setFocusedItemId(selectedItem.id);
                        setSelectedItems([selectedItem.id], activePaneId);
                        const el = document.getElementById(`fs-item-${selectedItem.id}`);
                        if (el) el.scrollIntoView({ block: 'nearest' });
                    }, 50);
               }
           }
        }
      }
      
      if (e.key === 'Delete') {
         const activePane = panes.find(p => p.id === activePaneId);
         if (activePane) {
             const tab = activePane.tabs[activePane.activeTabIndex];
             if (tab.selectedItems.length > 0) {
                 const dirContents = safeGetDirContents(fileSystem, tab.path) || [];
                 const selectedEntities = dirContents.filter((x: any) => tab.selectedItems.includes(x.id));
                 if (selectedEntities.length > 0) {
                     handleDeleteRequest(selectedEntities, tab.path, focusedItemId === 'TREE');
                 }
             }
         }
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [panes, activePaneId, isDualPane, activePaneIndex, activeTab, fileSystem, focusedItemId, filterText]);

  // Bridge Handler for AI renaming modification
  const handleApplyRename = (operations: RenameOperation[]) => {
     let newFs = fileSystem;
     newFs = updateFileSystem(newFs, activeTab.path, (dir) => {
        for (const op of operations) {
            const fileKey = Object.keys(dir.children).find(k => dir.children[k].name === op.originalName);
            if (fileKey) {
                const node = dir.children[fileKey] as any;
                dir.children[op.newName] = { ...node, name: op.newName, modified: new Date().toISOString() };
                if (node.type === "file") {
                   const parts = op.newName.split('.');
                   (dir.children[op.newName] as any).extension = parts.length > 1 ? parts.pop()! : '';
                }
                delete dir.children[fileKey];
            }
        }
     });
     setFileSystem(newFs);
     setSelectedItems([]); 
  };

    // Retrieves active selected objects for AI manipulation context
    const isGlobal = config.enableGlobalSearchPrefix && filterText.trimStart().startsWith('> ');
    const rootDriveEntities = drives.map(d => ({
        id: `drive-${d.name}`,
        name: d.name,
        type: "directory",
        path: d.name,
        size: d.totalSpace,
        modified: new Date().toISOString(),
        created: new Date().toISOString(),
        tags: [],
        typeDescription: `${d.label} Drive (${d.format})`,
        driveInfo: d
    }));

    let activeContents = currentPath === '/' || currentPath === '/this-pc' ? rootDriveEntities : safeGetDirContents(fileSystem, currentPath);
    if (isGlobal) activeContents = globalSearchResults || [];
    
    const activeFilesMap = activeContents?.filter(c => activeTab.selectedItems.includes(c.id)) || [];

  // --- Subcomponents ---
  const renderPane = (pane: PaneState, index: number) => {
    const isActive = pane.id === activePaneId;
    const currentTab = pane.tabs[pane.activeTabIndex];
    const computedViewMode = currentTab.viewMode || config.defaultViewMode || 'details';
    const panePath = currentTab.path;
    const isGlobal = isActive && config.enableGlobalSearchPrefix && filterText.trimStart().startsWith('> ');
    
    let contents = panePath === '/' || panePath === '/this-pc' ? rootDriveEntities : safeGetDirContents(fileSystem, panePath);
    if (isGlobal) {
        if (isGlobalSearchLoading) {
            // Render loading indicator
            contents = [];
        } else if (globalSearchResults) {
            contents = globalSearchResults;
        } else {
            contents = [];
        }
    } else if (contents && isActive && filterText.trim() !== '') {
        try {
            // Attempt Regex matching first
            const regex = new RegExp(filterText, 'i');
            contents = contents.filter(item => regex.test(item.name));
        } catch (e) {
            // Fallback to standard string checking if regex is invalid
            contents = contents.filter(item => item.name.toLowerCase().includes(filterText.toLowerCase()));
        }
    }

    if (contents && pane.filterRegex && pane.filterRegex.trim() !== '') {
        try {
            // Allow string search as well as regex
            const regex = new RegExp(pane.filterRegex, 'i');
            contents = contents.filter(item => regex.test(item.name));
        } catch (e) {
            // fallback to plain string match if invalid regex
            contents = contents.filter(item => item.name.toLowerCase().includes(pane.filterRegex!.toLowerCase()));
        }
    }

    if (contents && isActive && gridFilters?.isActive) {
        if (gridFilters.hideSystem) {
             contents = contents.filter((item: any) => !item.name.startsWith('.'));
        }
        if (gridFilters.isolateImages) {
             const imageExts = ['png', 'jpg', 'jpeg', 'gif', 'bmp', 'svg', 'webp'];
             contents = contents.filter((item: any) => item.type === 'directory' || (item.extension && imageExts.includes(item.extension.toLowerCase())));
        }
        if (gridFilters.isolateCode) {
             const codeExts = ['js', 'ts', 'jsx', 'tsx', 'py', 'java', 'c', 'cpp', 'cs', 'go', 'rs', 'html', 'css', 'json', 'yaml', 'yml', 'xml', 'md'];
             contents = contents.filter((item: any) => item.type === 'directory' || (item.extension && codeExts.includes(item.extension.toLowerCase())));
        }
        if (gridFilters.excludeExt) {
             const ext = gridFilters.excludeExt.toLowerCase();
             contents = contents.filter((item: any) => !item.extension || item.extension.toLowerCase() !== ext);
        }
    }

    if (contents) {
        contents = [...contents].sort((a, b) => {
            if (config.sortFoldersFirst) {
               const dirA = a.type === 'directory' ? -1 : 1;
               const dirB = b.type === 'directory' ? -1 : 1;
               if (dirA !== dirB) return dirA - dirB; // Always sort directories first
            }

            const col = pane.sortColumn || 'name';
            const dir = pane.sortDirection === 'desc' ? -1 : 1;

            if (col === 'name') {
                return dir * a.name.localeCompare(b.name);
            } else if (col === 'type') {
                const typeA = (a as any).extension || '';
                const typeB = (b as any).extension || '';
                return dir * typeA.localeCompare(typeB);
            } else if (col === 'size') {
                const sizeA = (a as any).size || 0;
                const sizeB = (b as any).size || 0;
                return dir * (sizeA - sizeB);
            } else if (col === 'modified') {
                const modA = new Date(a.modified).getTime();
                const modB = new Date(b.modified).getTime();
                return dir * (modA - modB);
            }
            return 0;
        });
    }

    const handleEntityClicked = (e: React.MouseEvent, id: string) => {
      e.stopPropagation();
      setActivePaneId(pane.id);
      
      const wasAlreadySelected = currentTab.selectedItems.length === 1 && currentTab.selectedItems[0] === id;
      
      setFocusedItemId(id);
      if (e.ctrlKey || e.metaKey) {
        setSelectedItems(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id], pane.id);
        setLastClickData(null);
      } else if (e.shiftKey) {
        setSelectedItems([id], pane.id);
        setLastClickData(null);
      } else {
        setSelectedItems([id], pane.id);
        
        // Delayed double-click rename ( standard windows UX )
        const now = Date.now();
        if (wasAlreadySelected && lastClickData && lastClickData.id === id) {
            const delay = now - lastClickData.time;
            if (delay >= 500 && delay <= 2000) {
                 const entity = safeGetDirContents(fileSystem, panePath)?.find((x: any) => x.id === id);
                 if (entity) {
                     setInlineRename({ path: panePath, entityId: id, currentName: entity.name });
                     setLastClickData(null); // consume click
                     return;
                 }
            }
        }
        setLastClickData({ id, time: now });
      }
    };

    const handleEntityDoubleClicked = (entity: any) => {
      setActivePaneId(pane.id);
      setFocusedItemId(entity.id);
      setLastClickData(null);
      setInlineRename(null);
      if (entity.type === "directory") {
        const newPath = isGlobal && entity.path ? entity.path : `${panePath}/${entity.name}`;
        setCurrentPath(newPath, pane.id);
        if (isGlobal) {
            setFilterText('');
            omniFilterRef.current?.blur();
        }
      } else {
        if (isGlobal && entity.path) {
            import('../lib/ipcBridge').then(({IPC}) => IPC.shellExecute('open', entity.path));
        }
      }
    };

    const handleDragOver = (e: React.DragEvent) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = e.ctrlKey ? "copy" : "move";
    };

    const handleDrop = (e: React.DragEvent, dropTargetIdOverride?: string | null) => {
      e.preventDefault();
      try {
        let destPath = panePath;
        if (dropTargetIdOverride) {
          const targetEntity = contents.find(c => c.id === dropTargetIdOverride);
          if (targetEntity && targetEntity.type === "directory") {
            destPath = `${panePath}/${targetEntity.name}`;
          }
        }

        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            // Drag FROM OS into BNDZ grid
            const filePaths = Array.from(e.dataTransfer.files).map(f => (f as any).path).filter(Boolean);
            if (filePaths.length > 0) {
                import('../lib/ipcBridge').then(({ IPC }) => {
                    IPC.executeFsOperation(`drop-${Date.now()}`, e.ctrlKey ? 'copy' : 'move', filePaths, destPath); 
                });
            }
            return;
        }

        const dataStr = e.dataTransfer.getData("application/bndz-file");
        if (!dataStr) return;
        const data = JSON.parse(dataStr);
        
        if (data.sourcePaneId !== pane.id || data.sourcePath !== destPath) {
           const srcDirContents = safeGetDirContents(fileSystem, data.sourcePath) || [];
           const entityToMove = srcDirContents.find((c: any) => c.id === data.entityId);
           if (!entityToMove) return;

           // Determine source full path
           const sourceFullPath = `${data.sourcePath}/${entityToMove.name}`;

           // Dynamically instruct native layer
           import('../lib/ipcBridge').then(({ IPC }) => {
              const opId = `op-${Date.now()}`;
              IPC.executeFsOperation(opId, 'move', sourceFullPath, destPath);
              
              if (!IPC.isNative) {
                 // Fallback eager update for web mockup
                 let newFs = fileSystem;
                 newFs = updateFileSystem(newFs, data.sourcePath, (dir) => {
                   const key = Object.keys(dir.children).find(k => dir.children[k].id === data.entityId);
                   if (key) delete dir.children[key];
                 });
      
                 newFs = updateFileSystem(newFs, destPath, (dir) => {
                   dir.children[entityToMove.name] = entityToMove;
                 });
                 setFileSystem(newFs);
              }
           });
        }
      } catch (err) {
         console.error(err);
      }
    };

    return (
      <div 
        key={pane.id}
        className={`flex-1 flex flex-col min-w-0 ${config.applyColors ? '' : 'bg-[#1c1c1c]'} ${isActive && isDualPane ? 'shadow-[inset_0_0_0_1px_rgba(59,130,246,0.6)] z-10' : ''} relative`}
        style={config.applyColors ? { backgroundColor: 'var(--list-bg)', color: 'var(--list-text)' } : {}}
        onClick={() => { setActivePaneId(pane.id); }}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
      >
        {config.shadeInactivePane !== false && !isActive && isDualPane && (
           <div className="absolute inset-0 bg-black/15 z-[5] pointer-events-none"></div>
        )}
        {/* Tab Strip */}
        <div className="flex bg-[#111] pt-1 px-1 shrink-0 overflow-x-auto no-scrollbar border-b border-[#333] items-end min-h-[28px]">
           {pane.tabs.map((tab, idx) => {
             const isTabActive = idx === pane.activeTabIndex;
             const name = tab.path === '/' ? 'This PC' : tab.path === '/C:' ? 'Local Disk (C:)' : tab.path === '/D:' ? 'Backup (D:)' : tab.path.split('/').pop();
             return (
               <div 
                 key={tab.id}
                 onClick={(e) => { e.stopPropagation(); setActiveTab(pane.id, idx); }}
                 className={`flex items-center px-3 py-[4px] ml-[2px] rounded-t z-10 -mb-[1px] cursor-pointer group border-t border-l border-r ${config.flexibleTabWidth ? 'max-w-[150px]' : ''} ${isTabActive ? 'border-[#333]' : 'border-transparent hover:border-[#333]'} ${config.makeSelectedTabBold && isTabActive ? 'font-bold' : 'font-semibold'}`}
                 style={config.applyColors ? {
                    backgroundColor: isTabActive ? 'var(--tab-active-bg)' : 'var(--tab-inactive-bg)',
                    color: isTabActive ? 'var(--tab-active-text)' : 'var(--tab-inactive-text)'
                 } : {
                    backgroundColor: isTabActive ? '#1c1c1c' : '#111',
                    color: isTabActive ? '#6db4e6' : '#6b7280'
                 }}
               >
                 {config.showIconsTabs !== false && (
                    <Folder size={12} className={`mr-1.5 ${isTabActive ? 'text-[#dcb67a]' : 'text-gray-500'} ${config.makeSelectedTabBold && isTabActive ? 'stroke-[2.5px]' : ''}`} />
                 )}
                 <span className={`truncate text-[11px]`}>{name}</span>
                 {config.showXCloseButtonsOnTabs !== "None" && pane.tabs.length > 1 && (config.showXCloseButtonsOnTabs === "All tabs" || isTabActive) && (
                    <X size={12} className={`ml-2 text-gray-500 hover:text-red-400 opacity-100`} onClick={(e) => closeTab(pane.id, idx, e)} />
                 )}
               </div>
             );
           })}
           {config.showNewTabButton !== false && (
             <div 
               className="ml-1 px-2 py-[2px] hover:bg-[#333] rounded-t flex items-center justify-center cursor-pointer text-gray-400 font-bold"
               onClick={(e) => { e.stopPropagation(); addTab(pane.id, currentTab.path); }}
             >
               <span className="text-[14px] leading-tight">+</span>
             </div>
           )}
           {config.showTabListButton && (
             <div 
               className="ml-1 px-2 py-[2px] hover:bg-[#333] rounded-t flex items-center justify-center cursor-pointer text-gray-400"
             >
               <Menu size={12} />
             </div>
           )}
        </div>
        
        {/* Breadcrumb Row */}
        <div className={`flex ${config.applyColors ? '' : 'bg-[#1a1a1a]'} border-b border-[#333] items-center px-1 py-[2px] shrink-0`}
             style={config.applyColors ? { backgroundColor: 'var(--breadcrumb-bg)', color: 'var(--breadcrumb-text)' } : {}}>
            <ToolbarButton icon={ArrowLeft} className={`w-5 ${currentTab.historyIndex > 0 ? '' : 'opacity-30'}`} onClick={() => goBack(pane.id)} />
            <ToolbarButton icon={ArrowRight} className={`w-5 ${currentTab.historyIndex < currentTab.history.length - 1 ? '' : 'opacity-30'}`} onClick={() => goForward(pane.id)} />
            <ToolbarButton icon={ArrowUp} className="w-5" onClick={() => goUp(pane.id)} />
            <div 
              className="flex items-center text-[12px] px-1 overflow-x-hidden whitespace-nowrap mask-image-rtl flex-1 cursor-text"
              onClick={() => {
                 if (!isGlobal) {
                     setEditingAddressBarPaneId(pane.id);
                     let initial = currentTab.path;
                     if (initial.startsWith('/')) initial = initial.substring(1);
                     setAddressBarInput(initial.replace(/\//g, '\\'));
                 }
              }}
            >
              {editingAddressBarPaneId === pane.id && !isGlobal ? (
                 <input 
                    type="text" 
                    autoFocus 
                    className="flex-1 bg-transparent border-none outline-none text-white w-full" 
                    value={addressBarInput} 
                    onChange={e => setAddressBarInput(e.target.value)} 
                    onBlur={() => setEditingAddressBarPaneId(null)}
                    onKeyDown={async e => {
                        if (e.key === 'Enter') {
                            e.preventDefault();
                            let newPath = addressBarInput.replace(/\\/g, '/');
                            if (!newPath.startsWith('/')) newPath = '/' + newPath;
                            import('../lib/ipcBridge').then(async ({IPC}) => {
                                const exists = await IPC.checkPathExists(newPath);
                                if (exists) {
                                  setCurrentPath(newPath, pane.id);
                                  setEditingAddressBarPaneId(null);
                                } else {
                                  setEditingAddressBarPaneId(null);
                                  // Revert smoothly as requested
                                }
                            });
                        }
                        if (e.key === 'Escape') setEditingAddressBarPaneId(null);
                    }}
                 />
              ) : isGlobal ? (
                 <React.Fragment>
                    <span className="text-gray-500 mx-1 shrink-0">Global Search &gt;</span>
                    <span className="hover:underline cursor-pointer font-semibold shrink-0 text-yellow-400">
                       {filterText.trimStart().substring(2).trim()}
                    </span>
                 </React.Fragment>
              ) : currentTab.path.split('/').map((part, idx, arr) => {
                if (!part) return null;
                const thisPath = arr.slice(0, idx + 1).join('/');
                return (
                  <React.Fragment key={idx}>
                    {idx > 1 && <span className="text-gray-500 mx-1 shrink-0">&gt;</span>}
                    <span 
                      className="hover:underline cursor-pointer font-semibold shrink-0"
                      onClick={(e) => { e.stopPropagation(); setCurrentPath(thisPath, pane.id); }}
                    >
                      {part}
                    </span>
                  </React.Fragment>
                )
              })}
            </div>
            <div className="flex bg-[#222] border border-[#444] rounded items-center px-1 text-[11px] shrink-0 mx-2">
                 <button onClick={() => setViewMode('details', pane.id)} className={`p-1 rounded ${computedViewMode === 'details' ? 'bg-[#444]' : 'hover:bg-[#333]'}`} title="Details View">
                     <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3.01" y2="6"></line><line x1="3" y1="12" x2="3.01" y2="12"></line><line x1="3" y1="18" x2="3.01" y2="18"></line></svg>
                 </button>
                 <button onClick={() => setViewMode('grid', pane.id)} className={`p-1 rounded ${computedViewMode === 'grid' ? 'bg-[#444]' : 'hover:bg-[#333]'}`} title="Grid View">
                     <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                 </button>
                 <button onClick={() => setViewMode('list', pane.id)} className={`p-1 rounded ${computedViewMode === 'list' ? 'bg-[#444]' : 'hover:bg-[#333]'}`} title="List View">
                     <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
                 </button>
            </div>
            <div className="flex bg-[#222] border border-[#444] rounded items-center px-2 py-0.5 mx-2 text-[11px] shrink-0 w-[140px] focus-within:w-[200px] focus-within:border-sky-500 transition-all duration-200">
               <Search size={12} className="text-gray-400 mr-1.5" />
               <input
                   type="text"
                   placeholder="Regex Filter..."
                   className="bg-transparent border-none outline-none text-gray-200 flex-1 placeholder:text-gray-600"
                   value={pane.filterRegex || ''}
                   onChange={(e) => {
                       const newPanes = [...panes];
                       const p = newPanes.find(x => x.id === pane.id);
                       if (p) p.filterRegex = e.target.value;
                       setPanes(newPanes);
                   }}
               />
            </div>
        </div>

        {/* Grid Header */}
        {(computedViewMode === 'details') && (
        <div className="flex bg-[#1a1a1a] border-b border-[#333] text-[#aaa] text-[11px] py-1 shrink-0 px-1 select-none">
           <div className="w-6 border-r border-[#333]"></div>
           <div className="w-[45%] max-w-[300px] px-2 border-r border-[#333] flex items-center justify-between cursor-pointer hover:bg-[#2a2a2a]" onClick={() => toggleSort(pane.id, 'name')}>
             Name {pane.sortColumn === 'name' && <span className="text-[10px]">{pane.sortDirection === 'asc' ? '▲' : '▼'}</span>}
           </div>
           <div className="w-[15%] max-w-[120px] px-2 border-r border-[#333] flex items-center justify-between cursor-pointer hover:bg-[#2a2a2a]" onClick={() => toggleSort(pane.id, 'type')}>
             Type {pane.sortColumn === 'type' && <span className="text-[10px]">{pane.sortDirection === 'asc' ? '▲' : '▼'}</span>}
           </div>
           <div className="w-[15%] max-w-[100px] px-2 border-r border-[#333] flex items-center justify-between cursor-pointer hover:bg-[#2a2a2a]" onClick={() => toggleSort(pane.id, 'size')}>
             <span className="flex-1 text-right">Size</span> {pane.sortColumn === 'size' && <span className="text-[10px] ml-1">{pane.sortDirection === 'asc' ? '▲' : '▼'}</span>}
           </div>
           <div className="w-[25%] max-w-[160px] px-2 border-r border-[#333] flex items-center justify-between cursor-pointer hover:bg-[#2a2a2a]" onClick={() => toggleSort(pane.id, 'modified')}>
             Modified {pane.sortColumn === 'modified' && <span className="text-[10px]">{pane.sortDirection === 'asc' ? '▲' : '▼'}</span>}
           </div>
           <div className="flex-1 px-2 border-r border-[#333]">Tags</div>
        </div>
        )}

        {/* List Items */}
        <div 
           data-pane-id={pane.id}
           className="flex-1 overflow-y-auto p-1 text-white focus:outline-none relative"
           onContextMenu={(e) => handleContextMenuRequest(e, panePath, null, true, null)}
           onClick={(e) => {
              if (e.defaultPrevented) return;
              // if marquee was active and dragged, we shouldn't clear. 
              // A simple way is to check a ref or just see if the mouse moved during pointerdown.
              // We'll rely on the fact that we can set a flag on the event or use a ref.
              // Actually, since React resets e, we will rely on a generic check.
              if ((window as any)._marqueeDragOccurred) {
                  (window as any)._marqueeDragOccurred = false;
                  return;
              }
              setSelectedItems([], pane.id);
              setLastClickData(null);
              setInlineRename(null);
           }}
           onPointerDown={(e) => {
              // Only trigger if clicking directly on the background or list container, not on an item
              if (!(e.target as HTMLElement).closest('.fs-item-wrapper')) {
                 const startX = e.clientX;
                 const startY = e.clientY;
                 setMarquee({ activePane: pane.id, startX, startY, currX: startX, currY: startY });
                 (window as any)._marqueeDragOccurred = false;

                 const onPointerMove = (ev: PointerEvent) => {
                     if (Math.abs(ev.clientX - startX) > 3 || Math.abs(ev.clientY - startY) > 3) {
                         (window as any)._marqueeDragOccurred = true;
                     }
                     setMarquee(prev => prev ? { ...prev, currX: ev.clientX, currY: ev.clientY } : null);
                 };
                 const onPointerUp = () => {
                     window.removeEventListener('pointermove', onPointerMove);
                     window.removeEventListener('pointerup', onPointerUp);
                     setMarquee(null);
                 };
                 window.addEventListener('pointermove', onPointerMove);
                 window.addEventListener('pointerup', onPointerUp);
              }
           }}
        >
          <div className={
            computedViewMode === 'grid' ? "grid grid-cols-[repeat(auto-fill,minmax(100px,1fr))] gap-2" :
            computedViewMode === 'list' ? "flex flex-wrap gap-2" :
            "flex flex-col"
          }>
                         {(contents || []).map((entity) => {
                const isSelected = currentTab.selectedItems.includes(entity.id);
                const isDir = entity.type === "directory";
                const isDrive = !!(entity as any).driveInfo;
                const drive = (entity as any).driveInfo;
                const isCut = clipboard?.action === 'cut' && clipboard.items.some((i: any) => i.id === entity.id);
                let filterColor = applyVisualFilters(entity, config.visualFilters);
                let syncOpacity = false;

                if (isSyncMode && syncResults) {
                     const sRes = syncResults[entity.id] || Object.values(syncResults).find((s: any) => s.path?.endsWith(entity.name));
                     if (sRes) {
                         const isPaneA = panes[0].id === pane.id;
                         const status = isPaneA ? sRes.statusA : sRes.statusB;
                         if (status === 'Identical') {
                             syncOpacity = true;
                         } else if (status === 'Unique') {
                             filterColor = '#22c55e'; // Green
                         } else if (status === 'Newer') {
                             filterColor = '#3b82f6'; // Blue
                         } else if (status === 'Conflict' || status === 'Missing') {
                             filterColor = status === 'Conflict' ? '#eab308' : '#ef4444'; // Yellow or Red
                         }
                     }
                }
                
                const displayName = (config.showFileExtensions === false && !isDir && (entity as any).extension) 
                    ? entity.name.replace(new RegExp(`\\.${(entity as any).extension}$`, 'i'), '') 
                    : entity.name;
                    
                const renameInput = inlineRename?.entityId === entity.id && inlineRename?.path === panePath ? (
                    <input 
                       type="text" 
                       className="bg-[#111] text-white border border-[#007acc] px-1 outline-none w-[90%]"
                       autoFocus 
                       value={inlineRename.currentName}
                       onChange={e => setInlineRename({ ...inlineRename, currentName: e.target.value })}
                       onBlur={() => {
                           if (inlineRename.currentName !== entity.name) {
                               import("../lib/ipcBridge").then(({ IPC }) => IPC.executeFsOperation(`rename-${Date.now()}`, "move", `${panePath}/${entity.name}`, `${panePath}/${inlineRename.currentName}`));
                           }
                           setInlineRename(null);
                       }}
                       onKeyDown={e => {
                           if (e.key === "Enter") {
                               e.currentTarget.blur();
                           } else if (e.key === "Escape") {
                               setInlineRename(null);
                           }
                       }}
                       onClick={e => e.stopPropagation()}
                       onDoubleClick={e => e.stopPropagation()}
                    />
                ) : null;

                return (
                  <div 
                    key={entity.id} 
                    id={`fs-item-${entity.id}`}
                    data-id={entity.id}
                    className={`fs-item-wrapper ${currentTab.viewMode === 'grid' ? 'flex flex-col items-center justify-center p-2 rounded w-full h-[100px]' : currentTab.viewMode === 'list' ? 'flex items-center text-[12px] py-1 px-2 w-[220px] rounded' : `flex items-center text-[12px] ${isDrive ? "mb-1 p-1" : "py-[3px]"}`} border cursor-pointer 
                      ${isSelected ? "border-[#007acc]" : "border-transparent hover:bg-[#2a2d2e]"}
                      ${focusedItemId === entity.id ? "ring-1 ring-inset ring-white/30" : ""}
                      ${dragTargetId === entity.id && isDir ? "ring-2 ring-inset ring-sky-400 bg-sky-900/40" : ""}
                      ${isCut || syncOpacity ? "opacity-50 grayscale" : ""}`}
                    style={{
                        ...(((config.applyColors && isSelected) ? { backgroundColor: "var(--list-selected-bg)" } : (isSelected ? { backgroundColor: "#264f78" } : {}))),
                        ...(filterColor && !isSelected ? { backgroundColor: `${filterColor}1A` } : {})
                    }}
                    onClick={(e) => handleEntityClicked(e, entity.id)}
                    onDoubleClick={() => handleEntityDoubleClicked(entity)}
                    onDragEnter={(e) => { e.preventDefault(); if (isDir) setDragTargetId(entity.id); }}
                    onDragLeave={(e) => { e.preventDefault(); if (dragTargetId === entity.id) setDragTargetId(null); }}
                    onDragOver={(e) => { e.preventDefault(); e.dataTransfer.dropEffect = "copy"; }}
                    onDrop={(e) => { e.preventDefault(); e.stopPropagation(); setDragTargetId(null); if (isDir) { handleDrop(e, entity.id); } else { handleDrop(e); } }}
                    onContextMenu={(e) => {
                       e.preventDefault();
                       e.stopPropagation();
                       let isPart = currentTab.selectedItems.includes(entity.id);
                       if (!isPart) {
                           handleEntityClicked(e, entity.id); // Select it if not part of current selection
                       }
                       // Compute paths array for context menu bulk actions
                       let selectedIds = isPart ? currentTab.selectedItems : [entity.id];
                       let contextPaths = selectedIds.map(sid => {
                           const se = contents.find(c => c.id === sid);
                           if (!se) return null;
                           return isGlobal && se.path ? se.path : (panePath + (panePath.endsWith("/") ? "" : "/") + se.name);
                       }).filter(Boolean) as string[];

                       handleContextMenuRequest(e, panePath, entity.id, isDir, entity.name, contextPaths);
                    }}
                    draggable={true}
                    onDragStart={(e) => {
                      const fullPath = isGlobal && entity.path ? entity.path : (panePath + (panePath.endsWith("/") ? "" : "/") + entity.name);
                      
                      let dragPaths = [fullPath];
                      if (pane.tabs[pane.activeTabIndex].selectedItems.includes(entity.id)) {
                          dragPaths = pane.tabs[pane.activeTabIndex].selectedItems.map((sid: string) => {
                             const se = contents.find(c => c.id === sid);
                             if (!se) return null;
                             return isGlobal && se.path ? se.path : (panePath + (panePath.endsWith("/") ? "" : "/") + se.name);
                          }).filter(Boolean) as string[];
                      }

                      e.preventDefault(); // Stop web drag

                      // Trigger native shell drag behavior natively
                      import("../lib/ipcBridge").then(m => m.IPC.startDrag(dragPaths));
                    }}
                  >
                     {isDrive && drive ? (
                        <>
                           <div className="w-6 flex justify-center shrink-0"><HardDrive size={16} className={drive.name.includes("C:") ? "text-[#6db4e6]" : "text-gray-400"} /></div>
                           {computedViewMode !== 'grid' && computedViewMode !== 'list' && (
                             <div className="flex-1 flex items-center shadow-none focus:outline-none">
                                <div className="w-[45%] max-w-[300px] px-2">{drive.label} ({drive.name.replace(/^\//,"")})</div>
                                <div className="w-[15%] max-w-[120px] px-2">{drive.type}</div>
                                <div className="w-[15%] max-w-[100px] px-2 text-right">{(drive.totalSpace / (1024*1024*1024)).toFixed(0)} GB</div>
                                <div className="w-[25%] max-w-[160px] px-2"></div>
                                <div className="flex-1 pl-2 pr-2">
                                   <div className="w-[180px] h-[10px] bg-[#333] border border-[#555] rounded-sm mb-[2px] overflow-hidden relative">
                                      <div className={`h-full ${((drive.totalSpace - drive.freeSpace) / drive.totalSpace) > 0.9 ? "bg-[#a03050]" : "bg-[#6db4e6]"}`} style={{width: `${((drive.totalSpace - drive.freeSpace) / drive.totalSpace) * 100}%`}}></div>
                                   </div>
                                   <div className="text-[10px] text-gray-400">{(drive.freeSpace / (1024*1024*1024)).toFixed(2)} GB free of {(drive.totalSpace / (1024*1024*1024)).toFixed(2)} GB</div>
                                </div>
                             </div>
                           )}
                           {(computedViewMode === 'grid' || computedViewMode === 'list') && (
                               <div className="px-2 truncate">
                                   {drive.label} ({drive.name.replace(/^\//,"")})
                               </div>
                           )}
                        </>
                     ) : (
                        <>
                           {computedViewMode === 'grid' ? (
                             <>
                               <div className="flex-1 flex items-center justify-center min-h-[48px]">
                                  <ThumbnailIcon entity={entity} isDir={isDir} path={panePath + (panePath.endsWith("/") ? "" : "/") + entity.name} size={48} />
                               </div>
                               <div className="text-center line-clamp-2 w-full break-words text-[11px] leading-tight" title={entity.name} style={filterColor ? { color: filterColor } : {}}>
                                  {renameInput || displayName}
                               </div>
                             </>
                           ) : computedViewMode === 'list' ? (
                             <>
                               <div className="w-6 flex justify-center shrink-0">
                                  <ThumbnailIcon entity={entity} isDir={isDir} path={panePath + (panePath.endsWith("/") ? "" : "/") + entity.name} size={16} />
                               </div>
                               <div className="flex-1 px-2 whitespace-nowrap overflow-hidden text-ellipsis shadow-none focus:outline-none" style={filterColor ? { color: filterColor } : {}}>
                                  {renameInput || displayName}
                               </div>
                             </>
                           ) : (
                             <>
                               <div className="w-6 flex justify-center shrink-0">
                                  <ThumbnailIcon entity={entity} isDir={isDir} path={panePath + (panePath.endsWith("/") ? "" : "/") + entity.name} size={16} />
                               </div>
                               <div className="w-[45%] max-w-[300px] px-2 whitespace-nowrap overflow-hidden text-ellipsis shadow-none focus:outline-none" style={filterColor ? { color: filterColor } : {}}>
                                  {renameInput || displayName}
                               </div>
                               <div className="w-[15%] max-w-[120px] px-2 text-gray-400 whitespace-nowrap overflow-hidden text-ellipsis">
                                 {entity.typeDescription || (isDir ? "File Folder" : `${(entity as any).extension || ""} File`)}
                               </div>
                               <div className="w-[15%] max-w-[100px] px-2 text-right text-gray-400">
                                 {isDir ? "" : formatSize((entity as any).size)}
                               </div>
                               <div className="w-[25%] max-w-[160px] px-2 text-gray-400 whitespace-nowrap overflow-hidden text-ellipsis">
                                 {new Date(entity.modified).toLocaleDateString()} {new Date(entity.modified).toLocaleTimeString([], {hour: "2-digit", minute:"2-digit"})}
                               </div>
                               <div className="flex-1 px-2 flex gap-1 h-full items-center">
                                 {config.fileTaggingFeature !== false && entity.tags.map(t => (
                                   <span key={t} className="bg-[#333] text-[9px] px-[4px] rounded-sm text-gray-300 border border-[#444] uppercase tracking-wide leading-none py-[2px]">{t}</span>
                                 ))}
                               </div>
                             </>
                           )}
                        </>
                     )}
                  </div>
                );
              })}
          </div>
          {marquee && marquee.activePane === pane.id && (
             <div 
                className="fixed bg-sky-500/20 border border-sky-400 z-50 pointer-events-none"
                style={{
                    left: Math.min(marquee.startX, marquee.currX),
                    top: Math.min(marquee.startY, marquee.currY),
                    width: Math.abs(marquee.startX - marquee.currX),
                    height: Math.abs(marquee.startY - marquee.currY)
                }}
             />
          )}
         </div>
      </div>
    );
  };

  const customStyles = config.applyColors ? {
    '--tree-bg': config.colorConfig2,
    '--tree-text': config.colorConfig1,
    '--tab-active-bg': config.colorConfig7,
    '--tab-active-text': config.colorConfig6,
    '--tab-inactive-bg': config.colorConfig9,
    '--tab-inactive-text': config.colorConfig8,
    '--list-bg': config.colorConfig11,
    '--list-text': config.colorConfig10,
    '--list-selected-bg': config.colorConfig14,
    '--breadcrumb-bg': config.colorConfig23,
    '--breadcrumb-text': config.colorConfig22,
  } as React.CSSProperties : {};

  return (
    <div style={customStyles} className="flex flex-col h-full w-full bg-[#0f0f0f] text-[#d4d4d4] font-sans text-[12px] select-none overflow-hidden">
      
      {/* Menu Bar */}
      {config.showTopMenubar !== false && (
      <div className="flex items-center px-2 py-1 bg-[#202020] text-[#ccc]">
         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">File</div>
             {config.enableContextSubmenus !== false && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => {
                        const selArgs = panes.find(p => p.id === activePaneId)?.tabs[panes.find(p => p.id === activePaneId)!.activeTabIndex]?.selectedItems[0];
                        if (selArgs) {
                           const cPath = panes.find(p => p.id === activePaneId)?.tabs[panes.find(p => p.id === activePaneId)!.activeTabIndex]?.path;
                           const entity = getDirContents(fileSystem, cPath || '')?.find(x => x.id === selArgs);
                           if (entity) import('../lib/ipcBridge').then(({ IPC }) => IPC.shellExecute('open', `${cPath}/${entity.name}`));
                        }
                    }}><FolderOpen size={14} /> Open Selected</div>
                    <div className="h-[1px] bg-[#444] my-1"></div>

                    <div className="relative group/sub1">
                        <div className="px-3 py-1 flex justify-between items-center hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">
                           <div className="flex items-center gap-2">Recent Files</div>
                           <ChevronRight size={14} className="ml-4 opacity-70" />
                        </div>
                        <div className="hidden group-hover/sub1:block absolute top-0 left-[100%] bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[160px] z-[110]">
                            <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-400 italic">(Empty)</div>
                        </div>
                    </div>

                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => {
                       const cPath = panes.find(p => p.id === activePaneId)?.tabs[panes.find(p => p.id === activePaneId)!.activeTabIndex]?.path;
                       import('../lib/ipcBridge').then(({ IPC }) => IPC.executeFsOperation(`new-folder-${Date.now()}`, 'create-dir', `${cPath}/New folder`, ''));
                    }}><Folder size={14} className="text-[#dcb67a]" /> New Folder</div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => {
                       const cPath = panes.find(p => p.id === activePaneId)?.tabs[panes.find(p => p.id === activePaneId)!.activeTabIndex]?.path;
                       import('../lib/ipcBridge').then(({ IPC }) => IPC.executeFsOperation(`new-file-${Date.now()}`, 'create-file', `${cPath}/New Text Document.txt`, ''));
                    }}><FileText size={14} className="text-[#eee]" /> New Text Document</div>

                    <div className="relative group/sub2">
                        <div className="px-3 py-1 flex justify-between items-center hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">
                           <div className="flex items-center gap-2">New (Other)</div>
                           <ChevronRight size={14} className="ml-4 opacity-70" />
                        </div>
                        <div className="hidden group-hover/sub2:block absolute top-0 left-[100%] bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[160px] z-[110]">
                            <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">ZIP Archive</div>
                            <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">Shortcut</div>
                        </div>
                    </div>

                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => {
                        const selArgs = panes.find(p => p.id === activePaneId)?.tabs[panes.find(p => p.id === activePaneId)!.activeTabIndex]?.selectedItems[0];
                        if (selArgs) {
                           const cPath = panes.find(p => p.id === activePaneId)?.tabs[panes.find(p => p.id === activePaneId)!.activeTabIndex]?.path;
                           const entity = getDirContents(fileSystem, cPath || '')?.find(x => x.id === selArgs);
                           if (entity) import('../lib/ipcBridge').then(({ IPC }) => IPC.executeContextMenuVerb(`${cPath}/${entity.name}`, 'properties'));
                        }
                    }}>
                       <Settings size={14} /> Properties
                    </div>
                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#e81123] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => {
                       import('../lib/ipcBridge').then(({ IPC }) => IPC.executeContextMenuVerb('exit', 'exit'));
                    }}>
                       Exit
                    </div>
                 </div>
             )}
         </div>
         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">Edit</div>
             {config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => {
                        import('../lib/ipcBridge').then(({ IPC }) => IPC.executeUndo());
                    }}><Undo size={14} /> Undo</div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => {
                        import('../lib/ipcBridge').then(({ IPC }) => IPC.executeRedo());
                    }}><Redo size={14} /> Redo</div>
                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => {
                        const selArgs = panes.find(p => p.id === activePaneId)?.tabs[panes.find(p => p.id === activePaneId)!.activeTabIndex]?.selectedItems[0];
                        if (selArgs) {
                           const cPath = panes.find(p => p.id === activePaneId)?.tabs[panes.find(p => p.id === activePaneId)!.activeTabIndex]?.path;
                           const entity = getDirContents(fileSystem, cPath || '')?.find(x => x.id === selArgs);
                           if (entity) import('../lib/ipcBridge').then(({ IPC }) => IPC.shellExecute('copyPath', `${cPath}/${entity.name}`));
                        }
                    }}><Copy size={14} /> Copy Path</div>

                    <div className="relative group/sub3">
                        <div className="px-3 py-1 flex justify-between items-center hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">
                           <div className="flex items-center gap-2">Copy To...</div>
                           <ChevronRight size={14} className="ml-4 opacity-70" />
                        </div>
                        <div className="hidden group-hover/sub3:block absolute top-0 left-[100%] bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[160px] z-[110]">
                            <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">Other Pane</div>
                            <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">Browse...</div>
                        </div>
                    </div>

                    <div className="relative group/sub4">
                        <div className="px-3 py-1 flex justify-between items-center hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">
                           <div className="flex items-center gap-2">Move To...</div>
                           <ChevronRight size={14} className="ml-4 opacity-70" />
                        </div>
                        <div className="hidden group-hover/sub4:block absolute top-0 left-[100%] bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[160px] z-[110]">
                            <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">Other Pane</div>
                            <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">Browse...</div>
                        </div>
                    </div>

                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => setIsSmartToolsOpen(true)}>
                       <Sparkles size={14} className="text-yellow-400" /> Smart Rename
                    </div>
                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#e81123] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => {
                        const activePane = panes.find(p => p.id === activePaneId);
                        if (activePane) {
                            const tab = activePane.tabs[activePane.activeTabIndex];
                            const selectedIds = tab.selectedItems;
                            if (selectedIds && selectedIds.length > 0) {
                               const cPath = tab.path;
                               const dirContents = getDirContents(fileSystem, cPath || '') || [];
                               const entities = dirContents.filter((x: any) => selectedIds.includes(x.id));
                               if (entities.length > 0) {
                                   handleDeleteRequest(entities, cPath);
                               }
                            }
                        }
                    }}><Scissors size={14} /> Delete Selected</div>
                 </div>
             )}
         </div>
         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">View</div>
             {config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={toggleDualPane}>
                       <Columns size={14} /> {isDualPane ? 'Single Pane' : 'Dual Pane'}
                    </div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => setIsPreviewPanelOpen(p => !p)}>
                        <Eye size={14} /> {isPreviewPanelOpen ? 'Hide Preview Panel' : 'Show Preview Panel'}
                    </div>
                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2">
                       <RefreshCw size={14} /> Refresh
                    </div>
                 </div>
             )}
         </div>
         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">Go</div>
             {config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => goBack()}>
                       <ArrowLeft size={14} /> Back
                    </div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => goForward()}>
                       <ArrowRight size={14} /> Forward
                    </div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => goUp()}>
                       <ArrowUp size={14} /> Up One Level
                    </div>
                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => setCurrentPath('/')}>
                       <Monitor size={14} /> This PC
                    </div>
                 </div>
             )}
         </div>
         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">Tools</div>
             {config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => startFolderCompare()}>
                       <RefreshCw size={14} className="text-purple-400" /> Sync / Compare Folders
                    </div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => setIsSmartToolsOpen(true)}>
                       <Sparkles size={14} className="text-yellow-400" /> AI Smart Workspace Tools
                    </div>
                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => setIsConfigDialogOpen(true)}>
                       <Settings size={14} /> Configuration
                    </div>
                 </div>
             )}
         </div>
         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">Favorites</div>
             {config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Added to favorites.")}>Toggle Favorite Folder</div>
                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="relative group/sub">
                        <div className="px-3 py-1 flex justify-between items-center hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">
                           <div className="flex items-center gap-2">Manage Favorites</div>
                           <ChevronRight size={14} className="ml-4 opacity-70" />
                        </div>
                        <div className="hidden group-hover/sub:block absolute top-0 left-[100%] bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[160px] z-[110]">
                            <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Opening favorites manager...")}>Organize Favorites...</div>
                        </div>
                    </div>
                 </div>
             )}
         </div>

         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">Tags</div>
             {config.fileTaggingFeature && config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Applied Red Tag.")}>Tag 1 (Red)</div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Applied Orange Tag.")}>Tag 2 (Orange)</div>
                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Opening tag manager...")}>Manage Tags...</div>
                 </div>
             )}
         </div>

         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">User</div>
             {config.userDefinedCommands && config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Executing Custom Command 1...")}>Custom Command 1</div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Executing Custom Command 2...")}>Custom Command 2</div>
                 </div>
             )}
         </div>

         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">Scripting</div>
             {config.scripting && config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Loading script file...")}>Load Script File...</div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Running script...")}>Run Script...</div>
                 </div>
             )}
         </div>

         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">Panes</div>
             {config.dualPaneFeature && config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={toggleDualPane}>Toggle Dual Pane</div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Swapped Panes.")}>Swap Panes</div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Synced Panes.")}>Sync Panes</div>
                 </div>
             )}
         </div>

         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">Tabsets</div>
             {config.tabsets && config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => {
                        setIsSaveTabsetOpen(true);
                        setTabsetNameInput('');
                    }}>Save Tabset As...</div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setIsLoadTabsetOpen(true)}>Load Tabset...</div>
                 </div>
             )}
         </div>

         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">Window</div>
             {config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Pinned Window.")}>Always on Top</div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Minimized to Tray.")}>Minimize to Tray</div>
                 </div>
             )}
         </div>

         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">Help</div>
             {config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Opening Help Topics...")}>Help Topics</div>
                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("You are on the latest version.")}>Check for Updates...</div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => import('../lib/ipcBridge').then(({ IPC }) => IPC.shellExecute('open', 'https://github.com'))}>About Applet</div>
                 </div>
             )}
         </div>
      </div>
      )}

      {/* Main Toolbar */}
      <div 
         className="flex items-center px-1 py-1 bg-[#1a1a1a] border-b border-[#333] shrink-0 flex-wrap"
         onWheel={(e) => {
             if (e.shiftKey) {
                 const profiles = config.toolbarProfiles || [];
                 if (profiles.length < 2) return;
                 let newIdx = (config.activeToolbarProfileIndex || 0) + (e.deltaY > 0 ? 1 : -1);
                 if (newIdx >= profiles.length) newIdx = 0;
                 if (newIdx < 0) newIdx = profiles.length - 1;
                 updateConfig({ activeToolbarProfileIndex: newIdx });
             }
         }}
      >
         {(config.toolbarProfiles?.[config.activeToolbarProfileIndex || 0] || []).map((item: any, i: number) => {
             const def = AVAILABLE_ITEMS.find(a => a.id === item.id);
             if (!def) return null;
             
             if (item.id === 'separator') return <div key={i} className="w-[1px] h-4 bg-[#444] mx-1"></div>;
             if (item.id === 'spacer') return <div key={i} className="w-2"></div>;
             if (item.id === 'new_row') return <div key={i} className="w-full h-0 basis-full"></div>;

             return (
                 <ToolbarButton 
                     key={i} 
                     icon={def.icon} 
                     icon3d={def.icon3d}
                     color={def.color} 
                     title={def.label}
                     onClick={() => {
                         switch(item.id) {
                           case 'nav_back': goBack(); break;
                           case 'nav_forward': goForward(); break;
                           case 'nav_up': goUp(); break;
                           case 'go_home': setCurrentPath('/'); break;
                           case 'undo': import('../lib/ipcBridge').then(({ IPC }) => IPC.executeUndo()); break;
                           case 'redo': import('../lib/ipcBridge').then(({ IPC }) => IPC.executeRedo()); break;
                           case 'sync_folders': startFolderCompare(); break;
                           case 'config': setIsConfigDialogOpen(true); break;
                           case 'wrench': setIsToolbarConfigOpen(true); break;
                            case 'delete':
                               const activePaneForBtn = panes.find(p => p.id === activePaneId);
                               if (activePaneForBtn) {
                                   const tab = activePaneForBtn.tabs[activePaneForBtn.activeTabIndex];
                                   if (tab.selectedItems.length > 0) {
                                       const dirContents = safeGetDirContents(fileSystem, tab.path) || [];
                                       const selectedEntities = dirContents.filter((x: any) => tab.selectedItems.includes(x.id));
                                       if (selectedEntities.length > 0) {
                                           handleDeleteRequest(selectedEntities, tab.path);
                                       }
                                   }
                               }
                               break;
                           case 'cmd': 
                           case 'ps':
                           case 'taskmgr':
                           case 'regedit': 
                               import('../lib/ipcBridge').then(({ IPC }) => IPC.shellExecute(`launch-${item.id}`, ''));
                               break;
                         }
                     }}
                 />
             );
         })}
         
         {/* Drive letters scoped to active pane (always show at end for fast access) */}
         <div className="w-[1px] h-4 bg-[#444] mx-2"></div>
         <div className="flex text-[10px] items-center gap-[2px] mx-1 font-mono">
            {drives.map(d => (
                <span key={d.name} className="bg-[#333] px-1 py-[1px] rounded border border-[#555] cursor-pointer hover:bg-[#444]" onClick={() => setCurrentPath(d.name)}>{d.name}</span>
            ))}
            {!drives.length && (
              <><span className="bg-[#333] px-1 py-[1px] rounded border border-[#555] cursor-pointer hover:bg-[#444]" onClick={() => setCurrentPath('/C:')}>C:</span><span className="bg-[#333] px-1 py-[1px] rounded border border-[#555] cursor-pointer hover:bg-[#444]" onClick={() => setCurrentPath('/D:')}>D:</span></>
            )}
         </div>
         <div className="w-[1px] h-4 bg-[#444] mx-2"></div>
         {config.dualPaneFeature !== false && (
            <ToolbarButton icon={Columns} color={isDualPane ? "#6db4e6" : "#666"} className="ml-1" title="Toggle Dual Pane View" onClick={toggleDualPane} />
         )}
         <div className="flex-1"></div>
         <ToolbarButton icon={PanelBottom} color={isBottomPanelOpen ? "#6db4e6" : "#666"} title="Toggle Bottom Plugin Panel" onClick={() => setIsBottomPanelOpen(prev => !prev)} />
         <ToolbarButton icon={Eye} color={isPreviewPanelOpen ? "#6db4e6" : "#666"} title="Toggle Right Side Preview Panel" onClick={() => setIsPreviewPanelOpen(prev => !prev)} />
      </div>

      {/* Omni-Filter Bar */}
      <div className="flex bg-[#111] px-2 py-1 items-center border-b border-[#333] shrink-0">
         <Search size={14} className="text-gray-400 mr-2" />
         <input 
            ref={omniFilterRef}
            type="text"
            className="flex-1 bg-[#1a1a1a] text-white border border-[#444] rounded px-2 py-[2px] text-[12px] focus:outline-none focus:border-blue-500 transition-colors placeholder-[#666]"
            placeholder="Type '/' to instantly fuzzy-filter files in the active pane..."
            value={filterText}
            onChange={(e) => setFilterText(e.target.value)}
            onKeyDown={(e) => {
               if (e.key === 'Escape') {
                   setFilterText('');
                   omniFilterRef.current?.blur();
               }
            }}
         />
         {filterText && (
             <button onClick={() => setFilterText('')} className="ml-2 hover:bg-[#333] text-gray-400 hover:text-white px-2 py-[2px] rounded border border-transparent hover:border-[#555] transition-colors">
                <X size={14} />
             </button>
         )}
      </div>

      {/* Main Split Architecture */}
      <div className="flex flex-1 overflow-hidden min-h-0 relative">
         <ResizablePanelGroup 
             direction="horizontal" 
             onLayout={(sizes) => updateConfig({ workspaceLayoutOuter: sizes })}
         >
            {/* Sidebar Tree */}
            <ResizablePanel defaultSize={15} minSize={0} collapsible={true} className="shrink-0 border-r border-[#282830] bg-[#111111] overflow-y-auto py-2 no-scrollbar" style={config.applyColors ? { backgroundColor: 'var(--tree-bg)', color: 'var(--tree-text)' } : {}}>
               <LeftSidebar 
                  onBackgroundClick={() => { setSelectedItems([], activePaneId); setFocusedItemId(null); setLastClickData(null); setInlineRename(null); }}
                  drivesContent={drives.length > 0 && drives.map(drive => {
                     const used = drive.totalSpace - drive.freeSpace;
                     const pct = (used / drive.totalSpace) * 100;
                     const formatBytesSpc = (bytes: number) => {
                        const k = 1024, sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
                        if (bytes === 0) return '0 B';
                        const i = Math.floor(Math.log(bytes) / Math.log(k));
                        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
                     };
                     return (
                        <div 
                           key={drive.name} 
                           className="px-3 py-2 cursor-pointer hover:bg-[#202020] group border-l-2 border-transparent hover:border-[#3b82f6] transition-all"
                           onClick={() => setCurrentPath(drive.name)}
                           onContextMenu={(e) => handleContextMenuRequest(e, drive.name, null, true, drive.label)}
                        >
                           <div className="flex items-center gap-2 mb-1.5 text-[#ccc] group-hover:text-white">
                              <HardDrive size={14} className={drive.name.includes('C:') ? 'text-sky-400' : 'text-gray-400 group-hover:text-[#dcb67a]'} />
                              <span className="text-[11px] font-medium truncate">{drive.label} <span className="text-[#666] font-normal">({drive.name.replace(/^\//,'')})</span></span>
                           </div>
                           <div className="w-full bg-[#2a2a2a] h-[4px] rounded-full overflow-hidden mb-1.5 shadow-inner">
                              <div className={`h-full opacity-90 ${pct > 90 ? 'bg-red-500' : 'bg-sky-500'}`} style={{width: `${pct}%`}}></div>
                           </div>
                           <div className="flex justify-between text-[9px] text-[#777] font-mono tracking-tighter">
                              <span><strong className="text-[#aaa] font-medium">{formatBytesSpc(drive.freeSpace)}</strong> free</span>
                              <span>{formatBytesSpc(drive.totalSpace)}</span>
                           </div>
                        </div>
                     );
                  })}
                  quickAccessContent={[...shortcuts, ...(config.pinnedFavorites || [])].length > 0 && [...shortcuts, ...(config.pinnedFavorites || [])].map(s => {
                     const getIcon = (ic: string) => {
                        if (ic === 'desktop') return <Monitor size={14} className="text-emerald-400" />
                        if (ic === 'documents') return <File size={14} className="text-amber-400" />
                        if (ic === 'downloads') return <ArrowDownCircle size={14} className="text-sky-400" />
                        return <Folder size={14} className="text-purple-400" />
                     };

                     return (
                        <div 
                           key={s.path}
                           className="flex items-center gap-2.5 px-3 py-1.5 cursor-pointer hover:bg-[#202020] text-[#ccc] hover:text-white border-l-2 border-transparent hover:border-[#3b82f6] transition-all"
                           onClick={() => setCurrentPath(s.path)}
                           onContextMenu={(e) => handleContextMenuRequest(e, s.path, null, true, s.name)}
                        >
                           {getIcon(s.icon)}
                           <span className="text-[11px] font-medium">{s.name}</span>
                        </div>
                     );
                  })}
                  treeContent={<div className="px-1">{treeData.map((item, i) => <TreeItem key={i} {...item} config={config} currentPath={currentPath} onClick={(p: string) => p ? setCurrentPath(p) : item.onClick?.()} onContextMenuClick={(e: any, path: string, name: string) => handleContextMenuRequest(e, path, null, true, name)} inlineRename={inlineRename} setInlineRename={setInlineRename} />)}</div>}
               />
            </ResizablePanel>
            <ResizableHandle className="w-1 bg-[#282830] transition-colors hover:bg-sky-500 cursor-col-resize shrink-0 z-20" />

            {/* Center Workspace Area */}
            <ResizablePanel defaultSize={85}>
               <ResizablePanelGroup 
                   direction="vertical" 
                   onLayout={(sizes) => updateConfig({ workspaceLayoutInner: sizes })}
               >
                  {/* Main File Grid */}
                  <ResizablePanel defaultSize={80} minSize={20}>
                     <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#202020] relative">
                        {isSyncMode && (
                           <div className="w-full bg-[#36274c] border-b border-[#5e4186] px-4 py-2 flex items-center justify-between shrink-0 z-30 shadow-md">
                               <div className="flex items-center gap-3">
                                  <RefreshCw size={16} className={`text-white ${isSyncing ? "animate-spin" : ""}`} />
                                  <span className="font-semibold text-white">Compare & Sync</span>
                                  {!isSyncing && syncResults && (
                                      <span className="text-gray-300 ml-4 font-mono text-xs">{Object.keys(syncResults).length} differences</span>
                                  )}
                               </div>
                               <div className="flex items-center gap-2">
                                  <button disabled={isSyncing} onClick={() => executeFolderSync('mirror')} className="px-3 py-1 bg-[#10b981] hover:bg-[#059669] text-white rounded shadow text-xs font-semibold flex items-center gap-1 disabled:opacity-50">
                                     <ArrowRight size={14}/> Mirror L {'->'} R
                                  </button>
                                  <button disabled={isSyncing} onClick={() => executeFolderSync('updateTarget')} className="px-3 py-1 bg-[#3b82f6] hover:bg-[#2563eb] text-white rounded shadow text-xs font-semibold flex items-center gap-1 disabled:opacity-50">
                                     <ArrowRight size={14}/> Update Target
                                  </button>
                                  <div className="w-[1px] h-4 bg-[#5e4186] mx-2"></div>
                                  <button onClick={() => { setIsSyncMode(false); setSyncResults({}); }} className="px-3 py-1 bg-[#ef4444] hover:bg-[#dc2626] text-white rounded shadow text-xs font-semibold">
                                     Close
                                  </button>
                               </div>
                           </div>
                        )}
                        <div className="flex flex-1 overflow-hidden min-h-0">
                           {renderPane(panes[0], 0)}
                           
                           {config.dualPaneFeature !== false && isDualPane && panes[1] && (
                              <>
                                 <div className="w-1 bg-[#282830] cursor-col-resize shrink-0 shadow-[inset_0_0_2px_rgba(0,0,0,0.5)] z-20"></div>
                                 {renderPane(panes[1], 1)}
                              </>
                           )}
                        </div>
                     </div>
                  </ResizablePanel>

                  {isBottomPanelOpen && (
                     <>
                        <ResizableHandle className="h-1 bg-[#282830] transition-colors hover:bg-sky-500 cursor-row-resize shrink-0 z-20" />
                        {/* Bottom Plugin Panel */}
                        <ResizablePanel defaultSize={20} minSize={0} collapsible={true} className="border-t border-[#282830] flex min-h-0 z-30 bg-[#181818]">
                           <div className="flex-1 overflow-hidden h-full flex flex-col">
                              <BottomPluginPanel entity={focusedItemId ? getEntityByPath(fileSystem, focusedItemId) : null} config={config} drives={drives} focusedPath={currentPath} selectedItems={(panes.find(p => p.id === activePaneId)?.tabs[panes.find(p => p.id === activePaneId)?.activeTabIndex ?? 0]?.selectedItems || []).map(id => {
                                 let items = currentPath === '/' || currentPath === '/this-pc' ? rootDriveEntities : safeGetDirContents(fileSystem, currentPath);
                                 if (isGlobal) items = globalSearchResults || [];
                                 return items.find((x: any) => x.id === id)?.name || id;
                              })} onFilterChange={setGridFilters} />
                           </div>
                        </ResizablePanel>
                     </>
                  )}
               </ResizablePanelGroup>
            </ResizablePanel>

            {isPreviewPanelOpen && config.rightSidebarEnabled !== false && (
               <>
                  <ResizableHandle className="w-1 bg-[#282830] transition-colors hover:bg-sky-500 cursor-col-resize shrink-0 z-20" />
                  <ResizablePanel defaultSize={15} minSize={0} collapsible={true} className="shrink-0 border-l border-[#282830] bg-[#111111] overflow-hidden z-10 flex min-h-0">
                     <div className="w-full h-full flex flex-col min-w-[200px]">
                        <RightPreviewPanel 
                           entity={focusedItemId ? getEntityByPath(fileSystem, focusedItemId) : null} 
                           path={focusedItemId}
                        />
                     </div>
                  </ResizablePanel>
               </>
            )}
         </ResizablePanelGroup>
      </div>

      {/* Footer Status Bar scoped to active pane metrics */}
      <div className="bg-[#1f1f1f] border-t border-[#444] px-2 py-1 flex items-center justify-between text-[11px] text-gray-400 shrink-0">
         <div>
           {activeContents ? `${activeContents.length} item(s)` : `2 drives`} 
           {activeTab.selectedItems.length > 0 ? ` | ${activeTab.selectedItems.length} selected` : ''}
         </div>
         <div className="flex items-center gap-4">
            <div>total free: 38.12 GB (2%) &nbsp; capacity: 2.04 TB</div>
            <div className="flex items-center">
               <Monitor size={12} className="text-[#6db4e6] mr-1" />
               <span className="bg-[#1c1c1c] border border-[#333] px-2 py-[2px] rounded-sm">total used: 2.00 TB free: 38.12 GB (2%)</span>
            </div>
         </div>
      </div>
      
      {/* Overlays / Modals */}
      {isSaveTabsetOpen && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
           <div className="bg-[#1f1f1f] border border-[#444] rounded-md shadow-2xl p-6 w-[400px]">
               <h2 className="text-white text-lg font-semibold mb-4">Save Tabset As...</h2>
               <div className="mb-4">
                  <label className="block text-gray-300 text-sm mb-2">Tabset Name</label>
                  <input
                     autoFocus
                     type="text"
                     value={tabsetNameInput}
                     onChange={(e) => setTabsetNameInput(e.target.value)}
                     className="w-full bg-[#111] text-white border border-[#444] rounded px-3 py-1.5 outline-none focus:border-sky-500"
                     onKeyDown={(e) => {
                         if (e.key === 'Enter' && tabsetNameInput.trim()) {
                             const newTabset = { id: `ts-${Date.now()}`, name: tabsetNameInput.trim(), panes: JSON.parse(JSON.stringify(panes)) };
                             updateConfig({ savedTabsets: [...(config.savedTabsets || []), newTabset] });
                             setIsSaveTabsetOpen(false);
                             setToastMessage(`Saved Tabset: ${newTabset.name}`);
                         }
                         if (e.key === 'Escape') setIsSaveTabsetOpen(false);
                     }}
                  />
               </div>
               <div className="flex justify-end gap-2">
                  <button onClick={() => setIsSaveTabsetOpen(false)} className="px-4 py-1.5 text-gray-300 hover:bg-[#333] rounded">Cancel</button>
                  <button onClick={() => {
                      if (!tabsetNameInput.trim()) return;
                      const newTabset = { id: `ts-${Date.now()}`, name: tabsetNameInput.trim(), panes: JSON.parse(JSON.stringify(panes)) };
                      updateConfig({ savedTabsets: [...(config.savedTabsets || []), newTabset] });
                      setIsSaveTabsetOpen(false);
                      setToastMessage(`Saved Tabset: ${newTabset.name}`);
                  }} className="px-4 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded">Save</button>
               </div>
           </div>
        </div>
      )}

      {isLoadTabsetOpen && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm" onClick={() => setIsLoadTabsetOpen(false)}>
           <div className="bg-[#1f1f1f] border border-[#444] rounded-md shadow-2xl p-6 w-[400px] max-h-[80vh] flex flex-col" onClick={e => e.stopPropagation()}>
               <h2 className="text-white text-lg font-semibold mb-4">Load Tabset</h2>
               <div className="flex-1 overflow-y-auto min-h-[100px] mb-4 border border-[#333] rounded">
                   {!(config.savedTabsets && config.savedTabsets.length > 0) ? (
                       <div className="text-gray-500 text-sm p-4 text-center">No saved tabsets.</div>
                   ) : (
                       config.savedTabsets.map((ts) => (
                           <div key={ts.id} className="flex justify-between items-center px-4 py-2 hover:bg-[#2a2d2e] border-b border-[#333] last:border-0 cursor-pointer text-gray-200" onClick={() => {
                               setPanes(JSON.parse(JSON.stringify(ts.panes)));
                               setIsLoadTabsetOpen(false);
                               setToastMessage(`Loaded Tabset: ${ts.name}`);
                           }}>
                               <span>{ts.name}</span>
                               <button onClick={(e) => {
                                   e.stopPropagation();
                                   updateConfig({ savedTabsets: config.savedTabsets?.filter(s => s.id !== ts.id) });
                               }} className="text-gray-500 hover:text-red-400">
                                   <Trash2 size={14} />
                               </button>
                           </div>
                       ))
                   )}
               </div>
               <div className="flex justify-end">
                  <button onClick={() => setIsLoadTabsetOpen(false)} className="px-4 py-1.5 text-gray-300 hover:bg-[#333] rounded">Close</button>
               </div>
           </div>
        </div>
      )}

      {isSmartToolsOpen && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <SmartToolsDialog 
            selectedFiles={activeFilesMap}
            onApplyRename={handleApplyRename}
            onClose={() => setIsSmartToolsOpen(false)} 
          />
        </div>
      )}
      
      {isToolbarConfigOpen && (
        <ToolbarConfigurator onClose={() => setIsToolbarConfigOpen(false)} />
      )}

      {isConfigDialogOpen && (
        <ConfigurationDialog onClose={() => setIsConfigDialogOpen(false)} />
      )}

      {/* Global Progress Bars */}
      {Object.keys(transferProgress).length > 0 && (
         <div className="absolute bottom-10 right-10 w-[420px] flex flex-col gap-3 z-50">
            {Object.keys(transferProgress).map((opId) => {
               const prog = transferProgress[opId];
               const formatBytes = (bytes: number) => {
                 if (bytes === 0) return '0 B';
                 const k = 1024, sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
                 const i = Math.floor(Math.log(bytes) / Math.log(k));
                 return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
               };
               return (
               <div key={opId} className="bg-[#1a1a1a] border border-[#3e3e42] shadow-2xl rounded p-4 flex flex-col items-stretch">
                 <div className="flex justify-between items-center mb-2">
                   <div className="flex items-center gap-3">
                     {prog.percentage < 100 ? (
                        <div className="scale-[0.5] -ml-2 -my-4"><Spinner /></div>
                     ) : (
                        <div className="text-green-500 scale-[0.8]"><Sparkles size={24} /></div>
                     )}
                     <div className="text-[13px] text-white font-medium truncate max-w-[200px]">
                        {prog.percentage < 100 ? `Copying ${prog.itemsCompleted} of ${prog.totalItems} items` : `Completed`}
                     </div>
                   </div>
                   <div className="text-[12px] text-gray-400">{Math.round(prog.percentage)}%</div>
                 </div>
                 <div className="text-[11px] text-gray-400 mb-3 truncate pl-2" title={prog.file}>
                   {prog.file}
                 </div>
                 <div className="w-full bg-[#1e1e1e] h-2 rounded-full overflow-hidden mb-3 border border-[#333]">
                   <div 
                     className={`h-full transition-all duration-300 ease-out ${prog.percentage >= 100 ? 'bg-green-500' : 'bg-[#007acc]'}`}
                     style={{ width: `${prog.percentage}%` }}
                   ></div>
                 </div>
                 <div className="flex justify-between items-center text-[11px] text-gray-400">
                   <div>
                     {prog.percentage < 100 ? `${formatBytes(prog.speedBytesPerSecond)}/s` : ''}
                   </div>
                   <div>
                     {formatBytes(prog.bytesTransferred)} / {formatBytes(prog.totalBytes)}
                   </div>
                 </div>
               </div>
               );
            })}
         </div>
      )}

      {/* Custom Context Menu */}
      {contextMenu && (
        <div 
          className="fixed z-[100] bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px]"
          style={{ top: contextMenu.y, left: contextMenu.x }}
          onClick={(e) => e.stopPropagation()} // Prevent closing immediately when clicking inside
        >
          {(() => {
             const renderNativeItems = () => {
                if (!contextMenu.nativeContextItems || contextMenu.nativeContextItems.length === 0) return null;
                
                return contextMenu.nativeContextItems.map((item, i) => item.separator ? (
                    <div key={i} className="h-[1px] bg-[#444] my-1"></div>
                ) : (
                    <div key={i} className={`px-3 py-1 flex items-center gap-2 hover:bg-[#007acc] cursor-pointer text-sm ${item.isPrimary ? 'text-white font-bold' : 'text-gray-200'}`} onClick={() => {
                        import('../lib/ipcBridge').then(({ IPC }) => {
                            if (contextMenu.entityId === null) {
                                IPC.executeContextMenuVerb(contextMenu.path, item.verb || item.id);
                            } else {
                                const targetPaths = (contextMenu.selectedPaths && contextMenu.selectedPaths.length > 0) 
                                    ? contextMenu.selectedPaths 
                                    : [`${contextMenu.path}/${contextMenu.entityName}`];
                                IPC.executeContextMenuVerb(targetPaths, item.verb || item.id);
                            }
                        });
                        setContextMenu(null);
                    }}>
                        <div className="w-5 flex justify-center items-center">
                          {item.icon === 'Settings' || item.verb === 'properties' ? <Settings size={14} className="text-[#a8a8a8] drop-shadow-md" /> : 
                           item.icon === 'Trash' || item.verb === 'delete' ? <Trash2 size={14} className="text-red-500 drop-shadow-md" /> : 
                           item.icon === 'Copy' || item.verb === 'copy' ? <Copy size={14} className="text-[#60a5fa] drop-shadow-md" /> : 
                           item.icon === 'Cut' || item.verb === 'cut' ? <Scissors size={14} className="text-[#f472b6] drop-shadow-md" /> : 
                           item.icon === 'Paste' || item.verb === 'paste' ? <Clipboard size={14} className="text-[#34d399] drop-shadow-md" /> : 
                           item.icon === 'Open' || item.verb === 'open' ? (contextMenu.isDirectory ? <FolderOpen size={14} className="text-[#fbbf24] drop-shadow-md" /> : <File size={14} className="text-[#9ca3af] drop-shadow-md" />) :
                           item.verb === 'rename' ? <FileText size={14} className="text-[#fbbf24] drop-shadow-md" /> :
                           <div className="w-3 h-3 rounded-full bg-gradient-to-br from-gray-500 to-gray-700 shadow-inner border border-gray-600" />}
                        </div>
                        <span>{item.label || item.id}</span>
                    </div>
                ));
             };

             if (contextMenu.entityId === null) {
                 return (
                    <>
                       <div className="px-3 py-1 flex items-center gap-2 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => {
                          setContextMenu(null);
                       }}>
                          <RefreshCw size={14} /> Refresh
                       </div>
                       <div className="relative group">
                          <div className="px-3 py-1 flex justify-between items-center hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">
                             <div className="flex items-center gap-2">Sort By</div>
                             {config.enableContextSubmenus && <ChevronRight size={14} className="ml-4 opacity-70" />}
                          </div>
                          {config.enableContextSubmenus && (
                              <div className="hidden group-hover:block absolute top-0 left-full ml-1 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[160px] z-[120]">
                                  <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={(e) => { e.stopPropagation(); setContextMenu(null); }}>Name</div>
                                  <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={(e) => { e.stopPropagation(); setContextMenu(null); }}>Date Modified</div>
                                  <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={(e) => { e.stopPropagation(); setContextMenu(null); }}>Type</div>
                                  <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={(e) => { e.stopPropagation(); setContextMenu(null); }}>Size</div>
                              </div>
                          )}
                       </div>
                       <div className="h-[1px] bg-[#444] my-1"></div>
                       <div className="relative group">
                          <div className="px-3 py-1 flex justify-between items-center hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">
                             <div className="flex items-center gap-2">New</div>
                             {config.enableContextSubmenus && <ChevronRight size={14} className="ml-4 opacity-70" />}
                          </div>
                          {config.enableContextSubmenus && (
                              <div className="hidden group-hover:block absolute top-0 left-[98%] bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[160px] z-[120]">
                                  <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={(e) => { 
                                      e.stopPropagation(); 
                                      import('../lib/ipcBridge').then(({ IPC }) => IPC.executeFsOperation(`new-folder-${Date.now()}`, 'create-dir', `${contextMenu.path}/New folder`, ''));
                                      setContextMenu(null); 
                                  }}><Folder size={14} className="text-[#dcb67a]" /> Folder</div>
                                  <div className="h-[1px] bg-[#444] my-1"></div>
                                  <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={(e) => { 
                                      e.stopPropagation(); 
                                      import('../lib/ipcBridge').then(({ IPC }) => IPC.executeFsOperation(`new-file-${Date.now()}`, 'create-file', `${contextMenu.path}/New Text Document.txt`, ''));
                                      setContextMenu(null); 
                                  }}><FileText size={14} className="text-[#eee]" /> Text Document</div>
                              </div>
                          )}
                       </div>
                       <div className="h-[1px] bg-[#444] my-1"></div>
                       <div className="px-3 py-1 flex items-center gap-2 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => {
                           import('../lib/ipcBridge').then(({ IPC }) => {
                               const targetPaths = (contextMenu.selectedPaths && contextMenu.selectedPaths.length > 0) ? contextMenu.selectedPaths : [`${contextMenu.path}/${contextMenu.entityName}`];
                               IPC.executeContextMenuVerb(targetPaths, 'properties');
                           });
                           setContextMenu(null);
                       }}>
                          <Settings size={14} /> Properties
                       </div>
                       <div className="h-[1px] bg-[#444] my-1"></div>
                       {renderNativeItems()}
                    </>
                 );
             }

             // bndzActions and bndzGlobal logic
             const bndzActions = contextMenu.isDirectory ? (
               <>
                 <div className="px-3 py-1 flex items-center gap-2 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => {
                    setContextMenu(null);
                 }}>
                    Open in New Tab
                 </div>
                 {(() => {
                     const fullPath = contextMenu.entityId && contextMenu.path !== contextMenu.entityId && !contextMenu.path.endsWith(contextMenu.entityName || '') ? `${contextMenu.path}/${contextMenu.entityName}` : (contextMenu.path || '');
                     const currentPinned = config.pinnedFavorites || [];
                     const isPinned = currentPinned.find((p: any) => p.path === fullPath);
                     
                     if (isPinned) {
                         return (
                             <div className="px-3 py-1 flex items-center gap-2 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => {
                                 updateConfig({ pinnedFavorites: currentPinned.filter((p: any) => p.path !== fullPath) });
                                 setContextMenu(null);
                             }}>
                                <Star size={14} className="text-gray-400" /> Unpin from Quick Access
                             </div>
                         );
                     } else {
                         return (
                             <div className="px-3 py-1 flex items-center gap-2 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => {
                                if (contextMenu.entityName) {
                                   updateConfig({ 
                                      pinnedFavorites: [...currentPinned, { name: contextMenu.entityName, path: fullPath, icon: 'folder' }] 
                                   });
                                }
                                setContextMenu(null);
                             }}>
                                <Star size={14} className="text-yellow-400" /> Pin to Quick Access
                             </div>
                         );
                     }
                 })()}
               </>
             ) : (
               <>
                 <div className="px-3 py-1 flex items-center gap-2 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => {
                    setIsSmartToolsOpen(true);
                    setContextMenu(null);
                 }}>
                    <Sparkles size={14} className="text-yellow-400" /> Smart Rename
                 </div>
                 <div className="relative group">
                    <div className="px-3 py-1 flex justify-between items-center hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => {
                        if (!config.enableContextSubmenus) {
                           import('../lib/ipcBridge').then(({ IPC }) => IPC.shellExecute('openWith', `${contextMenu.path}/${contextMenu.entityName}`));
                           setContextMenu(null);
                        }
                    }}>
                       <div className="flex items-center gap-2"><PlayCircle size={14} /> Open With</div>
                       {config.enableContextSubmenus && <ChevronRight size={14} className="ml-4 opacity-70" />}
                    </div>
                    {config.enableContextSubmenus && (
                        <div className="hidden group-hover:block absolute top-0 left-[98%] bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[160px] z-[120]">
                            <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={(e) => { e.stopPropagation(); import('../lib/ipcBridge').then(({ IPC }) => {
                                const targetPaths = (contextMenu.selectedPaths && contextMenu.selectedPaths.length > 0) ? contextMenu.selectedPaths : [`${contextMenu.path}/${contextMenu.entityName}`];
                                IPC.shellExecute('openWith', targetPaths);
                            }); setContextMenu(null); }}>Choose Default App...</div>
                            <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={(e) => { e.stopPropagation(); setContextMenu(null); }}>Notepad</div>
                            <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={(e) => { e.stopPropagation(); setContextMenu(null); }}>Visual Studio Code</div>
                        </div>
                    )}
                 </div>
               </>
             );

             const bndzGlobal = (() => {
               const targetPaths = (contextMenu.selectedPaths && contextMenu.selectedPaths.length > 0) ? contextMenu.selectedPaths : [`${contextMenu.path}/${contextMenu.entityName}`];
               return (
               <>
                 <div className="relative group">
                    <div className="px-3 py-1 flex justify-between items-center hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">
                       <div className="flex items-center gap-2"><Monitor size={14} /> Open in...</div>
                       <ChevronRight size={14} className="ml-4 opacity-70" />
                    </div>
                    <div className="hidden group-hover:block absolute top-[10%] left-[98%] bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[120]">
                       <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={(e) => {
                          import('../lib/ipcBridge').then(({ IPC }) => IPC.shellExecute('openTerminal', targetPaths));
                          setContextMenu(null);
                       }}>
                          Open in Terminal
                       </div>
                       <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={(e) => {
                          import('../lib/ipcBridge').then(({ IPC }) => IPC.shellExecute('openExplorer', targetPaths));
                          setContextMenu(null);
                       }}>
                          Show in Explorer
                       </div>                       </div>
                 </div>
                 <div className="px-3 py-1 flex items-center gap-2 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => {
                    import('../lib/ipcBridge').then(({ IPC }) => IPC.shellExecute('compress', targetPaths));
                    setContextMenu(null);
                 }}>
                    <Archive size={14} /> Compress to Zip
                 </div>
                 <div className="px-3 py-1 flex items-center gap-2 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => {
                    import('../lib/ipcBridge').then(({ IPC }) => IPC.shellExecute('copyPath', targetPaths));
                    setContextMenu(null);
                 }}>
                    <Clipboard size={14} /> Copy Path
                 </div>
               </>
               );
             })();

             return (
               <>
                  {bndzActions}
                  <div className="h-[1px] bg-[#444] my-1"></div>
                  {bndzGlobal}
                  <div className="h-[1px] bg-[#444] my-1"></div>
                  {renderNativeItems()}
               </>
             );
          })()}
        </div>
      )}

      {toastMessage && <Toast message={toastMessage} onClose={() => setToastMessage(null)} />}
      <CommandPalette 
          isOpen={isCommandPaletteOpen} 
          onClose={() => setIsCommandPaletteOpen(false)} 
          fileSystem={fileSystem} 
          currentPath={currentPath}
          drives={drives}
          setCurrentPath={(p: string) => setCurrentPath(p, activePaneId)}
          setConfigOpen={setIsConfigDialogOpen}
      />
    </div>
  );
}
