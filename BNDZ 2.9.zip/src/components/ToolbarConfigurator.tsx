import React, { useState } from 'react';
import { useAppConfig } from '../data/configContext';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragOverlay
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  rectSortingStrategy,
  useSortable
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { 
    ArrowLeft, ArrowRight, ArrowUp, Monitor, Scissors, Copy, Clipboard, 
    Trash2, Undo, Redo, RefreshCw, Settings, Wrench, Grid, Save, Plus, Terminal, Activity, Table, FolderPlus, List, Shield, Archive, SquareTerminal, Command, HardDrive
} from 'lucide-react';

export const AVAILABLE_ITEMS = [
  { id: 'nav_back', label: 'Back', icon: ArrowLeft, color: '#3b82f6', icon3d: '/assets/3d/left_arrow.png' },
  { id: 'nav_forward', label: 'Forward', icon: ArrowRight, color: '#3b82f6', icon3d: '/assets/3d/right_arrow.png' },
  { id: 'nav_up', label: 'Up One Level', icon: ArrowUp, color: '#10b981', icon3d: '/assets/3d/up_arrow.png' },
  { id: 'go_home', label: 'Go Home', icon: Monitor, color: '#6db4e6', icon3d: '/assets/3d/home.png' },
  { id: 'refresh', label: 'Refresh', icon: RefreshCw, color: '#10b981', icon3d: '/assets/3d/counterclockwise_arrows_button.png' },
  { id: 'cut', label: 'Cut', icon: Scissors, color: '#eab308', icon3d: '/assets/3d/scissors.png' },
  { id: 'copy', label: 'Copy', icon: Copy, color: '#3b82f6', icon3d: '/assets/3d/two_documents.png' },
  { id: 'paste', label: 'Paste', icon: Clipboard, color: '#eab308', icon3d: '/assets/3d/clipboard.png' },
  { id: 'delete', label: 'Delete', icon: Trash2, color: '#ef4444', icon3d: '/assets/3d/wastebasket.png' },
  { id: 'undo', label: 'Undo', icon: Undo, color: '#3b82f6', icon3d: '/assets/3d/undo.png' },
  { id: 'redo', label: 'Redo', icon: Redo, color: '#3b82f6', icon3d: '/assets/3d/redo.png' },
  { id: 'view_details', label: 'Details View', icon: List, color: '#dcb67a', icon3d: '/assets/3d/memo.png' },
  { id: 'sync_folders', label: 'Sync / Compare Files', icon: RefreshCw, color: '#9333ea', icon3d: '/assets/3d/counterclockwise_arrows_button.png' },
  { id: 'new_folder', label: 'New Folder', icon: FolderPlus, color: '#dcb67a', icon3d: '/assets/3d/file_folder.png' },
  { id: 'config', label: 'Configuration', icon: Settings, color: '#888', icon3d: '/assets/3d/gear.png' },
  { id: 'wrench', label: 'Customize Toolbar', icon: Wrench, color: '#3b82f6', icon3d: '/assets/3d/wrench.png' },
  { id: 'cmd', label: 'Command Prompt', icon: SquareTerminal, color: '#eee', icon3d: '/assets/3d/keyboard.png' },
  { id: 'ps', label: 'PowerShell', icon: Terminal, color: '#3b82f6', icon3d: '/assets/3d/blue_square.png' },
  { id: 'taskmgr', label: 'Task Manager', icon: Activity, color: '#10b981', icon3d: '/assets/3d/chart_increasing.png' },
  { id: 'regedit', label: 'Registry Editor', icon: Grid, color: '#eab308', icon3d: '/assets/3d/locked.png' },
  { id: 'separator', label: 'Separator (|)', icon: null, isStructure: true },
  { id: 'spacer', label: 'Spacer [ ]', icon: null, isStructure: true },
  { id: 'new_row', label: 'New Row (---)', icon: null, isStructure: true },
];

function SortableItem(props: any) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: props.id });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.4 : 1,
  };

  const itemDef = AVAILABLE_ITEMS.find(i => i.id === props.itemId) || { label: 'Unknown', isStructure: false, color: '#888' } as any;

  if (itemDef.isStructure) {
      return (
          <div ref={setNodeRef} style={style} {...attributes} {...listeners} className="px-2 py-1 bg-[#333] border border-[#555] rounded text-xs text-gray-300 mx-1 flex items-center justify-center cursor-move h-8 min-w-[32px]">
              {itemDef.id === 'separator' ? '|' : itemDef.id === 'spacer' ? '< >' : '---'}
          </div>
      );
  }

  const Icon = itemDef.icon || Plus;
  const [imgError, setImgError] = React.useState(false);

  return (
    <div ref={setNodeRef} style={style} {...attributes} {...listeners} className="p-1.5 hover:bg-[#444] rounded cursor-move group relative flex items-center justify-center h-8 w-8 mx-0.5">
       {itemDef.icon3d && !imgError ? (
           <img src={itemDef.icon3d} alt={itemDef.label} className="w-5 h-5 object-contain drop-shadow-md pointer-events-none" onError={() => setImgError(true)} />
       ) : (
           <Icon size={18} color={itemDef.color || '#ccc'} className="drop-shadow-md" />
       )}
    </div>
  );
}

export default function ToolbarConfigurator({ onClose }: { onClose: () => void }) {
    const { config, updateConfig } = useAppConfig();
    const profiles = config.toolbarProfiles && config.toolbarProfiles.length > 0 ? config.toolbarProfiles : [[{ id: "nav_back" }]];
    const [activeIndex, setActiveIndex] = useState(config.activeToolbarProfileIndex || 0);
    const [currentLayout, setCurrentLayout] = useState<{ uid: string, id: string }[]>(
        (profiles[activeIndex] || []).map((i: any) => ({ uid: Math.random().toString(36).substring(7), id: i.id }))
    );
    const [search, setSearch] = useState('');

    const sensors = useSensors(
        useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
        useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
    );

    const handleDragEnd = (event: any) => {
        const { active, over } = event;
        
        // True WYSIWYG out-of-bounds drop deletion
        if (!over) {
            setCurrentLayout((items) => items.filter((item) => item.uid !== active.id));
            return;
        }

        const oldIndex = currentLayout.findIndex((i) => i.uid === active.id);
        const newIndex = currentLayout.findIndex((i) => i.uid === over.id);

        if (oldIndex !== -1 && newIndex === -1) {
            // Dragged over something outside the active array
            setCurrentLayout((items) => items.filter((item) => item.uid !== active.id));
            return;
        }

        if (oldIndex !== -1 && newIndex !== -1 && active.id !== over.id) {
            setCurrentLayout((items) => arrayMove(items, oldIndex, newIndex));
        }
    };

    const handleAddItem = (itemId: string) => {
        setCurrentLayout(prev => [...prev, { uid: Math.random().toString(36).substring(7), id: itemId }]);
    };

    const handleSave = () => {
        const newProfiles = [...profiles];
        newProfiles[activeIndex] = currentLayout.map(i => ({ id: i.id }));
        updateConfig({ toolbarProfiles: newProfiles, activeToolbarProfileIndex: activeIndex });
        onClose();
    };

    const handleAddNewProfile = () => {
        const newProfiles = [...profiles, [{ id: "nav_back" }]];
        updateConfig({ toolbarProfiles: newProfiles, activeToolbarProfileIndex: newProfiles.length - 1 });
        setActiveIndex(newProfiles.length - 1);
        setCurrentLayout([{ uid: Math.random().toString(36).substring(7), id: "nav_back" }]);
    };

const ListItemIcon = ({ item }: { item: any }) => {
    const [imgError, setImgError] = React.useState(false);
    if (item.isStructure) {
        return <div className="w-5 text-center text-[#888] font-mono font-bold text-xs">{(item.id === 'separator' ? '|' : item.id === 'spacer' ? '< >' : '---')}</div>;
    }
    if (item.icon3d && !imgError) {
        return <img src={item.icon3d} alt={item.label} className="w-5 h-5 object-contain drop-shadow-md" onError={() => setImgError(true)} />;
    }
    return item.icon ? <item.icon size={16} color={item.color || '#ccc'} className="drop-shadow-md" /> : null;
};

    const filteredItems = AVAILABLE_ITEMS.filter(i => i.label.toLowerCase().includes(search.toLowerCase()));

    return (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[200] p-4 text-gray-200">
            <div className="bg-[#1e1e1e] border border-[#333] shadow-2xl rounded-lg w-full max-w-5xl flex flex-col max-h-[85vh]">
                <div className="p-4 border-b border-[#333] flex justify-between items-center bg-[#252526] rounded-t-lg">
                    <h2 className="text-lg font-bold flex items-center gap-2"><Wrench size={18} className="text-[#3b82f6]"/> Toolbar Configurator</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white">✕</button>
                </div>
                
                <div className="flex flex-1 overflow-hidden">
                    {/* Left Pane - Available Items */}
                    <div className="w-1/3 border-r border-[#333] flex flex-col bg-[#1a1a1a]">
                        <div className="p-3 border-b border-[#333]">
                           <input 
                              type="text" 
                              placeholder="Search commands, macros..." 
                              value={search}
                              onChange={e => setSearch(e.target.value)}
                              className="w-full bg-[#2a2a2a] border border-[#444] rounded px-3 py-1.5 text-sm outline-none focus:border-[#3b82f6]"
                           />
                        </div>
                        <div className="flex-1 overflow-y-auto p-2">
                           <div className="grid grid-cols-1 gap-1">
                               {filteredItems.map(item => (
                                   <div key={item.id} className="flex items-center justify-between p-2 hover:bg-[#2a2a2a] rounded cursor-pointer border border-transparent hover:border-[#444] transition-colors" onClick={() => handleAddItem(item.id)}>
                                      <div className="flex items-center gap-3">
                                          <ListItemIcon item={item} />
                                          <span className="text-sm">{item.label}</span>
                                      </div>
                                      <div className="opacity-0 group-hover:opacity-100 text-[#3b82f6]">
                                          <Plus size={16} />
                                      </div>
                                   </div>
                               ))}
                           </div>
                        </div>
                    </div>

                    {/* Right Pane - Active Mirror */}
                    <div className="w-2/3 flex flex-col bg-[#1e1e1e]">
                        <div className="p-3 border-b border-[#333] flex justify-between items-center bg-[#252526]">
                            <div className="flex items-center gap-3">
                                <span className="text-sm font-medium">Profile:</span>
                                <select 
                                   value={activeIndex} 
                                   onChange={e => {
                                      const idx = parseInt(e.target.value);
                                      setActiveIndex(idx);
                                      setCurrentLayout((profiles[idx] || []).map((i: any) => ({ uid: Math.random().toString(36).substring(7), id: i.id })));
                                   }}
                                   className="bg-[#333] border border-[#555] rounded px-2 py-1 text-sm outline-none"
                                >
                                    {profiles.map((_, i) => (
                                        <option key={i} value={i}>Toolbar {i + 1}</option>
                                    ))}
                                </select>
                                <button className="text-xs bg-[#333] hover:bg-[#444] border border-[#555] px-2 py-1 rounded" onClick={handleAddNewProfile}>+ New</button>
                            </div>
                            <button onClick={handleSave} className="flex items-center gap-2 bg-[#3b82f6] hover:bg-[#2563eb] text-white px-4 py-1.5 rounded text-sm font-medium transition-colors">
                                <Save size={14} /> Save to .ini
                            </button>
                        </div>
                        <div className="flex-1 p-6 relative">
                            <div className="text-xs text-gray-500 mb-4 font-medium uppercase tracking-wider">WYSIWYG Mirror (Drag to rearrange, drag out to remove)</div>
                            <div className="bg-[#2d2d2d] border-t border-b border-[#444] min-h-[42px] flex px-2 py-1 items-center flex-wrap shadow-inner relative">
                                <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
                                    <SortableContext items={currentLayout.map(i => i.uid)} strategy={rectSortingStrategy}>
                                        {currentLayout.map(item => {
                                            if (item.id === 'new_row') {
                                                return <div key={item.uid} className="w-full h-0 mb-2 basis-full"></div>;
                                            }
                                            return <SortableItem key={item.uid} id={item.uid} itemId={item.id} />;
                                        })}
                                    </SortableContext>
                                </DndContext>
                                {currentLayout.length === 0 && <div className="absolute inset-0 flex items-center justify-center text-sm text-gray-500 italic pointer-events-none">Empty Toolbar. Add items from the left.</div>}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
