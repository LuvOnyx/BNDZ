import React, { useState, useEffect } from 'react';
import { useAppConfig } from '../data/configContext';
import { FSEntity } from '../types';
import { File, Folder, Image, Music, FileText, Code, Settings, PlayCircle, ShieldUser, KeyRound, HardDrive, Binary } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';

interface RightPreviewPanelProps {
  entity: FSEntity | null;
  path?: string | null;
}

export default function RightPreviewPanel({ entity, path }: RightPreviewPanelProps) {
  const { config } = useAppConfig();
  const [thumbnailNative, setThumbnailNative] = useState<string | null>(null);
  const [fileContent, setFileContent] = useState<string | null>(null);
  const [hexContent, setHexContent] = useState<string | null>(null);
  const [isLoadingContent, setIsLoadingContent] = useState(false);
  const [contentError, setContentError] = useState<string | null>(null);

  // C# Wiring: hydrate high-resolution thumbnail based on focused entity
  useEffect(() => {
     if (entity && config.highResNativeWindowsThumbnails !== false && path) {
        setThumbnailNative(null);
        let active = true;
        import('../lib/ipcBridge').then(({ IPC }) => {
           IPC.getNativeThumbnailBase64(path).then(base64 => {
               if (active && base64) {
                  setThumbnailNative(base64);
               }
           });
        });
        return () => { active = false; };
     } else {
        setThumbnailNative(null);
     }
  }, [entity?.id, config.highResNativeWindowsThumbnails, path]);

  const isDir = entity?.type === 'directory';
  const ext = !isDir ? (entity as any)?.extension?.toLowerCase() || '' : '';
  const isImage = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'].includes(ext);
  const isAudio = ['mp3', 'wav', 'ogg', 'flac'].includes(ext);
  const isVideo = ['mp4', 'mkv', 'avi', 'mov', 'webm'].includes(ext);
  const isTextRaw = ['txt', 'md', 'log', 'csv', 'ini'].includes(ext);
  const isCode = ['js', 'ts', 'jsx', 'tsx', 'cs', 'json', 'html', 'css', 'xml', 'py', 'cpp', 'c', 'h'].includes(ext);
  const isPdf = ext === 'pdf';
  const isBinary = ['exe', 'dll', 'sys', 'dat', 'bin'].includes(ext);
  const isDrive = !!(entity as any)?.driveInfo;

  const virtualUrl = path ? `https://bndz.local${path.startsWith('/') ? path : '/' + path}` : '';

  useEffect(() => {
     setFileContent(null);
     setHexContent(null);
     setContentError(null);
     setIsLoadingContent(false);

     if (!path || isDir) return;

     const fetchContent = async () => {
         setIsLoadingContent(true);
         try {
             const isNative = typeof window !== 'undefined' && !!(window as any).chrome?.webview;
             if (!isNative) {
                 throw new Error("Local file streaming requires native C# host.");
             }
             const response = await fetch(virtualUrl);
             if (!response.ok) throw new Error("Failed to load local file via virtual host.");
             
             if (isTextRaw || isCode) {
                 const text = await response.text();
                 // Prevent huge string overhead
                 setFileContent(text.length > 50000 ? text.substring(0, 50000) + "\n... [TRUNCATED]" : text);
             } else if (isBinary || (!isImage && !isAudio && !isVideo && !isPdf)) {
                 const buffer = await response.arrayBuffer();
                 const bytes = new Uint8Array(buffer).slice(0, 256); // Read only the first 256 bytes for hex view
                 let hexStr = "";
                 for (let i = 0; i < bytes.length; i++) {
                     hexStr += bytes[i].toString(16).padStart(2, '0').toUpperCase() + " ";
                     if ((i + 1) % 16 === 0) hexStr += "\n";
                 }
                 setHexContent(hexStr || "Empty File");
             }
         } catch (err: any) {
             console.warn("Universal Preview Stream Error:", err);
             setContentError(err.message || "Failed to load preview.");
         } finally {
             setIsLoadingContent(false);
         }
     };

     if (isTextRaw || isCode || isBinary || (!isImage && !isAudio && !isVideo && !isPdf)) {
         fetchContent();
     }
  }, [path, isDir, isTextRaw, isCode, isBinary, isImage, isAudio, isVideo, isPdf, virtualUrl]);

  if (!entity) {
    return (
      <div className="w-full h-full border-l border-[#282830] bg-[#111111] flex flex-col items-center justify-center text-[#666] p-4 shrink-0 shadow-[-4px_0_15px_rgba(0,0,0,0.2)] z-10 select-none">
        <File size={48} className="mb-4 opacity-20" />
        <span className="text-[13px]">Select a file to preview</span>
      </div>
    );
  }

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024, sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getPreviewIcon = () => {
     if (isDrive) return <HardDrive size={80} className={(entity as any).name.includes('C:') ? "text-[#6db4e6]" : "text-gray-400"} />;
     if (isDir) return <Folder size={80} className="text-[#dcb67a]" />;
     if (isImage) return <Image size={80} className="text-purple-400" />;
     if (isAudio) return <Music size={80} className="text-sky-400" />;
     if (isCode) return <Code size={80} className="text-emerald-400" />;
     if (isTextRaw) return <FileText size={80} className="text-amber-400" />;
     return <File size={80} className="text-gray-400" />;
  };

  const showThumb = config.previewAsThumbnail;
  const zoom = config.selectConfig || "100%";
  const animDuration = config.richTransitionAnimations !== false ? 0.15 : 0;

  const renderUniversalPreview = () => {
      // 1. Audio / Video Native Players
      if (isAudio) {
          return (
              <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-[#080808]">
                  <Music size={48} className="text-sky-400 mb-6 drop-shadow-[0_0_15px_rgba(56,189,248,0.4)]" />
                  <audio src={virtualUrl} controls className="w-full max-w-[300px]" />
                  <div className="mt-4 text-[11px] text-gray-400 font-mono">Local Audio Stream ({ext.toUpperCase()})</div>
              </div>
          );
      }
      if (isVideo) {
          return (
              <div className="w-full h-full flex items-center justify-center bg-black">
                  <video src={virtualUrl} controls className="w-full h-full object-contain" poster={`data:image/png;base64,${thumbnailNative || ''}`} />
              </div>
          );
      }
      
      // 2. High-Res Image Viewer
      if (isImage) {
          return (
              <div className={`w-full h-full flex items-center justify-center relative overflow-hidden bg-[#080808] ${showThumb ? 'pattern-checkerboard' : ''}`}>
                  <img src={virtualUrl} className="max-w-full max-h-full object-contain drop-shadow-2xl" alt={entity.name} 
                       onError={(e) => {
                           if (thumbnailNative) (e.target as HTMLImageElement).src = `data:image/png;base64,${thumbnailNative}`;
                       }} 
                  />
                  {!thumbnailNative && contentError && <div className="absolute inset-0 flex items-center justify-center bg-black/80 text-xs text-red-400 p-4 text-center">{contentError}</div>}
              </div>
          );
      }

      // 3. Document / PDF Frame
      if (isPdf) {
          return (
              <div className="w-full h-full bg-[#111]">
                 <iframe src={virtualUrl} className="w-full h-full border-none" title={entity.name} />
              </div>
          );
      }

      // 4. Code & Text Inspector
      if (isTextRaw || isCode) {
          return (
              <div className="w-full h-full flex flex-col bg-[#1e1e1e]">
                  {isLoadingContent && <div className="p-4 text-xs text-gray-400 font-mono animate-pulse">Loading stream...</div>}
                  {contentError && <div className="p-4 text-xs text-red-400 font-mono border border-red-500/20 bg-red-500/5 m-2 rounded">{contentError}</div>}
                  {!isLoadingContent && !contentError && fileContent && (
                      <SyntaxHighlighter
                          language={isCode ? ext : 'text'}
                          style={vscDarkPlus}
                          showLineNumbers={true}
                          customStyle={{ margin: 0, padding: '1rem', background: 'transparent', height: '100%', fontSize: '11px', overflow: 'auto' }}
                      >
                          {fileContent}
                      </SyntaxHighlighter>
                  )}
              </div>
          );
      }

      // 5. Hex View Fallback
      if (isBinary || (!isDir && hexContent)) {
          return (
              <div className="w-full h-full flex flex-col bg-[#080808] p-4 overflow-hidden">
                  <div className="flex items-center gap-2 mb-4 text-[#eab308] font-mono text-[11px] pb-2 border-b border-[#333]">
                      <Binary size={14} /> <span>HEX INSPECTOR (First 256 Bytes)</span>
                  </div>
                  {isLoadingContent && <div className="text-xs text-gray-500 font-mono animate-pulse">Mapping virtual stream...</div>}
                  {contentError && <div className="p-4 text-xs text-red-400 font-mono border border-red-500/20 bg-red-500/5 rounded">{contentError}</div>}
                  {!isLoadingContent && !contentError && hexContent && (
                      <pre className="text-[11px] font-mono text-gray-400 leading-relaxed overflow-y-auto custom-scrollbar break-all whitespace-pre-wrap select-text">
                         {hexContent}
                      </pre>
                  )}
              </div>
          );
      }

      // 6. Default Fallback (Directories or unknown native fetch errors)
      return (
         <div className={`w-full h-full flex items-center justify-center p-4 relative bg-[#080808] ${showThumb ? 'pattern-checkerboard' : ''}`}>
             <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-10 pointer-events-none"></div>
             
             <div className="transition-transform duration-300">
                 {thumbnailNative ? (
                    thumbnailNative === 'mocked_base64_ready' ? (
                        <div className="flex flex-col items-center drop-shadow-2xl">
                            {getPreviewIcon()}
                        </div>
                    ) : (
                        <img src={`data:image/png;base64,${thumbnailNative}`} className="max-w-[200px] max-h-[200px] object-contain drop-shadow-2xl" alt="Preview Thumbnail" />
                    )
                 ) : (
                    <div className="flex flex-col items-center drop-shadow-2xl">
                        {getPreviewIcon()}
                    </div>
                 )}
             </div>
             
             <div className="absolute bottom-2 right-2 flex gap-1 shadow-md">
                {isDir ? (
                   <span className="bg-black/90 text-[#dcb67a] text-[9px] px-2 py-0.5 rounded-[2px] uppercase font-bold border border-[#dcb67a]/40 shadow-inner tracking-wider">DIR</span>
                ) : ext && (
                   <span className="bg-black/90 text-white text-[9px] px-2 py-0.5 rounded-[2px] uppercase font-bold border border-white/20 shadow-inner tracking-wider">{ext}</span>
                )}
             </div>
         </div>
      );
  };

  return (
    <div className="w-full h-full border-l border-[#282830] bg-[#151515] flex flex-col shrink-0 shadow-[-4px_0_15px_rgba(0,0,0,0.2)] z-10 overflow-hidden text-[#e0e0e0]">
       {/* Toolbar / Header */}
       <div className="bg-[#1e1e1e] border-b border-[#333] px-2 py-1.5 flex justify-between items-center z-10 shrink-0 select-none">
          <span className="text-[11px] font-bold text-gray-300 uppercase tracking-wider">Preview Details</span>
          <div className="flex gap-1">
             <div className="p-1 hover:bg-[#333] rounded cursor-pointer"><Settings size={12} className="text-gray-400" /></div>
          </div>
       </div>
       
       <div className="flex-1 overflow-y-auto no-scrollbar relative flex flex-col styled-scrollbar bg-[#111]">
          <AnimatePresence mode="wait">
             <motion.div 
                key={entity.id}
                initial={{ opacity: 0, y: animDuration > 0 ? 10 : 0 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: animDuration > 0 ? -10 : 0 }}
                transition={{ duration: animDuration, ease: "easeOut" }}
                className="flex flex-col flex-1"
             >
                {/* Advanced Universal Active Preview Area */}
                <div className="w-full h-[320px] shrink-0 border-b border-[#282830] relative group">
                    {renderUniversalPreview()}
                </div>

                {/* Dense Metadata Panel */}
                <div className="p-4 flex-1 bg-[#111] flex flex-col gap-4">
                    {/* Primary Identifier */}
                    <div className="pb-3 border-b border-[#282830]">
                       <h2 className="text-[14px] font-bold text-white break-words leading-tight">{entity.name}</h2>
                       <div className="text-[11px] text-gray-500 mt-1 uppercase tracking-widest font-mono">
                          {isDrive ? (entity as any).typeDescription : (isDir ? 'File Folder' : `${ext.toUpperCase()} File`)}
                       </div>
                    </div>

                    {/* Quick Stats Grid */}
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid grid-cols-[80px_1fr] gap-y-2 text-[11px] font-mono leading-relaxed">
                       {isDrive ? (
                           <>
                               <div className="text-gray-500 flex items-center gap-1"><HardDrive size={10} /> Total Size:</div>
                               <div className="text-sky-300">{formatSize((entity as any).driveInfo.totalSpace)}</div>
                               <div className="text-gray-500 flex items-center gap-1">Free Space:</div>
                               <div className="text-emerald-400">{formatSize((entity as any).driveInfo.freeSpace)}</div>
                               <div className="text-gray-500 flex items-center gap-1">Format:</div>
                               <div className="text-gray-300">{(entity as any).driveInfo.format}</div>
                           </>
                       ) : (
                           <>
                               <div className="text-gray-500 flex items-center gap-1"><HardDrive size={10} /> {isDir ? 'Size on disk:' : 'Size:'}</div>
                               <div className="text-sky-300">
                                  {isDir ? '-- (Calculate in BG)' : ((entity as any).size != null ? formatSize((entity as any).size) : '--')}
                               </div>
                               {isDir && (
                                  <>
                                     <div className="text-gray-500">Contents:</div>
                                     <div className="text-gray-300">-- Files, -- Folders</div>
                                  </>
                               )}

                               <div className="text-gray-500">Created:</div>
                               <div className="text-gray-300">{(entity as any).created ? new Date((entity as any).created).toLocaleString() : '--'}</div>

                               <div className="text-gray-500">Modified:</div>
                               <div className="text-gray-300">{new Date(entity.modified).toLocaleString()}</div>
                           </>
                       )}
                    </motion.div>

                    {/* Security & Access Box */}
                    <div className="mt-2 border border-[#282830] bg-[#151515] rounded-[4px] p-3 shadow-inner">
                       <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-widest font-bold text-gray-400 mb-2">
                          <ShieldUser size={12} className="text-emerald-400" /> Access Properties
                       </div>
                       
                       <div className="grid grid-cols-[80px_1fr] gap-y-1.5 text-[11px] font-mono">
                          <div className="text-gray-500">Owner:</div>
                          <div className="text-gray-300 flex items-center">BUILTIN\Administrators</div>
                          
                          <div className="text-gray-500 flex items-center gap-1"><KeyRound size={10} /> ACL:</div>
                          <div className="text-gray-300">Full Control</div>
                       </div>
                       
                       <div className="mt-3 pt-3 border-t border-[#282830] flex gap-4">
                          <label className="flex items-center gap-1.5 cursor-not-allowed">
                             <input type="checkbox" className="accent-sky-500 bg-[#222] border-[#444] rounded-sm" readOnly checked={(entity as any).readOnly !== false} /> 
                             <span className="text-[11px] text-gray-300">Read-only</span>
                          </label>
                          <label className="flex items-center gap-1.5 cursor-not-allowed">
                             <input type="checkbox" className="accent-sky-500 bg-[#222] border-[#444] rounded-sm" readOnly checked={(entity as any).hidden === true} /> 
                             <span className="text-[11px] text-gray-300">Hidden</span>
                          </label>
                       </div>
                    </div>
                </div>
             </motion.div>
          </AnimatePresence>
       </div>
    </div>
  );
}
