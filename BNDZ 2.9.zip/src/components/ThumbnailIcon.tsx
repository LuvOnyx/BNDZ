import { useState, useEffect, useRef } from "react";
import { Folder, File, FileCode, FileText, Music, Archive, FileJson, FileVideo, FileImage } from "lucide-react";
import { IPC } from "../lib/ipcBridge";
import { useAppConfig } from "../data/configContext";
import { FSEntity } from "../types";

// Local cache to prevent flashing
const _thumbnailCache: Record<string, string> = {};

const getIconForExtension = (ext: string, size: number) => {
    switch (ext.toLowerCase()) {
        case 'wav':
        case 'mp3':
        case 'flac':
        case 'ptx':
        case 'flp':
            return <Music size={size} color="#FFA500" />;
            
        case 'json':
            return <FileJson size={size} color="#f5a623" />;
            
        case 'tsx':
        case 'ts':
            return <FileCode size={size} color="#007acc" />;
            
        case 'js':
            return <FileCode size={size} color="#f7df1e" />;
            
        case 'cs':
            return <FileCode size={size} color="#9B4F96" />;
            
        case 'html':
            return <FileCode size={size} color="#e34c26" />;
            
        case 'css':
            return <FileCode size={size} color="#264de4" />;
            
        case 'zip':
        case 'rar':
        case '7z':
            return <Archive size={size} color="#d9534f" />;
            
        case 'pdf':
            return <FileText size={size} color="#e20613" />;
            
        case 'docx':
            return <FileText size={size} color="#2b579a" />;
            
        case 'txt':
            return <FileText size={size} color="#a9a9a9" />;

        case 'png':
        case 'jpg':
        case 'jpeg':
        case 'webp':
        case 'svg':
        case 'gif':
            return <FileImage size={size} color="#4fb0bc" />;

        case 'mp4':
        case 'mkv':
        case 'mov':
            return <FileVideo size={size} color="#ff4081" />;
            
        default:
            return <File size={size} className="text-[#eee]" />;
    }
}

export function ThumbnailIcon({ entity, isDir, path, size = 16 }: { entity: FSEntity, isDir: boolean, path: string, size?: number }) {
  const { config } = useAppConfig();
  const [thumb, setThumb] = useState<string | null>(entity.iconBase64 || _thumbnailCache[path] || null);
  const [isVisible, setIsVisible] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setIsVisible(true);
        observer.disconnect();
      }
    }, {
      rootMargin: '100px', // Pre-fetch slightly before they enter viewport
      threshold: 0
    });

    observer.observe(el);
    return () => {
      observer.disconnect();
    };
  }, []);

  useEffect(() => {
    if (!isVisible || thumb || !config.enableNativeThumbnails) return;
    
    let isMounted = true;
    IPC.getNativeThumbnailBase64(path).then(res => {
      if (res && isMounted) {
         const fullData = res.startsWith('data:') ? res : `data:image/png;base64,${res}`;
         _thumbnailCache[path] = fullData; // Assume aggressive cache on high-speed storage!
         setThumb(fullData);
      }
    });

    return () => { isMounted = false; };
  }, [path, config.enableNativeThumbnails, thumb, isVisible]);

  if (thumb) {
     return (
       <div ref={containerRef} style={{ width: size, height: size, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
         <img src={thumb} alt="" style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} />
       </div>
     );
  }
  
  let ExtIcon = isDir ? <Folder size={size} className="text-[#dcb67a]" /> : getIconForExtension((entity as any).extension || '', size);

  return (
      <div ref={containerRef} style={{ width: size, height: size, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          {ExtIcon}
      </div>
  );
}
