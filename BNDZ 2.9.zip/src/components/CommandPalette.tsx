import React, { useState, useEffect, useRef } from 'react';
import Fuse from 'fuse.js';
import { Search, Folder, Terminal, Settings } from 'lucide-react';

interface CommandItem {
    id: string;
    title: string;
    subtitle?: string;
    type: 'command' | 'path';
    action: () => void;
    icon?: React.ReactNode;
}

export default function CommandPalette({ isOpen, onClose, fileSystem, currentPath, drives, setCurrentPath, setConfigOpen }: any) {
    const [query, setQuery] = useState("");
    const [selectedIndex, setSelectedIndex] = useState(0);
    const inputRef = useRef<HTMLInputElement>(null);
    const [recentPaths, setRecentPaths] = useState<string[]>([]);

    useEffect(() => {
        if (isOpen) {
            setQuery("");
            setSelectedIndex(0);
            setTimeout(() => inputRef.current?.focus(), 50);
        }
    }, [isOpen]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'p' && e.ctrlKey && e.shiftKey) {
                e.preventDefault();
                // Handled in BNDZUI.tsx instead, or we can handle it if we export a trigger.
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, []);

    // Load recent paths from localStorage or similar (mocked as simple state for now)
    useEffect(() => {
        const saved = localStorage.getItem('bndz_recent_paths');
        if (saved) {
            try { setRecentPaths(JSON.parse(saved)); } catch (e) {}
        }
    }, [isOpen]);

    const saveRecentPath = (path: string) => {
        const updated = [path, ...recentPaths.filter(p => p !== path)].slice(0, 10);
        setRecentPaths(updated);
        localStorage.setItem('bndz_recent_paths', JSON.stringify(updated));
    };

    const allCommands: CommandItem[] = [
        { id: 'settings', title: 'Open Settings', type: 'command', icon: <Settings size={16}/>, action: () => { setConfigOpen(true); onClose(); } },
        { id: 'toggle-hidden', title: 'Toggle Hidden Files', type: 'command', icon: <Terminal size={16}/>, action: () => { console.log('Toggle hidden'); onClose(); } },
        { id: 'new-folder', title: 'New Folder', type: 'command', icon: <Folder size={16}/>, action: () => { console.log('New folder'); onClose(); } },
        { id: 'go-home', title: 'Go to Root', type: 'command', icon: <Folder size={16}/>, action: () => { setCurrentPath('/'); onClose(); } },
        ...drives.map((d: any) => ({
            id: `drive-${d.name}`,
            title: `Go to ${d.label} (${d.name})`,
            type: 'path' as const,
            icon: <Folder size={16}/>,
            action: () => { setCurrentPath(d.name); onClose(); }
        })),
        ...recentPaths.map((p) => ({
            id: `recent-${p}`,
            title: p,
            subtitle: 'Recent path',
            type: 'path' as const,
            icon: <Folder size={16}/>,
            action: () => { setCurrentPath(p); onClose(); }
        }))
    ];

    const fuse = new Fuse(allCommands, { keys: ['title', 'subtitle'], threshold: 0.3 });
    const results = query ? fuse.search(query).map(r => r.item) : allCommands;

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === 'Escape') onClose();
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setSelectedIndex(prev => (prev + 1) % Math.max(1, results.length));
        }
        if (e.key === 'ArrowUp') {
            e.preventDefault();
            setSelectedIndex(prev => (prev - 1 + results.length) % Math.max(1, results.length));
        }
        if (e.key === 'Enter') {
            e.preventDefault();
            if (results[selectedIndex]) {
                const item = results[selectedIndex];
                if (item.type === 'path') saveRecentPath(item.title.startsWith('Go to') ? item.title.split('(')[1].replace(')','') || item.title : item.title);
                item.action();
            }
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[9999] bg-black/60 backdrop-blur-sm flex items-start justify-center pt-[15vh]">
            <div 
                className="bg-[#1e1e1e] border border-[#333] shadow-2xl rounded-lg w-[600px] max-h-[60vh] flex flex-col font-sans overflow-hidden"
                onClick={e => e.stopPropagation()}
            >
                <div className="flex items-center px-4 py-3 border-b border-[#333] bg-[#252525]">
                    <Search size={18} className="text-gray-400 mr-3" />
                    <input 
                        ref={inputRef}
                        type="text" 
                        value={query}
                        onChange={e => { setQuery(e.target.value); setSelectedIndex(0); }}
                        onKeyDown={handleKeyDown}
                        placeholder="Type a command or search for paths..."
                        className="bg-transparent border-none text-white text-base w-full focus:outline-none placeholder-gray-500"
                    />
                </div>
                <div className="overflow-y-auto flex-1 p-2">
                    {results.length === 0 ? (
                        <div className="text-center text-gray-500 py-8">No matching commands found.</div>
                    ) : (
                        results.map((item, idx) => (
                            <div 
                                key={item.id}
                                className={`px-4 py-2.5 rounded flex items-center gap-3 cursor-pointer ${idx === selectedIndex ? 'bg-[#007acc] text-white' : 'text-gray-300 hover:bg-[#2d2d2d]'}`}
                                onClick={() => {
                                    if (item.type === 'path') saveRecentPath(item.title.startsWith('Go to') ? item.title.split('(')[1].replace(')','') || item.title : item.title);
                                    item.action();
                                }}
                                onMouseEnter={() => setSelectedIndex(idx)}
                            >
                                <span className={idx === selectedIndex ? 'text-white' : 'text-gray-400'}>{item.icon}</span>
                                <div className="flex flex-col">
                                    <span className="font-medium text-[13px]">{item.title}</span>
                                    {item.subtitle && <span className={`text-[11px] ${idx === selectedIndex ? 'text-blue-200' : 'text-gray-500'}`}>{item.subtitle}</span>}
                                </div>
                            </div>
                        ))
                    )}
                </div>
                <div className="bg-[#111] border-t border-[#333] px-3 py-1.5 text-[10px] text-gray-500 flex justify-between">
                    <span>Press <kbd className="bg-[#333] px-1 rounded">↑↓</kbd> to navigate, <kbd className="bg-[#333] px-1 rounded">Enter</kbd> to select, <kbd className="bg-[#333] px-1 rounded">Esc</kbd> to close.</span>
                    <span>BNDZ Command Palette</span>
                </div>
            </div>
            {/* Click outside to close is handled if we wrap it, but let's just add an overlay blocker below */}
            <div className="absolute inset-0 -z-10" onClick={onClose}></div>
        </div>
    );
}
