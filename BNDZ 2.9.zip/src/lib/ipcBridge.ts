/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface RenameOperation {
  originalName: string;
  newName: string;
  reason?: string;
}

export const IPC = {
  // Check if running inside a native Windows WebView2 container
  // This securely routes commands through the host WinForms/WPF app if available
  isNative: typeof window !== 'undefined' && !!(window as any).chrome?.webview,
  _listeners: [] as Array<(events: any[]) => void>,
  _initialized: false as boolean,
  _progressListeners: [] as Array<(progress: any) => void>,
  _conflictListeners: [] as Array<(conflict: any) => void>,
  _drivesListeners: [] as Array<(drives: any[]) => void>,

  init() {
    if (this.isNative && !this._initialized) {
        window.addEventListener("message", (e: any) => {
           if (e.data?.type === 'FS_EVENT_BATCH') {
              this._listeners.forEach(cb => cb(e.data.payload));
           } else if (e.data?.type === 'PROGRESS_UPDATE') {
              this._progressListeners.forEach(cb => cb(e.data.payload));
           } else if (e.data?.type === 'CONFLICT_DETECTED') {
              this._conflictListeners.forEach(cb => cb(e.data.payload));
           } else if (e.data?.type === 'DRIVES_CHANGED') {
              this._drivesListeners.forEach(cb => cb(e.data.payload));
           }
        });
        this._initialized = true;
    }
  },

  onDrivesChanged(callback: (drives: any[]) => void) {
     this.init();
     this._drivesListeners.push(callback);
     return () => {
         this._drivesListeners = this._drivesListeners.filter(cb => cb !== callback);
     };
  },

  onFsEvents(callback: (events: any[]) => void) {
     this.init();
     this._listeners.push(callback);
     return () => {
        this._listeners = this._listeners.filter(cb => cb !== callback);
     };
  },

  onProgress(callback: (progress: any) => void) {
     this.init();
     this._progressListeners.push(callback);
     return () => {
        this._progressListeners = this._progressListeners.filter(cb => cb !== callback);
     };
  },

  onConflictContent(callback: (conflict: any) => void) {
     this.init();
     this._conflictListeners.push(callback);
     return () => {
         this._conflictListeners = this._conflictListeners.filter(cb => cb !== callback);
     };
  },

  executeFsOperation(operationId: string, action: 'copy' | 'move' | 'delete' | 'create-dir' | 'create-file' | 'undo' | 'redo', source: string | string[], target: string, bypassRecycleBin: boolean = false) {
     if (this.isNative) {
         (window as any).chrome.webview.postMessage({ type: 'EXECUTE_FS_OPERATION', payload: { operationId, action, source, target, bypassRecycleBin } });
     } else {
         console.log(`[Web IPC Mock] Instructed C# backend to ${action} from ${source} to ${target} (Bypass Bin: ${bypassRecycleBin})`);
         
         // Mock progress and conflict for web preview
         if (action !== 'delete') {
             setTimeout(() => {
                 this._progressListeners.forEach(cb => cb({ operationId, percentage: 50, currentFile: typeof source === 'string' ? source : source[0] || '', bytesTransferred: 5000000, totalBytes: 10000000, speedBytesPerSecond: 10000000, itemsCompleted: 1, totalItems: 2 }));
             }, 500);
             setTimeout(() => {
                 this._progressListeners.forEach(cb => cb({ operationId, percentage: 100, currentFile: typeof source === 'string' ? source : source[source.length - 1] || '', bytesTransferred: 10000000, totalBytes: 10000000, speedBytesPerSecond: 10000000, itemsCompleted: 2, totalItems: 2 }));
             }, 1000);
         }
     }
  },

  startDrag(paths: string | string[]) {
     if (this.isNative) {
         (window as any).chrome.webview.postMessage({ type: 'START_DRAG', payload: { paths } });
     } else {
         console.log(`[Web IPC Mock] Sent START_DRAG for`, paths);
     }
  },

  clearThumbnailCache() {
     if (this.isNative) {
         (window as any).chrome.webview.postMessage({ type: 'CLEAR_THUMBNAIL_CACHE' });
     } else {
         console.log(`[Web IPC Mock] Sent CLEAR_THUMBNAIL_CACHE`);
     }
  },

  executeUndo() {
      if (this.isNative) {
         (window as any).chrome.webview.postMessage({ type: 'EXECUTE_UNDO' });
      } else {
         console.log(`[Web IPC Mock] Executed Undo`);
      }
  },

  executeRedo() {
      if (this.isNative) {
         (window as any).chrome.webview.postMessage({ type: 'EXECUTE_REDO' });
      } else {
         console.log(`[Web IPC Mock] Executed Redo`);
      }
  },

  compareDirectories(pathA: string, pathB: string, useHashing: boolean = false): Promise<any> {
      if (this.isNative) {
         return new Promise((resolve) => {
             const callbackName = `sync_cb_${Date.now()}`;
             (window as any)[callbackName] = (res: any) => {
                 delete (window as any)[callbackName];
                 resolve(res);
             };
             (window as any).chrome.webview.postMessage({ type: 'COMPARE_DIRECTORIES', payload: { pathA, pathB, useHashing, callbackName } });
         });
      } else {
         console.log(`[Web IPC Mock] Sent COMPARE_DIRECTORIES for ${pathA} and ${pathB}`);
         return Promise.resolve([]);
      }
  },

  executeContextMenuVerb(path: string | string[], verb: string, x?: number, y?: number) {
      if (this.isNative) {
         (window as any).chrome.webview.postMessage({ type: 'EXECUTE_CONTEXT_MENU_VERB', payload: { path, verb, x, y } });
      } else {
         console.log(`[Web IPC Mock] Executed native verb '${verb}' on`, path);
      }
  },

  shellExecute(action: 'open' | 'openWith' | 'copyPath' | 'compress' | 'openTerminal' | 'openExplorer' | string, path: string | string[]) {
      if (this.isNative) {
          (window as any).chrome.webview.postMessage({ type: 'SHELL_EXECUTE', payload: { action, path } });
      } else {
          console.log(`[Web IPC Mock] Shell Execute: ${action} on`, path);
          if (action === 'copyPath') {
              const text = Array.isArray(path) ? path.join('\n') : path;
              navigator.clipboard.writeText(text).catch(err => console.error("Clipboard failed", err));
          }
      }
  },

  resolveConflict(operationId: string, fileName: string, resolution: 'replace' | 'skip' | 'keepboth') {
     if (this.isNative) {
         (window as any).chrome.webview.postMessage({ type: 'RESOLVE_CONFLICT', payload: { operationId, fileName, resolution } });
     } else {
         console.log(`[Web IPC Mock] Resolving conflict for ${fileName} with: ${resolution}`);
     }
  },

  watchDirectory(path: string) {
     if (this.isNative) {
        (window as any).chrome.webview.postMessage({ type: 'WATCH_DIR', payload: { path } });
     } else {
        console.log(`[Web IPC Mock] Instructed C# backend to monitor: ${path}`);
     }
  },

  async aiBatchRename(filenames: string[], instructions: string): Promise<RenameOperation[]> {
    if (this.isNative) {
      // Native C# Interop layer
      return new Promise((resolve) => {
        const id = Date.now().toString();
        function listener(e: any) {
          if (e.data && e.data.id === id) {
            window.removeEventListener("message", listener);
            resolve(e.data.result);
          }
        }
        window.addEventListener("message", listener);
        
        // Post message to the WebView2 C# host process
        (window as any).chrome.webview.postMessage({ 
            type: 'AI_BATCH_RENAME', 
            payload: { filenames, instructions }, 
            id 
        });
      });
    }

    // Web Fallback: Proxy to local Node.js Server for browser previews
    const res = await fetch('/api/gemini/batch-rename', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ filenames, customInstructions: instructions })
    });
    
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || "AI Request Failed. Ensure GEMINI_API_KEY is linked.");
    }
    
    const data = await res.json();
    return data.renamedFiles;
  },

  syncFolders(source: string, target: string, entityId: string, action: 'copy' | 'move' = 'move') {
    if (this.isNative) {
       (window as any).chrome.webview.postMessage({ 
           type: 'SYNC_FOLDERS', 
           payload: { source, target, entityId, action } 
       });
    } else {
       console.log(`[Web IPC Mock] ${action} instructions sent to move ${entityId} from ${source} to ${target}`);
    }
  },

  getSystemDrives(): Promise<any[]> {
    if (this.isNative) {
      return new Promise((resolve) => {
        const id = Date.now().toString();
        const listener = (e: any) => {
          if (e.data && e.data.type === 'DRIVES_RESULT' && e.data.id === id) {
            window.removeEventListener("message", listener);
            resolve(e.data.payload);
          }
        };
        window.addEventListener("message", listener);
        (window as any).chrome.webview.postMessage({ type: 'GET_DRIVES', id });
      });
    } else {
      return Promise.resolve([
        { name: '/C:', label: 'Local Disk', totalSpace: 500_000_000_000, freeSpace: 40_000_000_000 },
        { name: '/D:', label: 'Space Hub', totalSpace: 2_000_000_000_000, freeSpace: 1_200_000_000_000 },
        { name: '/E:', label: 'Vault', totalSpace: 4_000_000_000_000, freeSpace: 100_000_000_000 }
      ]);
    }
  },

  getSystemShortcuts(): Promise<any[]> {
    return Promise.resolve([
      { name: 'Desktop', path: '/C:/Users/Developer/Desktop', icon: 'desktop' },
      { name: 'Downloads', path: '/C:/Users/Developer/Downloads', icon: 'downloads' },
      { name: 'Documents', path: '/C:/Users/Developer/Documents', icon: 'documents' },
      { name: 'User Profile', path: '/C:/Users/Developer', icon: 'profile' }
    ]);
  },

  setAsDefaultManager(enable: boolean) {
     if (this.isNative) {
        (window as any).chrome.webview.postMessage({ type: 'SHELL_INTEGRATION', payload: { action: 'setDefault', enable } });
     } else {
        console.log(`[Web IPC Mock] Instructed C# backend to ${enable ? 'set' : 'remove'} BNDZ as default file manager`);
     }
  },

  setInContextMenu(enable: boolean) {
     if (this.isNative) {
        (window as any).chrome.webview.postMessage({ type: 'SHELL_INTEGRATION', payload: { action: 'setContextMenu', enable } });
     } else {
        console.log(`[Web IPC Mock] Instructed C# backend to ${enable ? 'add' : 'remove'} BNDZ from folder context menu`);
     }
  },

  relaunchAsAdmin() {
     if (this.isNative) {
        (window as any).chrome.webview.postMessage({ type: 'SHELL_INTEGRATION', payload: { action: 'relaunchAdmin' } });
     } else {
        console.log(`[Web IPC Mock] Instructed C# backend to relaunch as administrator`);
     }
  },

  saveSettings(settings: any) {
     if (this.isNative) {
        (window as any).chrome.webview.postMessage({ type: 'SAVE_SETTINGS', payload: settings });
     } else {
        console.log(`[Web IPC Mock] Instructed C# backend to save settings`, settings);
     }
  },

  loadSettings(): Promise<any> {
    if (this.isNative) {
      return new Promise((resolve) => {
        const id = Date.now().toString();
        const listener = (e: any) => {
          if (e.data && e.data.type === 'LOAD_SETTINGS_RESULT' && e.data.id === id) {
            window.removeEventListener("message", listener);
            resolve(e.data.payload);
          }
        };
        window.addEventListener("message", listener);
        (window as any).chrome.webview.postMessage({ type: 'LOAD_SETTINGS', id });
      });
    } else {
      console.log(`[Web IPC Mock] Instructed C# backend to load settings`);
      // Simulating .ini load for mockup
      return Promise.resolve(null);
    }
  },

  fetchNativeContextMenuItems(path: string): Promise<any[]> {
    if (this.isNative) {
      return new Promise((resolve) => {
        const id = Date.now().toString();
        const listener = (e: any) => {
          if (e.data && e.data.type === 'CONTEXT_MENU_ITEMS_RESULT' && e.data.id === id) {
            window.removeEventListener("message", listener);
            resolve(e.data.payload);
          }
        };
        window.addEventListener("message", listener);
        (window as any).chrome.webview.postMessage({ type: 'GET_CONTEXT_MENU_ITEMS', payload: { path }, id });
      });
    } else {
      console.log(`[Web IPC Mock] Fetching native context menu items for: ${path}`);
      return Promise.resolve([
        { id: 'open', label: 'Open', icon: 'Open' },
        { id: 'edit', label: 'Edit', icon: 'Edit' },
        { id: 'print', label: 'Print', icon: 'Print' },
        { id: 'share', label: 'Share', icon: 'Share' },
        { separator: true },
        { id: 'copy', label: 'Copy', icon: 'Copy' },
        { id: 'cut', label: 'Cut', icon: 'Cut' },
        { id: 'delete', label: 'Delete', icon: 'Trash' },
        { id: 'properties', label: 'Properties', icon: 'Settings' }
      ]);
    }
  },

  checkPathExists(path: string): Promise<boolean> {
     if (this.isNative) {
        return new Promise((resolve) => {
          const id = Date.now().toString() + Math.random().toString();
          const listener = (e: any) => {
            if (e.data && e.data.type === 'CHECK_PATH_RESULT' && e.data.id === id) {
              window.removeEventListener("message", listener);
              resolve(e.data.payload);
            }
          };
          window.addEventListener("message", listener);
          (window as any).chrome.webview.postMessage({ type: 'CHECK_PATH_EXISTS', payload: { path }, id });
        });
     } else {
        console.log(`[Web IPC Mock] Instructed C# backend to check path: ${path}`);
        return Promise.resolve(path.length > 2); // mockup: most paths true
     }
  },

  getDirContents(path: string): Promise<any[]> {
    if (this.isNative) {
      return new Promise((resolve) => {
        const id = Date.now().toString() + Math.random().toString();
        const listener = (e: any) => {
          if (e.data && e.data.type === 'DIR_CONTENTS_RESULT' && e.data.id === id) {
            window.removeEventListener("message", listener);
            resolve(e.data.payload);
          }
        };
        window.addEventListener("message", listener);
        (window as any).chrome.webview.postMessage({ type: 'GET_DIR_CONTENTS', payload: { path }, id });
      });
    } else {
      console.log(`[Web IPC Mock] Instructed C# backend to load directory: ${path}`);
      return Promise.resolve([]);
    }
  },

  performGlobalSearch(query: string, limit: number): Promise<any[]> {
    if (this.isNative) {
      return new Promise((resolve) => {
        const id = Date.now().toString();
        const listener = (e: any) => {
          if (e.data && e.data.type === 'GLOBAL_SEARCH_RESULT' && e.data.id === id) {
            window.removeEventListener("message", listener);
            resolve(e.data.payload);
          }
        };
        window.addEventListener("message", listener);
        (window as any).chrome.webview.postMessage({ type: 'PERFORM_GLOBAL_SEARCH', payload: { query, limit }, id });
      });
    } else {
      console.log(`[Web IPC Mock] Instructed C# backend to perform global search for: ${query} (limit: ${limit})`);
      // Mock result
      return Promise.resolve([
          {
              id: 'mock_search_1',
              name: `EverythingNet_MockResult_for_${query}.exe`,
              type: 'file',
              size: 1524312,
              modified: Date.now(),
              created: Date.now(),
              accessed: Date.now(),
              extension: 'exe',
              path: `/C:/Windows/EverythingNet_MockResult_for_${query}.exe`
          }
      ]);
    }
  },

  getSubDirectories(path: string, showHidden: boolean = false): Promise<any[]> {
    if (this.isNative) {
       return new Promise((resolve) => {
         const id = Date.now().toString() + Math.random().toString();
         const listener = (e: any) => {
           if (e.data && e.data.type === 'SUBDIR_RESULT' && e.data.id === id) {
             window.removeEventListener("message", listener);
             resolve(e.data.payload);
           }
         };
         window.addEventListener("message", listener);
         (window as any).chrome.webview.postMessage({ type: 'GET_SUB_DIRECTORIES', payload: { path, showHidden }, id });
       });
    } else {
       console.log(`[Web IPC Mock] Requested subdirectories for: ${path}`);
       return Promise.resolve([]);
    }
  },

  showNativeContextMenu(path: string, x: number, y: number) {
    if (this.isNative) {
       (window as any).chrome.webview.postMessage({ type: 'SHOW_CONTEXT_MENU', payload: { path, x, y } });
    } else {
       console.log(`[Web IPC Mock] Instructed C# to show native context menu for ${path} at (${x}, ${y})`);
    }
  },

  getNativeThumbnailBase64(path: string): Promise<string | null> {
    if (this.isNative) {
       return new Promise((resolve) => {
         const id = Date.now().toString();
         const listener = (e: any) => {
           if (e.data && e.data.type === 'THUMBNAIL_RESULT' && e.data.id === id) {
             window.removeEventListener("message", listener);
             resolve(e.data.payload);
           }
         };
         window.addEventListener("message", listener);
         (window as any).chrome.webview.postMessage({ type: 'GET_THUMBNAIL', payload: { path }, id });
       });
    } else {
       console.log(`[Web IPC Mock] Requested native thumbnail for: ${path}`);
       return new Promise((resolve) => {
           setTimeout(() => resolve(null), 50); // mocked delay
       });
    }
  },

  getExtendedMetadata(path: string): Promise<Record<string, string>> {
     if (this.isNative) {
        return new Promise((resolve) => {
          const id = Date.now().toString();
          const listener = (e: any) => {
            if (e.data && e.data.type === 'EXTENDED_METADATA_RESULT' && e.data.id === id) {
              window.removeEventListener("message", listener);
              resolve(e.data.payload || {});
            }
          };
          window.addEventListener("message", listener);
          (window as any).chrome.webview.postMessage({ type: 'GET_EXTENDED_METADATA', payload: { path }, id });
        });
     } else {
        console.log(`[Web IPC Mock] Requested extended metadata for: ${path}`);
        return new Promise((resolve) => {
            setTimeout(() => resolve({ "Mocked Data": "True", "Audio Bitrate": "320 kbps", "Dimensions": "1920x1080" }), 50);
        });
     }
  }
};
