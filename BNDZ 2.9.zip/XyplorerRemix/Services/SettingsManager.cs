using System;
using System.IO;

namespace XyplorerRemix.Services
{
    public class SettingsManager
    {
        private readonly string _configFilePath;

        public SettingsManager()
        {
            try
            {
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                string bndzData = Path.Combine(appData, "BNDZ64");
                if (!Directory.Exists(bndzData))
                {
                    Directory.CreateDirectory(bndzData);
                }
                _configFilePath = Path.Combine(bndzData, "bndz_config.json");
            }
            catch
            {
                _configFilePath = "bndz_config.json"; // Fallback to current directory if permissions fail
            }
        }

        public void SaveSettings(string jsonConfig)
        {
            try
            {
                File.WriteAllText(_configFilePath, jsonConfig);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[SettingsManager] Failed to save settings: {ex.Message}");
            }
        }

        public string LoadSettings()
        {
            try
            {
                if (File.Exists(_configFilePath))
                {
                    return File.ReadAllText(_configFilePath);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[SettingsManager] Failed to load settings: {ex.Message}");
            }
            return null;
        }
    }
}
