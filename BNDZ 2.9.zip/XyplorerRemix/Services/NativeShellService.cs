using System;
using System.Drawing;
using Microsoft.WindowsAPICodePack.Shell;
using System.IO;

namespace XyplorerRemix.Services
{
    public class NativeShellService
    {
        public NativeShellService()
        {
        }

        public string GetNativeThumbnailBase64(string filePath)
        {
            try
            {
                if (string.IsNullOrEmpty(filePath) || (!File.Exists(filePath) && !Directory.Exists(filePath)))
                    return "";

                // Attempt to get a high-quality Extra Large thumbnail
                using var fileObj = ShellObject.FromParsingName(filePath);
                using var bitmap = fileObj.Thumbnail.ExtraLargeBitmap;
                if (bitmap != null)
                {
                    using var ms = new MemoryStream();
                    bitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                    return Convert.ToBase64String(ms.ToArray());
                }
            }
            catch
            {
                try
                {
                    // Fallback to basic icon extraction
                    var icon = System.Drawing.Icon.ExtractAssociatedIcon(filePath);
                    if (icon != null)
                    {
                        using var bitmap = icon.ToBitmap();
                        using var ms = new MemoryStream();
                        bitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                        return Convert.ToBase64String(ms.ToArray());
                    }
                }
                catch { }
            }
            return "";
        }

        public System.Collections.Generic.Dictionary<string, string> GetExtendedMetadata(string filePath)
        {
            var meta = new System.Collections.Generic.Dictionary<string, string>();
            try
            {
                if (string.IsNullOrEmpty(filePath) || (!File.Exists(filePath) && !Directory.Exists(filePath))) return meta;
                
                using var fileObj = ShellObject.FromParsingName(filePath);

                var bitRate = fileObj.Properties.System.Audio.EncodingBitrate.Value;
                if (bitRate != null) meta["Audio Bitrate"] = $"{bitRate / 1000} kbps";

                var dims = fileObj.Properties.System.Image.Dimensions.Value;
                if (dims != null) meta["Dimensions"] = dims;

                var duration = fileObj.Properties.System.Media.Duration.Value;
                if (duration != null) meta["Duration"] = TimeSpan.FromTicks((long)duration).ToString(@"hh\:mm\:ss");

                var fileVer = fileObj.Properties.System.Software.ProductVersion.Value;
                if (fileVer != null) meta["Version"] = fileVer;

                var company = fileObj.Properties.System.Software.ProductName.Value;
                if (company != null) meta["Product"] = company;

                var authors = fileObj.Properties.System.Author.Value;
                if (authors != null && authors.Length > 0) meta["Authors"] = string.Join(", ", authors);

            }
            catch {}
            return meta;
        }
    }
}
