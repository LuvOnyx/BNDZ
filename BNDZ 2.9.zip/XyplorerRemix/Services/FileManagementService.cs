using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using Windows.Win32;
using Windows.Win32.UI.Shell;
using Windows.Win32.Foundation;
using Windows.Win32.Graphics.Gdi;
using System.Drawing;
using System.Drawing.Imaging;
using XyplorerRemix.Models;

namespace XyplorerRemix.Services
{
    public class FileManagementService
    {
        public async Task<List<object>> GetDirContentsAsync(string path)
        {
            var results = new List<object>();
            return await Task.Run(() =>
            {
                try
                {
                    if (Directory.Exists(path))
                    {
                        var nativeSvc = new NativeShellService();
                        foreach (var dir in Directory.GetDirectories(path))
                        {
                            var di = new DirectoryInfo(dir);
                            if ((di.Attributes & FileAttributes.Hidden) == FileAttributes.Hidden) continue;
                            
                            results.Add(new {
                                id = Guid.NewGuid().ToString(),
                                name = di.Name,
                                type = "directory",
                                path = dir.Replace("\\", "/"),
                                size = 0,
                                modified = di.LastWriteTime.ToString("O"),
                                created = di.CreationTime.ToString("O"),
                                extension = "",
                                typeDescription = GetFileTypeDescription(dir),
                                iconBase64 = nativeSvc.GetNativeThumbnailBase64(dir)
                            });
                        }
                        
                        foreach (var file in Directory.GetFiles(path))
                        {
                            var fi = new FileInfo(file);
                            if ((fi.Attributes & FileAttributes.Hidden) == FileAttributes.Hidden) continue;
                            
                            results.Add(new {
                                id = Guid.NewGuid().ToString(),
                                name = fi.Name,
                                type = "file",
                                path = file.Replace("\\", "/"),
                                size = fi.Length,
                                modified = fi.LastWriteTime.ToString("O"),
                                created = fi.CreationTime.ToString("O"),
                                extension = fi.Extension.TrimStart('.'),
                                typeDescription = GetFileTypeDescription(file),
                                iconBase64 = nativeSvc.GetNativeThumbnailBase64(file)
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Error enumerating {path}: {ex.Message}");
                }
                return results;
            });
        }

        private string GetFileTypeDescription(string path)
        {
            if (!OperatingSystem.IsWindows()) return "File";

            SHFILEINFO fileInfo = default;
            uint flags = PInvoke.SHGFI_TYPENAME;
            
            PInvoke.SHGetFileInfo(
                path,
                0,
                ref fileInfo,
                (uint)Marshal.SizeOf<SHFILEINFO>(),
                flags);

            return fileInfo.szTypeName.ToString();
        }

        private string GetIconBase64(string path, bool isDirectory)
        {
            if (!OperatingSystem.IsWindows()) return "";

            SHFILEINFO fileInfo = default;
            uint flags = PInvoke.SHGFI_ICON | PInvoke.SHGFI_SMALLICON;
            
            var res = PInvoke.SHGetFileInfo(
                path,
                0, // FILE_ATTRIBUTE_NORMAL
                ref fileInfo,
                (uint)Marshal.SizeOf<SHFILEINFO>(),
                flags);

            if (res != 0 && fileInfo.hIcon != IntPtr.Zero)
            {
                try
                {
                    using var icon = Icon.FromHandle(fileInfo.hIcon);
                    using var bmp = icon.ToBitmap();
                    using var ms = new MemoryStream();
                    bmp.Save(ms, ImageFormat.Png);
                    PInvoke.DestroyIcon(new HICON(fileInfo.hIcon));
                    return "data:image/png;base64," + Convert.ToBase64String(ms.ToArray());
                }
                catch
                {
                    // Ignore extraction errors
                }
            }
            return "";
        }

        public bool BatchRename(List<string> filePaths, string pattern, int startIndex = 1)
        {
            // Simple batch rename replacing {n} with index
            try
            {
                int index = startIndex;
                foreach (var filePath in filePaths)
                {
                    var fileInfo = new FileInfo(filePath);
                    if (fileInfo.Exists)
                    {
                        string newName = pattern.Replace("{n}", index.ToString()) + fileInfo.Extension;
                        string newPath = Path.Combine(fileInfo.DirectoryName ?? "", newName);
                        File.Move(filePath, newPath);
                        index++;
                    }
                }
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
