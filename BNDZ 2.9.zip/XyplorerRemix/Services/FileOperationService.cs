using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

namespace XyplorerRemix.Services
{
    public class FileOperationService
    {
        public delegate void ProgressCallback(string operationId, double percentage, string currentFile, long bytesTransferred, long totalBytes, double speedBytesPerSecond, int itemsCompleted, int totalItems);
        public delegate Task<string> ConflictCallback(string operationId, string fileName, string sourcePath, string destPath);

        private readonly string _ledgerPath;
        private List<OperationLedgerEntry> _undoStack = new List<OperationLedgerEntry>();
        private List<OperationLedgerEntry> _redoStack = new List<OperationLedgerEntry>();

        public class OperationLedgerEntry 
        {
            public string Action { get; set; }
            public string Source { get; set; }
            public string Destination { get; set; }
        }

        public FileOperationService()
        {
            string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string appFolder = Path.Combine(appData, "BNDZ_Remix");
            if (!Directory.Exists(appFolder)) Directory.CreateDirectory(appFolder);
            _ledgerPath = Path.Combine(appFolder, "operation_ledger.json");
            LoadLedger();
        }

        private void LoadLedger()
        {
            try
            {
                if (File.Exists(_ledgerPath))
                {
                    string json = File.ReadAllText(_ledgerPath);
                    _undoStack = System.Text.Json.JsonSerializer.Deserialize<List<OperationLedgerEntry>>(json) ?? new List<OperationLedgerEntry>();
                }
            }
            catch { }
        }

        private void SaveLedger()
        {
            try
            {
                string json = System.Text.Json.JsonSerializer.Serialize(_undoStack);
                File.WriteAllText(_ledgerPath, json);
            }
            catch { }
        }

        private void LogOperation(string action, string source, string dest)
        {
            _undoStack.Add(new OperationLedgerEntry { Action = action, Source = source, Destination = dest });
            if (_undoStack.Count > 100) _undoStack.RemoveAt(0);
            _redoStack.Clear(); // Clear redo stack on new operation
            SaveLedger();
        }

        public async Task ExecuteUndoAsync()
        {
            if (_undoStack.Count == 0) return;
            var op = _undoStack.Last();
            _undoStack.RemoveAt(_undoStack.Count - 1);
            _redoStack.Add(op);
            SaveLedger();
            
            await ExecuteReverseOp(op);
        }

        public async Task ExecuteRedoAsync()
        {
            if (_redoStack.Count == 0) return;
            var op = _redoStack.Last();
            _redoStack.RemoveAt(_redoStack.Count - 1);
            _undoStack.Add(op);
            SaveLedger();

            await ExecuteForwardOp(op);
        }

        private async Task ExecuteReverseOp(OperationLedgerEntry op)
        {
            // Simple reverse logic
            if (op.Action == "move")
            {
                if (File.Exists(op.Destination)) File.Move(op.Destination, op.Source);
                else if (Directory.Exists(op.Destination)) Directory.Move(op.Destination, op.Source);
            }
            else if (op.Action == "copy")
            {
                if (File.Exists(op.Destination)) File.Delete(op.Destination);
                else if (Directory.Exists(op.Destination)) Directory.Delete(op.Destination, true);
            }
            else if (op.Action == "delete")
            {
                // Un-delete from recycle bin unsupported easily, mock for now
            }
        }

        private async Task ExecuteForwardOp(OperationLedgerEntry op)
        {
            if (op.Action == "move")
            {
                if (File.Exists(op.Source)) File.Move(op.Source, op.Destination);
                else if (Directory.Exists(op.Source)) Directory.Move(op.Source, op.Destination);
            }
            else if (op.Action == "copy")
            {
                if (File.Exists(op.Source)) File.Copy(op.Source, op.Destination);
            }
            else if (op.Action == "delete")
            {
                if (File.Exists(op.Source)) File.Delete(op.Source);
                else if (Directory.Exists(op.Source)) Directory.Delete(op.Source, true);
            }
        }

        public async Task ExecuteOperationAsync(
            string operationId, 
            string action, // "copy", "move", "delete"
            IEnumerable<string> sourceFiles, 
            string targetDir, 
            bool bypassRecycleBin,
            ProgressCallback onProgress, 
            ConflictCallback onConflict)
        {
            await Task.Run(async () => 
            {
                if (action == "delete")
                {
                    foreach (var source in sourceFiles)
                    {
                        var sourceFile = source.Replace("/", "\\");
                        if (File.Exists(sourceFile) || Directory.Exists(sourceFile))
                        {
                            if (bypassRecycleBin)
                            {
                                if (File.Exists(sourceFile)) File.Delete(sourceFile);
                                else Directory.Delete(sourceFile, true);
                            }
                            else 
                            {
                                // Using Vanara shell NativeSHFileOperation to send to Recycle Bin
                                var shfo = new Vanara.PInvoke.Shell32.SHFILEOPSTRUCT
                                {
                                    wFunc = Vanara.PInvoke.Shell32.FO_FUNC.FO_DELETE,
                                    pFrom = sourceFile + '\0' + '\0',
                                    pTo = null,
                                    fFlags = Vanara.PInvoke.Shell32.FILEOP_FLAGS.FOF_ALLOWUNDO | Vanara.PInvoke.Shell32.FILEOP_FLAGS.FOF_NOCONFIRMATION | Vanara.PInvoke.Shell32.FILEOP_FLAGS.FOF_SILENT
                                };
                                Vanara.PInvoke.Shell32.SHFileOperation(ref shfo);
                            }
                        }
                        LogOperation("delete", sourceFile, "");
                    }
                    onProgress(operationId, 100, "", 0, 0, 0, 1, 1);
                    return;
                }

                targetDir = targetDir.Replace("/", "\\");
                if (!string.IsNullOrEmpty(targetDir) && !Directory.Exists(targetDir))
                {
                    Directory.CreateDirectory(targetDir);
                }

                List<string> allFilesToProcess = new List<string>();
                Dictionary<string, string> basePaths = new Dictionary<string, string>(); // To easily compute relative paths later

                foreach (var source in sourceFiles)
                {
                    var sourceFile = source.Replace("/", "\\");
                    bool isDirectory = Directory.Exists(sourceFile);
                    if (isDirectory)
                    {
                        var files = Directory.GetFiles(sourceFile, "*.*", SearchOption.AllDirectories);
                        allFilesToProcess.AddRange(files);
                        foreach (var f in files)
                        {
                            basePaths[f] = Directory.GetParent(sourceFile)?.FullName ?? Path.GetDirectoryName(sourceFile) ?? sourceFile;
                        }
                    }
                    else if (File.Exists(sourceFile))
                    {
                        allFilesToProcess.Add(sourceFile);
                        basePaths[sourceFile] = Path.GetDirectoryName(sourceFile);
                    }
                }

                if (allFilesToProcess.Count == 0) return;

                long totalBytes = 0;
                foreach (var f in allFilesToProcess)
                {
                    totalBytes += new FileInfo(f).Length;
                }

                long copiedBytes = 0;
                int totalItems = allFilesToProcess.Count;
                int itemsCompleted = 0;
                var sw = System.Diagnostics.Stopwatch.StartNew();

                var tasks = new List<Task>();
                foreach (var file in allFilesToProcess)
                {
                    string refPath = Path.GetRelativePath(basePaths[file] ?? "", file);
                    string destPath = Path.Combine(targetDir, refPath);

                    string destDir = Path.GetDirectoryName(destPath);
                    if (!string.IsNullOrEmpty(destDir) && !Directory.Exists(destDir))
                        Directory.CreateDirectory(destDir);

                    tasks.Add(ProcessSingleFileAsync(operationId, action, file, destPath, ref totalBytes, ref copiedBytes, ref itemsCompleted, totalItems, sw, onProgress, onConflict));

                    if (tasks.Count >= Environment.ProcessorCount * 4) // SSD max throughput throttle
                    {
                        var completedTask = await Task.WhenAny(tasks);
                        tasks.Remove(completedTask);
                    }
                }

                await Task.WhenAll(tasks);

                if (action == "move") 
                {
                    foreach (var source in sourceFiles)
                    {
                        var sourceFile = source.Replace("/", "\\");
                         bool isDirectory = Directory.Exists(sourceFile);
                         if (isDirectory) Directory.Delete(sourceFile, true);
                    }
                }

                foreach (var source in sourceFiles)
                {
                   LogOperation(action, source.Replace("/", "\\"), targetDir);
                }
            });
        }

        private async Task ProcessSingleFileAsync(
            string operationId,
            string action,
            string sourceFile, 
            string destPath, 
            ref long totalBytes, 
            ref long copiedBytes,
            ref int itemsCompleted,
            int totalItems,
            System.Diagnostics.Stopwatch sw,
            ProgressCallback onProgress,
            ConflictCallback onConflict)
        {
            string finalDestPath = destPath;
            bool skip = false;

            if (File.Exists(finalDestPath))
            {
                var resolution = await onConflict(operationId, Path.GetFileName(sourceFile), sourceFile, finalDestPath);
                if (resolution == "skip")
                {
                    skip = true;
                    long size = new FileInfo(sourceFile).Length;
                    Interlocked.Add(ref copiedBytes, size);
                    Interlocked.Increment(ref itemsCompleted);
                    double speed = sw.Elapsed.TotalSeconds > 0 ? (double)Interlocked.Read(ref copiedBytes) / sw.Elapsed.TotalSeconds : 0;
                    onProgress(operationId, (double)copiedBytes / totalBytes * 100, sourceFile, copiedBytes, totalBytes, speed, itemsCompleted, totalItems);
                }
                else if (resolution == "replace")
                {
                    File.Delete(finalDestPath);
                }
                else if (resolution == "keepboth")
                {
                    string dir = Path.GetDirectoryName(finalDestPath);
                    string name = Path.GetFileNameWithoutExtension(finalDestPath);
                    string ext = Path.GetExtension(finalDestPath);
                    int counter = 1;
                    do
                    {
                        finalDestPath = Path.Combine(dir, $"{name} ({counter}){ext}");
                        counter++;
                    } while (File.Exists(finalDestPath));
                }
            }

            if (!skip)
            {
                await CopyFileToDestinationWithProgressAsync(operationId, sourceFile, finalDestPath, ref totalBytes, ref copiedBytes, ref itemsCompleted, totalItems, sw, onProgress);
                
                if (action == "move")
                {
                    File.Delete(sourceFile);
                }
            }
        }

        private async Task CopyFileToDestinationWithProgressAsync(
            string operationId,
            string sourceFile, 
            string destinationFile, 
            ref long totalBytes, 
            ref long copiedBytes,
            ref int itemsCompleted,
            int totalItems,
            System.Diagnostics.Stopwatch sw,
            ProgressCallback onProgress)
        {
            const int bufferSize = 4096 * 1024; // 4MB buffer for NVMe saturation
            using var sourceStream = new FileStream(sourceFile, FileMode.Open, FileAccess.Read, FileShare.Read, bufferSize, FileOptions.Asynchronous | FileOptions.SequentialScan);
            using var destinationStream = new FileStream(destinationFile, FileMode.Create, FileAccess.Write, FileShare.None, bufferSize, FileOptions.Asynchronous | FileOptions.SequentialScan);
            
            byte[] buffer = new byte[bufferSize];
            int bytesRead;

            while ((bytesRead = await sourceStream.ReadAsync(buffer, 0, buffer.Length)) > 0)
            {
                await destinationStream.WriteAsync(buffer, 0, bytesRead);
                Interlocked.Add(ref copiedBytes, bytesRead);
                
                double speed = sw.Elapsed.TotalSeconds > 0 ? (double)Interlocked.Read(ref copiedBytes) / sw.Elapsed.TotalSeconds : 0;
                onProgress(operationId, (double)Interlocked.Read(ref copiedBytes) / totalBytes * 100, sourceFile, Interlocked.Read(ref copiedBytes), totalBytes, speed, itemsCompleted, totalItems);
            }
            Interlocked.Increment(ref itemsCompleted);
            
            double finalSpeed = sw.Elapsed.TotalSeconds > 0 ? (double)Interlocked.Read(ref copiedBytes) / sw.Elapsed.TotalSeconds : 0;
            onProgress(operationId, (double)Interlocked.Read(ref copiedBytes) / totalBytes * 100, sourceFile, Interlocked.Read(ref copiedBytes), totalBytes, finalSpeed, itemsCompleted, totalItems);
        }
    }
}
