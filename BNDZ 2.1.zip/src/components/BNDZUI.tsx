import React, { useState, useMemo, useEffect, useRef } from 'react';
import { 
  ArrowLeft, ArrowRight, ArrowUp, Monitor, FolderSearch, File, 
  Scissors, Copy, Clipboard, Undo, Redo, Search, RefreshCw, 
  Filter, Settings, Wrench, Menu, HardDrive, Network,
  FolderOpen, Server, Star, Tag, Database, PlayCircle, Folder, ArrowDownCircle, Sparkles, Wand2, Columns, X, AlertTriangle, Archive, Eye, FileText, ChevronDown, ChevronRight, PanelBottom } from 'lucide-react';
import Fuse from 'fuse.js';
import { createInitialFileSystem, getDirContents, getEntityByPath, updateFileSystem } from '../data/initialFS';
import { VirtualDirectory, FSEntity, DriveInfo, ShortcutInfo } from '../types';
import SmartToolsDialog from './SmartToolsDialog';
import RightPreviewPanel from './RightPreviewPanel';
import BottomPluginPanel from './BottomPluginPanel';
import { RenameOperation } from '../lib/ipcBridge';
import { useAppConfig } from '../data/configContext';
import { motion, AnimatePresence } from 'framer-motion';

const ToolbarButton = ({ icon: Icon, color, onClick, className = '', title }: any) => (
  <button title={title} className={`p-[4px] hover:bg-[#333] rounded mx-[1px] flex items-center justify-center ${className}`} onClick={onClick}>
    <Icon size={16} color={color || "#ccc"} />
  </button>
);

const TreeItem = ({ label, icon: Icon, iconColor, indent = 0, selected = false, expanded = false, childrenItems = [], onClick, onToggle, isDynamic, path, currentPath, config }: any) => {
  const [dynExpanded, setDynExpanded] = useState(false);
  const [dynChildren, setDynChildren] = useState<any[] | null>(null);

  const isExpanded = isDynamic ? dynExpanded : expanded;
  const childList = isDynamic ? (dynChildren || []) : childrenItems;

  const handleToggle = () => {
    if (isDynamic) {
        const next = !dynExpanded;
        setDynExpanded(next);
        if (next && !dynChildren) {
             import('../lib/ipcBridge').then(({ IPC }) => {
                 IPC.getSubDirectories(path, config?.showHiddenSystemFoldersInTree).then(dirs => {
                     setDynChildren(dirs.sort((a,b) => a.name.localeCompare(b.name)));
                 });
             });
        }
    } else {
        onToggle?.();
    }
  };

  const handleContext = (e: React.MouseEvent) => {
      if (path && config?.useNativeOSContextMenu !== false) {
          e.preventDefault();
          e.stopPropagation();
          import('../lib/ipcBridge').then(({ IPC }) => {
              IPC.showNativeContextMenu(path, e.screenX, e.screenY);
          });
      }
  };

  return (
    <div>
      <div 
        className={`flex items-center py-[2px] px-1 cursor-pointer whitespace-nowrap ${selected || (isDynamic && currentPath === path) ? 'bg-[#264f78]' : 'hover:bg-[#2a2d2e]'}`} 
        style={{ paddingLeft: `${indent * 12 + 4}px` }}
        onClick={(e) => { e.stopPropagation(); if (isDynamic) { onClick?.(path); } else { onClick?.(); } }}
        onDoubleClick={(e) => { e.stopPropagation(); handleToggle(); }}
        onContextMenu={handleContext}
      >
        {(childList.length > 0 || isDynamic) ? (
          <span 
            className="w-3 text-gray-500 text-[10px] mr-[2px] flex justify-center hover:text-white"
            onClick={(e) => { e.stopPropagation(); handleToggle(); }}
          >
            {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
          </span>
        ) : (
          <span className="w-3 mr-[2px] flex justify-center"></span>
        )}
        {Icon && <Icon size={14} color={iconColor || "#dcb67a"} className="mr-[6px] shrink-0" />}
        <span className="text-[12px] select-none">{label}</span>
      </div>
      {isExpanded && childList && childList.map((child: any, i: number) => (
        <TreeItem 
            key={isDynamic ? child.path : i} 
            {...child} 
            label={isDynamic ? child.name : child.label}
            icon={Folder}
            iconColor="#dcb67a"
            indent={indent + 1} 
            isDynamic={isDynamic}
            path={isDynamic ? child.path : undefined}
            currentPath={currentPath}
            config={config}
            onClick={onClick}
        />
      ))}
    </div>
  );
};

function formatSize(bytes: number) {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}

interface TabState {
  id: string;
  path: string;
  history: string[];
  historyIndex: number;
  selectedItems: string[];
}

interface PaneState {
  id: string;
  tabs: TabState[];
  activeTabIndex: number;
  sortColumn?: 'name' | 'type' | 'size' | 'modified';
  sortDirection?: 'asc' | 'desc';
}

const Spinner = () => (
  <div className="flex justify-center items-center w-full h-full p-4 relative min-w-[50px] min-h-[50px]">
    <div className="w-[40px] h-[40px] border-[3.5px] border-[#333] rounded-full absolute" />
    <div className="w-[40px] h-[40px] border-[3.5px] border-transparent border-t-[#22c55e] border-r-[#22c55e] rounded-full animate-[spin_1s_cubic-bezier(0.5,0,0.5,1)_infinite] absolute" />
    <div className="w-[40px] h-[40px] border-[3.5px] border-transparent border-b-[#22c55e] border-l-[#22c55e] rounded-full animate-[spin_1.5s_cubic-bezier(0.5,0,0.5,1)_infinite_reverse] absolute opacity-70" />
  </div>
);

const Toast = ({ message, onClose }: { message: string, onClose: () => void }) => {
  useEffect(() => {
    const timer = setTimeout(onClose, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed bottom-6 right-6 bg-[#1e1e20] overflow-hidden shadow-[0_8px_30px_rgba(0,0,0,0.8)] border border-[#333] rounded-[8px] p-4 pr-10 flex flex-col gap-1 z-[100] animate-[slide-in-right_0.4s_cubic-bezier(0,0.5,0.2,1)_forwards] select-none">
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center p-[6px] bg-green-500/10 rounded-full text-green-400">
           <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7"></path></svg>
        </div>
        <div className="flex flex-col pr-2">
           <span className="text-[14px] font-semibold text-gray-100 leading-none">Success</span>
           <span className="text-[12px] text-gray-400 pt-[4px]">{message}</span>
        </div>
        <button onClick={onClose} className="absolute right-3 top-3 text-gray-500 hover:text-gray-300 transition-colors pointer-events-auto cursor-pointer"><X size={14} /></button>
      </div>
      <div className="absolute bottom-0 left-0 h-[3px] bg-green-500/80" style={{ width: '100%', transformOrigin: 'left', animation: 'progress 3s linear forwards' }} />
    </div>
  );
};

export default function BNDZUI({ onOpenConfig }: any) {
  const { config } = useAppConfig();
  const [drives, setDrives] = useState<DriveInfo[]>([]);
  const [shortcuts, setShortcuts] = useState<ShortcutInfo[]>([]);
  const [fileSystem, setFileSystem] = useState<VirtualDirectory>(() => createInitialFileSystem());

  useEffect(() => {
    import('../lib/ipcBridge').then(({ IPC }) => {
      IPC.getSystemDrives().then(setDrives);
      IPC.getSystemShortcuts().then(setShortcuts);
    });
  }, []);

  const [expandedPaths, setExpandedPaths] = useState<Set<string>>(new Set(["/C:", "/C:/Users", "/C:/Users/Developer"]));
  const [isSmartToolsOpen, setIsSmartToolsOpen] = useState(false);
  const [isPreviewPanelOpen, setIsPreviewPanelOpen] = useState(false);
  const [isBottomPanelOpen, setIsBottomPanelOpen] = useState(true);
  
  // Dual Pane Architecture state
  const [isDualPane, setIsDualPane] = useState(false);
  const [panes, setPanes] = useState<PaneState[]>([
     { 
       id: 'pane1', 
       tabs: [{ id: 't1', path: '/C:/Users/Developer/BNDZ_CSharp_Windows_App', history: ['/C:/Users/Developer/BNDZ_CSharp_Windows_App'], historyIndex: 0, selectedItems: [] }],
       activeTabIndex: 0,
       sortColumn: 'name',
       sortDirection: 'asc'
     }
  ]);
  const [activePaneId, setActivePaneId] = useState('pane1');
  const [focusedItemId, setFocusedItemId] = useState<string | null>(null);

  // File Operations State
  const [transferProgress, setTransferProgress] = useState<{ [opId: string]: { percentage: number, file: string, bytesTransferred: number, totalBytes: number, speedBytesPerSecond: number, itemsCompleted: number, totalItems: number } }>({});
  const [conflict, setConflict] = useState<{ opId: string, fileName: string, srcPath: string, destPath: string } | null>(null);

  // Omni-Filter State
  const [filterText, setFilterText] = useState("");
  const [globalSearchResults, setGlobalSearchResults] = useState<any[] | null>(null);
  const [isGlobalSearchLoading, setIsGlobalSearchLoading] = useState(false);
  const omniFilterRef = useRef<HTMLInputElement>(null);

  // Trigger Global Search
  useEffect(() => {
     if (config.enableGlobalSearchPrefix && filterText.trimStart().startsWith('> ')) {
         const query = filterText.trimStart().substring(2).trim();
         if (query.length > 0) {
             setIsGlobalSearchLoading(true);
             const timer = setTimeout(() => {
                 import('../lib/ipcBridge').then(({ IPC }) => {
                     IPC.performGlobalSearch(query, config.globalSearchLimit || 1000).then(results => {
                         setGlobalSearchResults(results);
                         setIsGlobalSearchLoading(false);
                     });
                 });
             }, 300);
             return () => clearTimeout(timer);
         } else {
             setGlobalSearchResults(null);
             setIsGlobalSearchLoading(false);
         }
     } else {
         setGlobalSearchResults(null);
         setIsGlobalSearchLoading(false);
     }
  }, [filterText, config.enableGlobalSearchPrefix, config.globalSearchLimit]);

  // Context Menu State
  const [contextMenu, setContextMenu] = useState<{ x: number, y: number, entityId: string | null, path: string, entityName: string | null, isDirectory: boolean } | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [dragTargetId, setDragTargetId] = useState<string | null>(null);

  useEffect(() => {
    const handleClickOutside = () => setContextMenu(null);
    window.addEventListener('click', handleClickOutside);
    return () => window.removeEventListener('click', handleClickOutside);
  }, []);

  const activePaneIndex = panes.findIndex(p => p.id === activePaneId);
  const activePane = panes[activePaneIndex] || panes[0];
  const activeTab = activePane?.tabs[activePane.activeTabIndex] || { path: '/', selectedItems: [] };
  const currentPath = activeTab.path;

  // --- External File System Watcher ---
  useEffect(() => {
    let unsubscribe: () => void;
    import('../lib/ipcBridge').then(({ IPC }) => {
      unsubscribe = IPC.onFsEvents((events) => {
        setFileSystem(prevFs => {
          let newFs = prevFs;
          for (const ev of events) {
            const vPath = ev.dir.replace(/\\/g, '/');
            newFs = updateFileSystem(newFs, vPath, (dir) => {
              if (ev.type === 'Created' && !dir.children[ev.name]) {
                const isFile = ev.name.includes('.');
                dir.children[ev.name] = {
                  id: `${vPath}/${ev.name}`,
                  name: ev.name,
                  type: isFile ? 'file' : 'directory',
                  size: isFile ? 1024 : 0,
                  modified: new Date().toISOString(),
                  tags: [],
                  ...(isFile ? { extension: ev.name.split('.').pop() } : { children: {} })
                } as any;
              } else if (ev.type === 'Deleted') {
                delete dir.children[ev.name];
              } else if (ev.type === 'Renamed' && ev.oldName) {
                const node = dir.children[ev.oldName];
                if (node) {
                  dir.children[ev.name] = { ...node, name: ev.name };
                  delete dir.children[ev.oldName];
                }
              }
            });
          }
          return newFs;
        });
      });
    });
    return () => unsubscribe && unsubscribe();
  }, []);

  // Monitor paths when panes change to fire native FileSystemWatcher
  useEffect(() => {
    import('../lib/ipcBridge').then(({ IPC }) => {
       panes.forEach(p => {
          p.tabs.forEach(t => {
            if (t.path && t.path.includes('/')) {
               IPC.watchDirectory(t.path);
            }
          });
       });
    });
  }, [panes]);

  // Operations Progress and Conflict Listeners
  useEffect(() => {
    let unsubProp: () => void;
    let unsubConf: () => void;
    import('../lib/ipcBridge').then(({ IPC }) => {
      unsubProp = IPC.onProgress((progressDetails) => {
        setTransferProgress(prev => ({
           ...prev,
           [progressDetails.operationId]: {
              percentage: progressDetails.percentage,
              file: progressDetails.currentFile,
              bytesTransferred: progressDetails.bytesTransferred || 0,
              totalBytes: progressDetails.totalBytes || 0,
              speedBytesPerSecond: progressDetails.speedBytesPerSecond || 0,
              itemsCompleted: progressDetails.itemsCompleted || 0,
              totalItems: progressDetails.totalItems || 0
           }
        }));
        if (progressDetails.percentage >= 100) {
           setTimeout(() => {
             setTransferProgress(prev => {
                const next = { ...prev };
                delete next[progressDetails.operationId];
                return next;
             });
           }, 1000);
        }
      });
      unsubConf = IPC.onConflictContent((conflictDetails) => {
         setConflict(conflictDetails);
      });
    });
    return () => {
       unsubProp && unsubProp();
       unsubConf && unsubConf();
    };
  }, []);

  // --- Tree State Helpers ---
  const toggleExpand = (path: string) => {
    setExpandedPaths(prev => {
      const next = new Set(prev);
      if (next.has(path)) next.delete(path);
      else next.add(path);
      return next;
    });
  };

  const buildFSTree = (node: FSEntity, path: string): any => {
    if (node.type !== "directory") return null;
    const isExpanded = expandedPaths.has(path);
    const childrenItems = Object.keys(node.children)
      .map(k => buildFSTree(node.children[k], `${path}/${k}`))
      .filter(Boolean);

    return {
      label: node.name,
      icon: Folder,
      iconColor: "#dcb67a",
      selected: currentPath === path,
      expanded: isExpanded,
      onClick: () => { setCurrentPath(path); },
      onToggle: () => toggleExpand(path),
      childrenItems
    };
  };

  const treeData = [
    { label: "Rapid Access", icon: Star, iconColor: "#6dc2b8" },
    { 
      label: "This PC", icon: Monitor, iconColor: "#6db4e6", expanded: true, selected: currentPath === '/',
      onClick: () => setCurrentPath('/'),
      childrenItems: [
        { label: "Desktop", path: "C:/Users/Default/Desktop", isDynamic: true, icon: Monitor, iconColor: "#6db4e6" },
        { label: "Documents", path: "C:/Users/Default/Documents", isDynamic: true, icon: File, iconColor: "#dcb67a" },
        { label: "Downloads", path: "C:/Users/Default/Downloads", isDynamic: true, icon: ArrowDownCircle, iconColor: "#dcb67a" },
        ...drives.map(d => ({
           label: `${d.label} (${d.name.replace(/^\//,'')})`,
           icon: HardDrive,
           iconColor: d.name.includes("C:") ? "#6db4e6" : "#aaa",
           path: d.name,
           isDynamic: true
        }))
      ].filter(Boolean)
    },
    { label: "Network", icon: Network, iconColor: "#6db4e6" }
  ];

  // --- Multi-pane Orchestration Logic ---
  const toggleDualPane = () => {
    if (isDualPane) {
       setPanes([activePane]);
       setIsDualPane(false);
    } else {
       setPanes([panes[0], { 
         id: `pane-${Date.now()}`, 
         tabs: [{ id: `t-${Date.now()}`, path: '/D:', history: ['/D:'], historyIndex: 0, selectedItems: [] }],
         activeTabIndex: 0,
         sortColumn: 'name',
         sortDirection: 'asc'
       }]);
       setIsDualPane(true);
    }
  };

  const addTab = (paneId: string, path: string) => {
    setPanes(prev => prev.map(p => {
      if (p.id === paneId) {
        const newTab = { id: `t-${Date.now()}`, path, history: [path], historyIndex: 0, selectedItems: [] };
        return { ...p, tabs: [...p.tabs, newTab], activeTabIndex: p.tabs.length };
      }
      return p;
    }));
  };

  const closeTab = (paneId: string, tabIndex: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setPanes(prev => prev.map(p => {
      if (p.id === paneId && p.tabs.length > 1) {
        const newTabs = p.tabs.filter((_, i) => i !== tabIndex);
        const newActive = Math.min(p.activeTabIndex, newTabs.length - 1);
        return { ...p, tabs: newTabs, activeTabIndex: newActive };
      }
      return p;
    }));
  };

  const setActiveTab = (paneId: string, tabIndex: number) => {
    setActivePaneId(paneId);
    setPanes(prev => prev.map(p => p.id === paneId ? { ...p, activeTabIndex: tabIndex } : p));
  };

  const setCurrentPath = (path: string, paneId: string = activePaneId, updateHistory: boolean = true) => {
    setPanes(prev => prev.map(p => {
      if (p.id === paneId) {
        const newTabs = [...p.tabs];
        const tab = newTabs[p.activeTabIndex];
        let newHistory = tab.history;
        let newHistoryIndex = tab.historyIndex;
        if (updateHistory && tab.path !== path) {
            newHistory = newHistory.slice(0, newHistoryIndex + 1);
            newHistory.push(path);
            newHistoryIndex = newHistory.length - 1;
        }
        newTabs[p.activeTabIndex] = { ...tab, path, history: newHistory, historyIndex: newHistoryIndex, selectedItems: [] };
        return { ...p, tabs: newTabs };
      }
      return p;
    }));
  };

  const goBack = (paneId: string = activePaneId) => {
    setPanes(prev => prev.map(p => {
      if (p.id === paneId) {
         const newTabs = [...p.tabs];
         const tab = newTabs[p.activeTabIndex];
         if (tab.historyIndex > 0) {
             const newHistoryIndex = tab.historyIndex - 1;
             const path = tab.history[newHistoryIndex];
             newTabs[p.activeTabIndex] = { ...tab, path, historyIndex: newHistoryIndex, selectedItems: [] };
         }
         return { ...p, tabs: newTabs };
      }
      return p;
    }));
  };

  const goForward = (paneId: string = activePaneId) => {
    setPanes(prev => prev.map(p => {
      if (p.id === paneId) {
         const newTabs = [...p.tabs];
         const tab = newTabs[p.activeTabIndex];
         if (tab.historyIndex < tab.history.length - 1) {
             const newHistoryIndex = tab.historyIndex + 1;
             const path = tab.history[newHistoryIndex];
             newTabs[p.activeTabIndex] = { ...tab, path, historyIndex: newHistoryIndex, selectedItems: [] };
         }
         return { ...p, tabs: newTabs };
      }
      return p;
    }));
  };

  const setSelectedItems = (items: string[] | ((prev: string[]) => string[]), paneId: string = activePaneId) => {
    setPanes(prev => prev.map(p => {
      if (p.id === paneId) {
         const newTabs = [...p.tabs];
         const tab = newTabs[p.activeTabIndex];
         const newSelected = typeof items === 'function' ? items(tab.selectedItems) : items;
         newTabs[p.activeTabIndex] = { ...tab, selectedItems: newSelected };
         return { ...p, tabs: newTabs };
      }
      return p;
    }));
  };

  const toggleSort = (paneId: string, column: 'name' | 'type' | 'size' | 'modified') => {
    setPanes(prev => prev.map(p => {
      if (p.id === paneId) {
         if (p.sortColumn === column) {
            return { ...p, sortDirection: p.sortDirection === 'asc' ? 'desc' : 'asc' };
         } else {
            return { ...p, sortColumn: column, sortDirection: 'asc' };
         }
      }
      return p;
    }));
  };

  const goUp = (paneId: string = activePaneId) => {
    const p = panes.find(x => x.id === paneId);
    if (!p) return;
    const cPath = p.tabs[p.activeTabIndex].path;
    if (cPath === "/C:" || cPath === "/D:") {
      setCurrentPath("/", paneId);
    } else if (cPath.includes("/")) {
      setCurrentPath(cPath.substring(0, cPath.lastIndexOf("/")), paneId);
    }
    setSelectedItems([], paneId);
  };

  // Keyboard state
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isInput = e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement;

      if (e.key === '/') {
          if (document.activeElement !== omniFilterRef.current && !isInput) {
              e.preventDefault();
              omniFilterRef.current?.focus();
              return;
          }
      }
      
      if (e.key === 'Escape') {
          if (document.activeElement === omniFilterRef.current) {
              e.preventDefault();
              omniFilterRef.current?.blur();
              setFilterText('');
              return;
          }
      }

      if (e.altKey && e.key === 'ArrowLeft') {
         e.preventDefault();
         goBack(activePaneId);
      } else if (e.altKey && e.key === 'ArrowRight') {
         e.preventDefault();
         goForward(activePaneId);
      } else if ((e.altKey && e.key === 'ArrowUp') || (e.key === 'Backspace' && !isInput)) {
         e.preventDefault();
         goUp(activePaneId);
      }

      // Ignore other keys if user is typing in another input (like Smart Tools)
      if (isInput && document.activeElement !== omniFilterRef.current) return;

      // Allow typing in OmniFilter to proceed normally, but handle specific keys like Down/Up/Enter
      if (document.activeElement === omniFilterRef.current && !['ArrowDown', 'ArrowUp', 'Enter'].includes(e.key)) {
          return;
      }

      if (e.key === 'Tab') {
        e.preventDefault();
        if (isDualPane) {
           const nextIdx = (activePaneIndex + 1) % panes.length;
           setActivePaneId(panes[nextIdx].id);
        }
      } else if (e.key === 't' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        addTab(activePaneId, activeTab.path);
      } else if (e.key === 'F2') {
        e.preventDefault();
        if (activeTab.selectedItems.length > 0) {
           setIsSmartToolsOpen(true);
        }
      } else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        const isGlobal = config.enableGlobalSearchPrefix && filterText.trimStart().startsWith('> ');
        let paneContents = activeTab.path === '/' || activeTab.path === '/D:' ? [] : getDirContents(fileSystem, activeTab.path) || [];
        
        if (isGlobal) {
            paneContents = globalSearchResults || [];
        } else if (filterText.trim() !== '') {
            const fuse = new Fuse(paneContents, {
               keys: ['name', 'extension'],
               threshold: 0.3
            });
            paneContents = fuse.search(filterText).map(res => res.item) as any;
        }

        if (paneContents.length === 0) return;
        
        let idx = paneContents.findIndex((c: any) => c.id === focusedItemId || (activeTab.selectedItems.length > 0 && c.id === activeTab.selectedItems[0]));
        
        if (e.key === 'ArrowDown') {
           idx = idx === -1 ? 0 : Math.min(idx + 1, paneContents.length - 1);
        } else {
           idx = idx === -1 ? paneContents.length - 1 : Math.max(idx - 1, 0);
        }
        
        const nextItem = paneContents[idx] as any;
        if (nextItem) {
           setFocusedItemId(nextItem.id);
           setSelectedItems([nextItem.id], activePaneId);
           const el = document.getElementById(`fs-item-${nextItem.id}`);
           if (el) el.scrollIntoView({ block: 'nearest' });
        }
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (activeTab.selectedItems.length > 0) {
           const isGlobal = config.enableGlobalSearchPrefix && filterText.trimStart().startsWith('> ');
           let paneContents = activeTab.path === '/' || activeTab.path === '/D:' ? [] : getDirContents(fileSystem, activeTab.path) || [];
           if (isGlobal) {
               paneContents = globalSearchResults || [];
           } else if (filterText.trim() !== '') {
               const fuse = new Fuse(paneContents, {
                  keys: ['name', 'extension'],
                  threshold: 0.3
               });
               paneContents = fuse.search(filterText).map(res => res.item) as any;
           }
           const selectedItem = paneContents?.find((c: any) => c.id === activeTab.selectedItems[0]) as any;
           if (selectedItem?.type === 'directory') {
               const newPath = selectedItem.path || `${activeTab.path}/${selectedItem.name}`;
               setCurrentPath(newPath, activePaneId);
               setFilterText(''); // Clear filter when opening directory
               omniFilterRef.current?.blur();
           } else if (selectedItem?.type === 'file') {
               // Optional: If it's a file, execute it or open directory (if the path is known)
               if (isGlobal && selectedItem.path) {
                    const dirPath = selectedItem.path.substring(0, selectedItem.path.lastIndexOf('/'));
                    setCurrentPath(dirPath, activePaneId);
                    setFilterText('');
                    omniFilterRef.current?.blur();
                    // maybe focus this item?
                    setTimeout(() => {
                        setFocusedItemId(selectedItem.id);
                        setSelectedItems([selectedItem.id], activePaneId);
                        const el = document.getElementById(`fs-item-${selectedItem.id}`);
                        if (el) el.scrollIntoView({ block: 'nearest' });
                    }, 50);
               }
           }
        }
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [panes, activePaneId, isDualPane, activePaneIndex, activeTab, fileSystem, focusedItemId, filterText]);

  // Bridge Handler for AI renaming modification
  const handleApplyRename = (operations: RenameOperation[]) => {
     let newFs = fileSystem;
     newFs = updateFileSystem(newFs, activeTab.path, (dir) => {
        for (const op of operations) {
            const fileKey = Object.keys(dir.children).find(k => dir.children[k].name === op.originalName);
            if (fileKey) {
                const node = dir.children[fileKey] as any;
                dir.children[op.newName] = { ...node, name: op.newName, modified: new Date().toISOString() };
                if (node.type === "file") {
                   const parts = op.newName.split('.');
                   (dir.children[op.newName] as any).extension = parts.length > 1 ? parts.pop()! : '';
                }
                delete dir.children[fileKey];
            }
        }
     });
     setFileSystem(newFs);
     setSelectedItems([]); 
  };

    // Retrieves active selected objects for AI manipulation context
    const isGlobal = config.enableGlobalSearchPrefix && filterText.trimStart().startsWith('> ');
    let activeContents = currentPath === '/' || currentPath === '/D:' ? [] : getDirContents(fileSystem, currentPath);
    if (isGlobal) activeContents = globalSearchResults || [];
    
    const activeFilesMap = activeContents?.filter(c => activeTab.selectedItems.includes(c.id)) || [];

  // --- Subcomponents ---
  const renderPane = (pane: PaneState, index: number) => {
    const isActive = pane.id === activePaneId;
    const currentTab = pane.tabs[pane.activeTabIndex];
    const panePath = currentTab.path;
    const isGlobal = isActive && config.enableGlobalSearchPrefix && filterText.trimStart().startsWith('> ');
    
    let contents = panePath === '/' || panePath === '/D:' ? null : getDirContents(fileSystem, panePath);
    if (isGlobal) {
        if (isGlobalSearchLoading) {
            // Render loading indicator
            contents = [];
        } else if (globalSearchResults) {
            contents = globalSearchResults;
        } else {
            contents = [];
        }
    } else if (contents && isActive && filterText.trim() !== '') {
        const fuse = new Fuse(contents, {
           keys: ['name', 'extension'],
           threshold: 0.3
        });
        contents = fuse.search(filterText).map(res => res.item) as any;
    }

    if (contents) {
        contents = [...contents].sort((a, b) => {
            if (config.sortFoldersFirst) {
               const dirA = a.type === 'directory' ? -1 : 1;
               const dirB = b.type === 'directory' ? -1 : 1;
               if (dirA !== dirB) return dirA - dirB; // Always sort directories first
            }

            const col = pane.sortColumn || 'name';
            const dir = pane.sortDirection === 'desc' ? -1 : 1;

            if (col === 'name') {
                return dir * a.name.localeCompare(b.name);
            } else if (col === 'type') {
                const typeA = (a as any).extension || '';
                const typeB = (b as any).extension || '';
                return dir * typeA.localeCompare(typeB);
            } else if (col === 'size') {
                const sizeA = (a as any).size || 0;
                const sizeB = (b as any).size || 0;
                return dir * (sizeA - sizeB);
            } else if (col === 'modified') {
                const modA = new Date(a.modified).getTime();
                const modB = new Date(b.modified).getTime();
                return dir * (modA - modB);
            }
            return 0;
        });
    }

    const handleEntityClicked = (e: React.MouseEvent, id: string) => {
      e.stopPropagation();
      setActivePaneId(pane.id);
      setFocusedItemId(id);
      if (e.ctrlKey || e.metaKey) {
        setSelectedItems(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id], pane.id);
      } else {
        setSelectedItems([id], pane.id);
      }
    };

    const handleEntityDoubleClicked = (entity: any) => {
      setActivePaneId(pane.id);
      setFocusedItemId(entity.id);
      if (entity.type === "directory") {
        const newPath = isGlobal && entity.path ? entity.path : `${panePath}/${entity.name}`;
        setCurrentPath(newPath, pane.id);
        if (isGlobal) {
            setFilterText('');
            omniFilterRef.current?.blur();
        }
      } else {
        if (isGlobal && entity.path) {
            import('../lib/ipcBridge').then(({IPC}) => IPC.shellExecute('open', entity.path));
        }
      }
    };

    const handleDragOver = (e: React.DragEvent) => {
      e.preventDefault();
    };

    const handleDrop = (e: React.DragEvent, dropTargetIdOverride?: string | null) => {
      e.preventDefault();
      try {
        const dataStr = e.dataTransfer.getData("application/bndz-file");
        if (!dataStr) return;
        const data = JSON.parse(dataStr);
        
        let destPath = panePath;
        if (dropTargetIdOverride) {
          const targetEntity = contents.find(c => c.id === dropTargetIdOverride);
          if (targetEntity && targetEntity.type === "directory") {
            destPath = `${panePath}/${targetEntity.name}`;
          }
        }

        if (data.sourcePaneId !== pane.id || data.sourcePath !== destPath) {
           const srcDirContents = getDirContents(fileSystem, data.sourcePath) || [];
           const entityToMove = srcDirContents.find((c: any) => c.id === data.entityId);
           if (!entityToMove) return;

           // Determine source full path
           const sourceFullPath = `${data.sourcePath}/${entityToMove.name}`;

           // Dynamically instruct native layer
           import('../lib/ipcBridge').then(({ IPC }) => {
              const opId = `op-${Date.now()}`;
              IPC.executeFsOperation(opId, 'move', sourceFullPath, destPath);
              
              if (!IPC.isNative) {
                 // Fallback eager update for web mockup
                 let newFs = fileSystem;
                 newFs = updateFileSystem(newFs, data.sourcePath, (dir) => {
                   const key = Object.keys(dir.children).find(k => dir.children[k].id === data.entityId);
                   if (key) delete dir.children[key];
                 });
      
                 newFs = updateFileSystem(newFs, destPath, (dir) => {
                   dir.children[entityToMove.name] = entityToMove;
                 });
                 setFileSystem(newFs);
              }
           });
        }
      } catch (err) {
         console.error(err);
      }
    };

    return (
      <div 
        key={pane.id}
        className={`flex-1 flex flex-col min-w-0 ${config.applyColors ? '' : 'bg-[#1c1c1c]'} ${isActive && isDualPane ? 'shadow-[inset_0_0_0_1px_rgba(59,130,246,0.6)] z-10' : ''} relative`}
        style={config.applyColors ? { backgroundColor: 'var(--list-bg)', color: 'var(--list-text)' } : {}}
        onClick={() => { setActivePaneId(pane.id); }}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
      >
        {config.shadeInactivePane !== false && !isActive && isDualPane && (
           <div className="absolute inset-0 bg-black/15 z-[5] pointer-events-none"></div>
        )}
        {/* Tab Strip */}
        <div className="flex bg-[#111] pt-1 px-1 shrink-0 overflow-x-auto no-scrollbar border-b border-[#333] items-end min-h-[28px]">
           {pane.tabs.map((tab, idx) => {
             const isTabActive = idx === pane.activeTabIndex;
             const name = tab.path === '/' ? 'This PC' : tab.path === '/C:' ? 'Local Disk (C:)' : tab.path === '/D:' ? 'Backup (D:)' : tab.path.split('/').pop();
             return (
               <div 
                 key={tab.id}
                 onClick={(e) => { e.stopPropagation(); setActiveTab(pane.id, idx); }}
                 className={`flex items-center px-3 py-[4px] ml-[2px] rounded-t z-10 -mb-[1px] cursor-pointer group border-t border-l border-r ${config.flexibleTabWidth ? 'max-w-[150px]' : ''} ${isTabActive ? 'border-[#333]' : 'border-transparent hover:border-[#333]'} ${config.makeSelectedTabBold && isTabActive ? 'font-bold' : 'font-semibold'}`}
                 style={config.applyColors ? {
                    backgroundColor: isTabActive ? 'var(--tab-active-bg)' : 'var(--tab-inactive-bg)',
                    color: isTabActive ? 'var(--tab-active-text)' : 'var(--tab-inactive-text)'
                 } : {
                    backgroundColor: isTabActive ? '#1c1c1c' : '#111',
                    color: isTabActive ? '#6db4e6' : '#6b7280'
                 }}
               >
                 {config.showIconsTabs !== false && (
                    <Folder size={12} className={`mr-1.5 ${isTabActive ? 'text-[#dcb67a]' : 'text-gray-500'} ${config.makeSelectedTabBold && isTabActive ? 'stroke-[2.5px]' : ''}`} />
                 )}
                 <span className={`truncate text-[11px]`}>{name}</span>
                 {config.showXCloseButtonsOnTabs !== "None" && pane.tabs.length > 1 && (config.showXCloseButtonsOnTabs === "All tabs" || isTabActive) && (
                    <X size={12} className={`ml-2 text-gray-500 hover:text-red-400 opacity-100`} onClick={(e) => closeTab(pane.id, idx, e)} />
                 )}
               </div>
             );
           })}
           {config.showNewTabButton !== false && (
             <div 
               className="ml-1 px-2 py-[2px] hover:bg-[#333] rounded-t flex items-center justify-center cursor-pointer text-gray-400 font-bold"
               onClick={(e) => { e.stopPropagation(); addTab(pane.id, currentTab.path); }}
             >
               <span className="text-[14px] leading-tight">+</span>
             </div>
           )}
           {config.showTabListButton && (
             <div 
               className="ml-1 px-2 py-[2px] hover:bg-[#333] rounded-t flex items-center justify-center cursor-pointer text-gray-400"
             >
               <Menu size={12} />
             </div>
           )}
        </div>
        
        {/* Breadcrumb Row */}
        <div className={`flex ${config.applyColors ? '' : 'bg-[#1a1a1a]'} border-b border-[#333] items-center px-1 py-[2px] shrink-0`}
             style={config.applyColors ? { backgroundColor: 'var(--breadcrumb-bg)', color: 'var(--breadcrumb-text)' } : {}}>
            <ToolbarButton icon={ArrowLeft} className={`w-5 ${currentTab.historyIndex > 0 ? '' : 'opacity-30'}`} onClick={() => goBack(pane.id)} />
            <ToolbarButton icon={ArrowRight} className={`w-5 ${currentTab.historyIndex < currentTab.history.length - 1 ? '' : 'opacity-30'}`} onClick={() => goForward(pane.id)} />
            <ToolbarButton icon={ArrowUp} className="w-5" onClick={() => goUp(pane.id)} />
            <div className="flex items-center text-[12px] px-1 overflow-x-hidden whitespace-nowrap mask-image-rtl flex-1">
              {isGlobal ? (
                 <React.Fragment>
                    <span className="text-gray-500 mx-1 shrink-0">Global Search &gt;</span>
                    <span className="hover:underline cursor-pointer font-semibold shrink-0 text-yellow-400">
                       {filterText.trimStart().substring(2).trim()}
                    </span>
                 </React.Fragment>
              ) : currentTab.path.split('/').map((part, idx, arr) => {
                if (!part) return null;
                const thisPath = arr.slice(0, idx + 1).join('/');
                return (
                  <React.Fragment key={idx}>
                    {idx > 1 && <span className="text-gray-500 mx-1 shrink-0">&gt;</span>}
                    <span 
                      className="hover:underline cursor-pointer font-semibold shrink-0"
                      onClick={(e) => { e.stopPropagation(); setCurrentPath(thisPath, pane.id); }}
                    >
                      {part}
                    </span>
                  </React.Fragment>
                )
              })}
            </div>
            <ToolbarButton icon={Filter} className="w-5 shrink-0" />
        </div>

        {/* Grid Header */}
        <div className="flex bg-[#1a1a1a] border-b border-[#333] text-[#aaa] text-[11px] py-1 shrink-0 px-1 select-none">
           <div className="w-6 border-r border-[#333]"></div>
           <div className="w-[45%] max-w-[300px] px-2 border-r border-[#333] flex items-center justify-between cursor-pointer hover:bg-[#2a2a2a]" onClick={() => toggleSort(pane.id, 'name')}>
             Name {pane.sortColumn === 'name' && <span className="text-[10px]">{pane.sortDirection === 'asc' ? '▲' : '▼'}</span>}
           </div>
           <div className="w-[15%] max-w-[120px] px-2 border-r border-[#333] flex items-center justify-between cursor-pointer hover:bg-[#2a2a2a]" onClick={() => toggleSort(pane.id, 'type')}>
             Type {pane.sortColumn === 'type' && <span className="text-[10px]">{pane.sortDirection === 'asc' ? '▲' : '▼'}</span>}
           </div>
           <div className="w-[15%] max-w-[100px] px-2 border-r border-[#333] flex items-center justify-between cursor-pointer hover:bg-[#2a2a2a]" onClick={() => toggleSort(pane.id, 'size')}>
             <span className="flex-1 text-right">Size</span> {pane.sortColumn === 'size' && <span className="text-[10px] ml-1">{pane.sortDirection === 'asc' ? '▲' : '▼'}</span>}
           </div>
           <div className="w-[25%] max-w-[160px] px-2 border-r border-[#333] flex items-center justify-between cursor-pointer hover:bg-[#2a2a2a]" onClick={() => toggleSort(pane.id, 'modified')}>
             Modified {pane.sortColumn === 'modified' && <span className="text-[10px]">{pane.sortDirection === 'asc' ? '▲' : '▼'}</span>}
           </div>
           <div className="flex-1 px-2 border-r border-[#333]">Tags</div>
        </div>

        {/* List Items */}
        <div 
           className="flex-1 overflow-y-auto p-1 text-white focus:outline-none"
           onContextMenu={(e) => {
              e.preventDefault();
              setContextMenu({
                 x: e.clientX,
                 y: e.clientY,
                 entityId: null,
                 path: panePath,
                 entityName: null,
                 isDirectory: true
              });
           }}
        >
           {contents === null ? (
             <>
               {/* Fixed Drives Overview View */}
               <div className="flex items-center mb-1 group cursor-pointer hover:bg-[#2a2d2e] p-1 border border-transparent" 
                    onClick={(e) => { e.stopPropagation(); setActivePaneId(pane.id); }} 
                    onDoubleClick={() => {
                        setCurrentPath('/C:', pane.id);
                    }}
                >
                  <div className="w-6 flex justify-center"><HardDrive size={16} className="text-[#6db4e6]" /></div>
                  <div className="flex-1 flex text-[12px] items-center">
                     <div className="w-[45%] max-w-[300px] px-2">Local Disk (C:)</div>
                     <div className="w-[15%] max-w-[120px] px-2">System Drive</div>
                     <div className="w-[15%] max-w-[100px] px-2 text-right">464 GB</div>
                     <div className="w-[25%] max-w-[160px] px-2"></div>
                     <div className="flex-1 pl-2">
                        <div className="w-[180px] h-3 bg-[#333] border border-[#555] rounded-sm mb-[2px] overflow-hidden relative">
                           <div className="h-full bg-[#a03050]" style={{width: '98%'}}></div>
                        </div>
                        <div className="text-[10px] text-gray-400">2.08 GB free of 464.11 GB</div>
                     </div>
                  </div>
               </div>

               <div className="flex items-center mb-1 group cursor-pointer hover:bg-[#2a2d2e] p-1 border border-transparent" 
                    onClick={(e) => { e.stopPropagation(); setActivePaneId(pane.id); }}
                    onDoubleClick={() => {
                        setCurrentPath('/D:', pane.id);
                    }}
                >
                  <div className="w-6 flex justify-center"><HardDrive size={16} className="text-gray-400" /></div>
                  <div className="flex-1 flex text-[12px] items-center">
                     <div className="w-[45%] max-w-[300px] px-2">Backup (D:)</div>
                     <div className="w-[15%] max-w-[120px] px-2">Data Drive</div>
                     <div className="w-[15%] max-w-[100px] px-2 text-right">232 GB</div>
                     <div className="w-[25%] max-w-[160px] px-2"></div>
                     <div className="flex-1 pl-2">
                        <div className="w-[180px] h-3 bg-[#333] border border-[#555] rounded-sm mb-[2px] overflow-hidden relative">
                           <div className="h-full bg-[#6a6a6a]" style={{width: '94%'}}></div>
                        </div>
                        <div className="text-[10px] text-gray-400">14.48 GB free of 232.11 GB</div>
                     </div>
                  </div>
               </div>
             </>
           ) : (
             contents.map((entity) => {
               const isSelected = currentTab.selectedItems.includes(entity.id);
               const isDir = entity.type === "directory";
               return (
                 <div 
                   key={entity.id} 
                   id={`fs-item-${entity.id}`}
                   className={`flex items-center text-[12px] py-[3px] border cursor-pointer 
                     ${isSelected ? 'border-[#007acc]' : 'border-transparent hover:bg-[#2a2d2e]'}
                     ${focusedItemId === entity.id ? 'ring-1 ring-inset ring-white/30' : ''}
                     ${dragTargetId === entity.id && isDir ? 'ring-2 ring-inset ring-sky-400 bg-sky-900/40' : ''}`}
                   style={(config.applyColors && isSelected) ? { backgroundColor: 'var(--list-selected-bg)' } : (isSelected ? { backgroundColor: '#264f78' } : {})}
                   onClick={(e) => handleEntityClicked(e, entity.id)}
                   onDoubleClick={() => handleEntityDoubleClicked(entity)}
                   onDragEnter={(e) => { e.preventDefault(); if (isDir) setDragTargetId(entity.id); }}
                   onDragLeave={(e) => { e.preventDefault(); if (dragTargetId === entity.id) setDragTargetId(null); }}
                   onDragOver={(e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; }}
                   onDrop={(e) => { e.preventDefault(); e.stopPropagation(); setDragTargetId(null); if (isDir) { handleDrop(e, entity.id); } else { handleDrop(e); } }}
                   onContextMenu={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      handleEntityClicked(e, entity.id); // Select it
                      setContextMenu({
                         x: e.clientX,
                         y: e.clientY,
                         entityId: entity.id,
                         path: panePath,
                         entityName: entity.name,
                         isDirectory: isDir
                      });
                   }}
                   draggable={true}
                   onDragStart={(e) => {
                     e.dataTransfer.setData("application/bndz-file", JSON.stringify({
                        sourcePaneId: pane.id,
                        sourcePath: panePath,
                        entityId: entity.id
                     }));
                   }}
                 >
                    <div className="w-6 flex justify-center shrink-0">
                       {entity.iconBase64 ? <img src={entity.iconBase64} alt="" className="w-4 h-4 object-contain" /> : (isDir ? <Folder size={16} className="text-[#dcb67a]" /> : <File size={16} className="text-[#eee]" />)}
                    </div>
                    <div className="w-[45%] max-w-[300px] px-2 whitespace-nowrap overflow-hidden text-ellipsis shadow-none focus:outline-none">{entity.name}</div>
                    <div className="w-[15%] max-w-[120px] px-2 text-gray-400 whitespace-nowrap overflow-hidden text-ellipsis">
                      {entity.typeDescription || (isDir ? "File Folder" : `${(entity as any).extension || ''} File`)}
                    </div>
                    <div className="w-[15%] max-w-[100px] px-2 text-right text-gray-400">
                      {isDir ? "" : formatSize((entity as any).size)}
                    </div>
                    <div className="w-[25%] max-w-[160px] px-2 text-gray-400 whitespace-nowrap overflow-hidden text-ellipsis">
                      {new Date(entity.modified).toLocaleDateString()} {new Date(entity.modified).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                    </div>
                    <div className="flex-1 px-2 flex gap-1 h-full items-center">
                      {config.fileTaggingFeature !== false && entity.tags.map(t => (
                        <span key={t} className="bg-[#333] text-[9px] px-[4px] rounded-sm text-gray-300 border border-[#444] uppercase tracking-wide leading-none py-[2px]">{t}</span>
                      ))}
                    </div>
                 </div>
               );
             })
           )}
        </div>
      </div>
    );
  };

  const customStyles = config.applyColors ? {
    '--tree-bg': config.colorConfig2,
    '--tree-text': config.colorConfig1,
    '--tab-active-bg': config.colorConfig7,
    '--tab-active-text': config.colorConfig6,
    '--tab-inactive-bg': config.colorConfig9,
    '--tab-inactive-text': config.colorConfig8,
    '--list-bg': config.colorConfig11,
    '--list-text': config.colorConfig10,
    '--list-selected-bg': config.colorConfig14,
    '--breadcrumb-bg': config.colorConfig23,
    '--breadcrumb-text': config.colorConfig22,
  } as React.CSSProperties : {};

  return (
    <div style={customStyles} className="flex flex-col h-full w-full bg-[#1c1c1c] text-[#d4d4d4] font-sans text-[12px] select-none overflow-hidden">
      
      {/* Menu Bar */}
      {config.showTopMenubar !== false && (
      <div className="flex items-center px-2 py-1 bg-[#202020] text-[#ccc]">
         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">File</div>
             {config.enableContextSubmenus !== false && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => {
                        const selArgs = panes.find(p => p.id === activePaneId)?.tabs[panes.find(p => p.id === activePaneId)!.activeTabIndex]?.selectedItems[0];
                        if (selArgs) {
                           const cPath = panes.find(p => p.id === activePaneId)?.tabs[panes.find(p => p.id === activePaneId)!.activeTabIndex]?.path;
                           const entity = getDirContents(fileSystem, cPath || '')?.find(x => x.id === selArgs);
                           if (entity) import('../lib/ipcBridge').then(({ IPC }) => IPC.shellExecute('open', `${cPath}/${entity.name}`));
                        }
                    }}><FolderOpen size={14} /> Open Selected</div>
                    <div className="h-[1px] bg-[#444] my-1"></div>

                    <div className="relative group/sub1">
                        <div className="px-3 py-1 flex justify-between items-center hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">
                           <div className="flex items-center gap-2">Recent Files</div>
                           <ChevronRight size={14} className="ml-4 opacity-70" />
                        </div>
                        <div className="hidden group-hover/sub1:block absolute top-0 left-[100%] bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[160px] z-[110]">
                            <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-400 italic">(Empty)</div>
                        </div>
                    </div>

                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => {
                       const cPath = panes.find(p => p.id === activePaneId)?.tabs[panes.find(p => p.id === activePaneId)!.activeTabIndex]?.path;
                       import('../lib/ipcBridge').then(({ IPC }) => IPC.executeFsOperation(`new-folder-${Date.now()}`, 'create-dir', `${cPath}/New folder`, ''));
                    }}><Folder size={14} className="text-[#dcb67a]" /> New Folder</div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => {
                       const cPath = panes.find(p => p.id === activePaneId)?.tabs[panes.find(p => p.id === activePaneId)!.activeTabIndex]?.path;
                       import('../lib/ipcBridge').then(({ IPC }) => IPC.executeFsOperation(`new-file-${Date.now()}`, 'create-file', `${cPath}/New Text Document.txt`, ''));
                    }}><FileText size={14} className="text-[#eee]" /> New Text Document</div>

                    <div className="relative group/sub2">
                        <div className="px-3 py-1 flex justify-between items-center hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">
                           <div className="flex items-center gap-2">New (Other)</div>
                           <ChevronRight size={14} className="ml-4 opacity-70" />
                        </div>
                        <div className="hidden group-hover/sub2:block absolute top-0 left-[100%] bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[160px] z-[110]">
                            <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">ZIP Archive</div>
                            <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">Shortcut</div>
                        </div>
                    </div>

                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => {}}>
                       <Settings size={14} /> Properties
                    </div>
                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#e81123] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => {
                       // Optional: exit app via IPC if it existed
                    }}>
                       Exit
                    </div>
                 </div>
             )}
         </div>
         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">Edit</div>
             {config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => {
                        const selArgs = panes.find(p => p.id === activePaneId)?.tabs[panes.find(p => p.id === activePaneId)!.activeTabIndex]?.selectedItems[0];
                        if (selArgs) {
                           const cPath = panes.find(p => p.id === activePaneId)?.tabs[panes.find(p => p.id === activePaneId)!.activeTabIndex]?.path;
                           const entity = getDirContents(fileSystem, cPath || '')?.find(x => x.id === selArgs);
                           if (entity) import('../lib/ipcBridge').then(({ IPC }) => IPC.shellExecute('copyPath', `${cPath}/${entity.name}`));
                        }
                    }}><Copy size={14} /> Copy Path</div>

                    <div className="relative group/sub3">
                        <div className="px-3 py-1 flex justify-between items-center hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">
                           <div className="flex items-center gap-2">Copy To...</div>
                           <ChevronRight size={14} className="ml-4 opacity-70" />
                        </div>
                        <div className="hidden group-hover/sub3:block absolute top-0 left-[100%] bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[160px] z-[110]">
                            <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">Other Pane</div>
                            <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">Browse...</div>
                        </div>
                    </div>

                    <div className="relative group/sub4">
                        <div className="px-3 py-1 flex justify-between items-center hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">
                           <div className="flex items-center gap-2">Move To...</div>
                           <ChevronRight size={14} className="ml-4 opacity-70" />
                        </div>
                        <div className="hidden group-hover/sub4:block absolute top-0 left-[100%] bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[160px] z-[110]">
                            <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">Other Pane</div>
                            <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">Browse...</div>
                        </div>
                    </div>

                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => setIsSmartToolsOpen(true)}>
                       <Sparkles size={14} className="text-yellow-400" /> Smart Rename
                    </div>
                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#e81123] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => {
                        const selArgs = panes.find(p => p.id === activePaneId)?.tabs[panes.find(p => p.id === activePaneId)!.activeTabIndex]?.selectedItems[0];
                        if (selArgs) {
                           const cPath = panes.find(p => p.id === activePaneId)?.tabs[panes.find(p => p.id === activePaneId)!.activeTabIndex]?.path;
                           const entity = getDirContents(fileSystem, cPath || '')?.find(x => x.id === selArgs);
                           if (entity) import('../lib/ipcBridge').then(({ IPC }) => IPC.executeFsOperation(`del-${Date.now()}`, 'delete', `${cPath}/${entity.name}`, ''));
                        }
                    }}><Scissors size={14} /> Delete Selected</div>
                 </div>
             )}
         </div>
         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">View</div>
             {config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={toggleDualPane}>
                       <Columns size={14} /> {isDualPane ? 'Single Pane' : 'Dual Pane'}
                    </div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => setIsPreviewPanelOpen(p => !p)}>
                        <Eye size={14} /> {isPreviewPanelOpen ? 'Hide Preview Panel' : 'Show Preview Panel'}
                    </div>
                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2">
                       <RefreshCw size={14} /> Refresh
                    </div>
                 </div>
             )}
         </div>
         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">Go</div>
             {config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={goBack}>
                       <ArrowLeft size={14} /> Back
                    </div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={goForward}>
                       <ArrowRight size={14} /> Forward
                    </div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={goUp}>
                       <ArrowUp size={14} /> Up One Level
                    </div>
                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => setCurrentPath('/')}>
                       <Monitor size={14} /> This PC
                    </div>
                 </div>
             )}
         </div>
         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">Tools</div>
             {config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={() => setIsSmartToolsOpen(true)}>
                       <Sparkles size={14} className="text-yellow-400" /> AI Smart Workspace Tools
                    </div>
                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={onOpenConfig}>
                       <Settings size={14} /> Configuration
                    </div>
                 </div>
             )}
         </div>
         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">Favorites</div>
             {config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Added to favorites.")}>Toggle Favorite Folder</div>
                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="relative group/sub">
                        <div className="px-3 py-1 flex justify-between items-center hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">
                           <div className="flex items-center gap-2">Manage Favorites</div>
                           <ChevronRight size={14} className="ml-4 opacity-70" />
                        </div>
                        <div className="hidden group-hover/sub:block absolute top-0 left-[100%] bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[160px] z-[110]">
                            <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Opening favorites manager...")}>Organize Favorites...</div>
                        </div>
                    </div>
                 </div>
             )}
         </div>

         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">Tags</div>
             {config.fileTaggingFeature && config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Applied Red Tag.")}>Tag 1 (Red)</div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Applied Orange Tag.")}>Tag 2 (Orange)</div>
                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Opening tag manager...")}>Manage Tags...</div>
                 </div>
             )}
         </div>

         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">User</div>
             {config.userDefinedCommands && config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Executing Custom Command 1...")}>Custom Command 1</div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Executing Custom Command 2...")}>Custom Command 2</div>
                 </div>
             )}
         </div>

         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">Scripting</div>
             {config.scripting && config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Loading script file...")}>Load Script File...</div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Running script...")}>Run Script...</div>
                 </div>
             )}
         </div>

         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">Panes</div>
             {config.dualPaneFeature && config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={toggleDualPane}>Toggle Dual Pane</div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Swapped Panes.")}>Swap Panes</div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Synced Panes.")}>Sync Panes</div>
                 </div>
             )}
         </div>

         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">Tabsets</div>
             {config.tabsets && config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Saved Tabset.")}>Save Tabset As...</div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Loaded Tabset.")}>Load Tabset...</div>
                 </div>
             )}
         </div>

         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">Window</div>
             {config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Pinned Window.")}>Always on Top</div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Minimized to Tray.")}>Minimize to Tray</div>
                 </div>
             )}
         </div>

         <div className="relative group">
             <div className="px-2 py-[2px] hover:bg-[#333] cursor-pointer rounded-sm">Help</div>
             {config.enableContextSubmenus && (
                 <div className="hidden group-hover:block absolute top-[100%] left-0 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[110]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("Opening Help Topics...")}>Help Topics</div>
                    <div className="h-[1px] bg-[#444] my-1"></div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setToastMessage("You are on the latest version.")}>Check for Updates...</div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => import('../lib/ipcBridge').then(({ IPC }) => IPC.shellExecute('open', 'https://github.com'))}>About Applet</div>
                 </div>
             )}
         </div>
      </div>
      )}

      {/* Main Toolbar */}
      <div className="flex items-center px-1 py-1 bg-[#1a1a1a] border-b border-[#333] shrink-0">
         <ToolbarButton icon={ArrowLeft} color="#3b82f6" onClick={() => goBack()} />
         <ToolbarButton icon={ArrowRight} color="#3b82f6" onClick={() => goForward()} />
         <ToolbarButton icon={ArrowUp} color="#10b981" className="mr-2" onClick={goUp} title="Go Up One Level" />
         
         <div className="w-[1px] h-4 bg-[#444] mx-1"></div>
         
         <ToolbarButton icon={Monitor} color="#6db4e6" onClick={() => setCurrentPath('/')} title="This PC" />
         <ToolbarButton icon={FolderSearch} color="#dcb67a" />
         <ToolbarButton icon={File} color="#eee" className="mr-2" />

         <div className="w-[1px] h-4 bg-[#444] mx-1"></div>

         <ToolbarButton icon={Scissors} />
         <ToolbarButton icon={Copy} />
         <ToolbarButton icon={Clipboard} />
         <ToolbarButton icon={Folder} color="#eab308" className="mr-2" />

         <div className="w-[1px] h-4 bg-[#444] mx-1"></div>

         <ToolbarButton icon={Undo} color="#3b82f6" />
         <ToolbarButton icon={Redo} color="#3b82f6" className="mr-2" />

         <div className="w-[1px] h-4 bg-[#444] mx-1"></div>

         <ToolbarButton 
            icon={Sparkles} 
            color="#a855f7" 
            title="AI Smart Workspace Tools"
            onClick={() => setIsSmartToolsOpen(true)}
         />
         <ToolbarButton icon={Search} color="#3b82f6" />
         <ToolbarButton icon={RefreshCw} color="#10b981" className="mr-2" />

         <div className="w-[1px] h-4 bg-[#444] mx-1"></div>
         
         {/* Drive letters scoped to active pane */}
         <div className="flex text-[10px] items-center gap-[2px] mx-1 font-mono">
            <span className="bg-[#333] px-1 py-[1px] rounded border border-[#555] cursor-pointer hover:bg-[#444]" onClick={() => setCurrentPath('/C:')}>C:</span>
            <span className="bg-[#333] px-1 py-[1px] rounded border border-[#555] cursor-pointer hover:bg-[#444]" onClick={() => setCurrentPath('/D:')}>D:</span>
            <span className="bg-[#333] px-1 py-[1px] rounded border border-[#555]">E:</span>
            <span className="bg-[#333] px-1 py-[1px] rounded border border-[#555]">F:</span>
         </div>
         
         <div className="w-[1px] h-4 bg-[#444] mx-2"></div>
         
         {/* Dual Pane Toggle */}
         {config.dualPaneFeature !== false && (
            <ToolbarButton 
               icon={Columns} 
               color={isDualPane ? "#6db4e6" : "#666"} 
               className="ml-1" 
               title="Toggle Dual Pane View"
               onClick={toggleDualPane} 
            />
         )}
         
         <div className="flex-1"></div>
         
         {/* Right side tools */}
         <ToolbarButton 
            icon={PanelBottom } 
            color={isBottomPanelOpen ? "#6db4e6" : "#666"} 
            title="Toggle Bottom Plugin Panel"
            onClick={() => setIsBottomPanelOpen(prev => !prev)} 
         />
         <ToolbarButton 
            icon={Eye} 
            color={isPreviewPanelOpen ? "#6db4e6" : "#666"} 
            title="Toggle Right Side Preview Panel"
            onClick={() => setIsPreviewPanelOpen(prev => !prev)} 
         />
         <ToolbarButton icon={Settings} onClick={onOpenConfig} title="Configuration" />
         <ToolbarButton icon={Wrench} color="#3b82f6" title="Customize Toolbar" />
      </div>

      {/* Omni-Filter Bar */}
      <div className="flex bg-[#111] px-2 py-1 items-center border-b border-[#333] shrink-0">
         <Search size={14} className="text-gray-400 mr-2" />
         <input 
            ref={omniFilterRef}
            type="text"
            className="flex-1 bg-[#1a1a1a] text-white border border-[#444] rounded px-2 py-[2px] text-[12px] focus:outline-none focus:border-blue-500 transition-colors placeholder-[#666]"
            placeholder="Type '/' to instantly fuzzy-filter files in the active pane..."
            value={filterText}
            onChange={(e) => setFilterText(e.target.value)}
            onKeyDown={(e) => {
               if (e.key === 'Escape') {
                   setFilterText('');
                   omniFilterRef.current?.blur();
               }
            }}
         />
         {filterText && (
             <button onClick={() => setFilterText('')} className="ml-2 hover:bg-[#333] text-gray-400 hover:text-white px-2 py-[2px] rounded border border-transparent hover:border-[#555] transition-colors">
                <X size={14} />
             </button>
         )}
      </div>

      {/* Main Split Architecture */}
      <div className="flex flex-1 overflow-hidden min-h-0 relative">
         {/* Sidebar Tree */}
         <div className="w-[280px] shrink-0 border-r border-[#282830] bg-[#111111] overflow-y-auto py-2 no-scrollbar" style={config.applyColors ? { backgroundColor: 'var(--tree-bg)', color: 'var(--tree-text)' } : {}}>
                     {drives.length > 0 && (
                        <>
                           <div className="px-3 pb-1 pt-1 uppercase text-[#666] text-[10px] font-bold tracking-wider mb-1 border-b border-[#222]">Storage Units</div>
                           {drives.map(drive => {
                              const used = drive.totalSpace - drive.freeSpace;
                              const pct = (used / drive.totalSpace) * 100;
                              const formatBytesSpc = (bytes: number) => {
                                 const k = 1024, sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
                                 if (bytes === 0) return '0 B';
                                 const i = Math.floor(Math.log(bytes) / Math.log(k));
                                 return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
                              };
                              return (
                                 <div 
                                    key={drive.name} 
                                    className="px-3 py-2 cursor-pointer hover:bg-[#202020] group border-l-2 border-transparent hover:border-[#3b82f6] transition-all"
                                    onClick={() => setCurrentPath(drive.name)}
                                    onContextMenu={(e) => {
                                       if (config.useNativeOSContextMenu !== false) {
                                           e.preventDefault();
                                           import('../lib/ipcBridge').then(({ IPC }) => { IPC.showNativeContextMenu(drive.name, e.screenX, e.screenY); });
                                       }
                                    }}
                                 >
                                    <div className="flex items-center gap-2 mb-1.5 text-[#ccc] group-hover:text-white">
                                       <HardDrive size={14} className={drive.name.includes('C:') ? 'text-sky-400' : 'text-gray-400 group-hover:text-[#dcb67a]'} />
                                       <span className="text-[11px] font-medium truncate">{drive.label} <span className="text-[#666] font-normal">({drive.name.replace(/^\//,'')})</span></span>
                                    </div>
                                    <div className="w-full bg-[#2a2a2a] h-[4px] rounded-full overflow-hidden mb-1.5 shadow-inner">
                                       <div className={`h-full opacity-90 ${pct > 90 ? 'bg-red-500' : 'bg-sky-500'}`} style={{width: `${pct}%`}}></div>
                                    </div>
                                    <div className="flex justify-between text-[9px] text-[#777] font-mono tracking-tighter">
                                       <span><strong className="text-[#aaa] font-medium">{formatBytesSpc(drive.freeSpace)}</strong> free</span>
                                       <span>{formatBytesSpc(drive.totalSpace)}</span>
                                    </div>
                                 </div>
                              );
                           })}
                        </>
                     )}

                     {shortcuts.length > 0 && (
                        <>
                           <div className="px-3 pb-1 pt-4 uppercase text-[#666] text-[10px] font-bold tracking-wider mb-1 border-b border-[#222]">Quick Access</div>
                           {shortcuts.map(s => {
                              const getIcon = (ic: string) => {
                                 if (ic === 'desktop') return <Monitor size={14} className="text-emerald-400" />
                                 if (ic === 'documents') return <File size={14} className="text-amber-400" />
                                 if (ic === 'downloads') return <ArrowDownCircle size={14} className="text-sky-400" />
                                 return <Folder size={14} className="text-purple-400" />
                              };

                              return (
                                 <div 
                                    key={s.path}
                                    className="flex items-center gap-2.5 px-3 py-1.5 cursor-pointer hover:bg-[#202020] text-[#ccc] hover:text-white border-l-2 border-transparent hover:border-[#3b82f6] transition-all"
                                    onClick={() => setCurrentPath(s.path)}
                                    onContextMenu={(e) => {
                                       if (config.useNativeOSContextMenu !== false) {
                                           e.preventDefault();
                                           import('../lib/ipcBridge').then(({ IPC }) => { IPC.showNativeContextMenu(s.path, e.screenX, e.screenY); });
                                       }
                                    }}
                                 >
                                    {getIcon(s.icon)}
                                    <span className="text-[11px] font-medium">{s.name}</span>
                                 </div>
                              );
                           })}
                        </>
                     )}

                     <div className="px-3 pb-1 pt-4 uppercase text-[#666] text-[10px] font-bold tracking-wider mb-1 border-b border-[#222]">Navigation Tree</div>
                     <div className="px-1">
                        {treeData.map((item, i) => <TreeItem key={i} {...item} config={config} currentPath={currentPath} onClick={(p: string) => p ? setCurrentPath(p) : item.onClick?.()} />)}
                     </div>
                  </div>
         {/* Multi-Pane Content Area */}
         <div className="flex-1 flex flex-col overflow-hidden bg-[#202020] relative">
            <div className="flex flex-1 overflow-hidden min-h-0">
                  {renderPane(panes[0], 0)}
                  
                  {config.dualPaneFeature !== false && isDualPane && panes[1] && (
                     <>
                        <div className="w-1 bg-[#282830] cursor-col-resize shrink-0 shadow-[inset_0_0_2px_rgba(0,0,0,0.5)] z-20"></div>
                        {renderPane(panes[1], 1)}
                     </>
                  )}
            </div>
            
            <AnimatePresence>
               {isBottomPanelOpen && (
                  <motion.div 
                     initial={{ y: "100%", opacity: 0 }}
                     animate={{ y: 0, opacity: 1 }}
                     exit={{ y: "100%", opacity: 0 }}
                     transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                     className="absolute bottom-0 left-0 right-0 h-[250px] shrink-0 border-t border-[#282830] flex min-h-0 z-30 shadow-[0_-10px_30px_rgba(0,0,0,0.5)]"
                  >
                     <BottomPluginPanel entity={focusedItemId ? getEntityByPath(fileSystem, focusedItemId) : null} config={config} drives={drives} focusedPath={focusedItemId || currentPath} />
                  </motion.div>
               )}
            </AnimatePresence>
         </div>

         <AnimatePresence>
            {isPreviewPanelOpen && config.rightSidebarEnabled !== false && (
               <motion.div 
                  initial={{ width: 0, opacity: 0 }}
                  animate={{ width: 300, opacity: 1 }}
                  exit={{ width: 0, opacity: 0 }}
                  transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                  className="shrink-0 border-l border-[#282830] bg-[#111111] overflow-hidden z-10 flex min-h-0"
               >
                  <div className="w-[300px] h-full flex flex-col min-w-[300px]">
                     <RightPreviewPanel 
                        entity={focusedItemId ? getEntityByPath(fileSystem, focusedItemId) : null} 
                     />
                  </div>
               </motion.div>
            )}
         </AnimatePresence>
      </div>

      {/* Footer Status Bar scoped to active pane metrics */}
      <div className="bg-[#1f1f1f] border-t border-[#444] px-2 py-1 flex items-center justify-between text-[11px] text-gray-400 shrink-0">
         <div>
           {activeContents ? `${activeContents.length} item(s)` : `2 drives`} 
           {activeTab.selectedItems.length > 0 ? ` | ${activeTab.selectedItems.length} selected` : ''}
         </div>
         <div className="flex items-center gap-4">
            <div>total free: 38.12 GB (2%) &nbsp; capacity: 2.04 TB</div>
            <div className="flex items-center">
               <Monitor size={12} className="text-[#6db4e6] mr-1" />
               <span className="bg-[#1c1c1c] border border-[#333] px-2 py-[2px] rounded-sm">total used: 2.00 TB free: 38.12 GB (2%)</span>
            </div>
         </div>
      </div>
      
      {/* Overlays / Modals */}
      {isSmartToolsOpen && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <SmartToolsDialog 
            selectedFiles={activeFilesMap}
            onApplyRename={handleApplyRename}
            onClose={() => setIsSmartToolsOpen(false)} 
          />
        </div>
      )}

      {/* Global Progress Bars */}
      {Object.keys(transferProgress).length > 0 && (
         <div className="absolute bottom-10 right-10 w-[420px] flex flex-col gap-3 z-50">
            {Object.keys(transferProgress).map((opId) => {
               const prog = transferProgress[opId];
               const formatBytes = (bytes: number) => {
                 if (bytes === 0) return '0 B';
                 const k = 1024, sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
                 const i = Math.floor(Math.log(bytes) / Math.log(k));
                 return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
               };
               return (
               <div key={opId} className="bg-[#1a1a1a] border border-[#3e3e42] shadow-2xl rounded p-4 flex flex-col items-stretch">
                 <div className="flex justify-between items-center mb-2">
                   <div className="flex items-center gap-3">
                     {prog.percentage < 100 ? (
                        <div className="scale-[0.5] -ml-2 -my-4"><Spinner /></div>
                     ) : (
                        <div className="text-green-500 scale-[0.8]"><Sparkles size={24} /></div>
                     )}
                     <div className="text-[13px] text-white font-medium truncate max-w-[200px]">
                        {prog.percentage < 100 ? `Copying ${prog.itemsCompleted} of ${prog.totalItems} items` : `Completed`}
                     </div>
                   </div>
                   <div className="text-[12px] text-gray-400">{Math.round(prog.percentage)}%</div>
                 </div>
                 <div className="text-[11px] text-gray-400 mb-3 truncate pl-2" title={prog.file}>
                   {prog.file}
                 </div>
                 <div className="w-full bg-[#1e1e1e] h-2 rounded-full overflow-hidden mb-3 border border-[#333]">
                   <div 
                     className={`h-full transition-all duration-300 ease-out ${prog.percentage >= 100 ? 'bg-green-500' : 'bg-[#007acc]'}`}
                     style={{ width: `${prog.percentage}%` }}
                   ></div>
                 </div>
                 <div className="flex justify-between items-center text-[11px] text-gray-400">
                   <div>
                     {prog.percentage < 100 ? `${formatBytes(prog.speedBytesPerSecond)}/s` : ''}
                   </div>
                   <div>
                     {formatBytes(prog.bytesTransferred)} / {formatBytes(prog.totalBytes)}
                   </div>
                 </div>
               </div>
               );
            })}
         </div>
      )}

      {/* Conflict Resolution Dialog */}
      {conflict && (
         <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
           <div className="bg-[#1e1e1e] border border-[#333] shadow-2xl rounded-md w-96 p-4">
             <div className="flex items-center gap-3 mb-4">
               <AlertTriangle className="text-yellow-500" size={24} />
               <h3 className="text-white font-semibold flex-1">File Conflict Detected</h3>
               <X className="text-gray-400 cursor-pointer" size={16} onClick={() => {
                  import('../lib/ipcBridge').then(({ IPC }) => IPC.resolveConflict(conflict.opId, conflict.fileName, 'skip'));
                  setConflict(null);
               }} />
             </div>
             
             <p className="text-sm text-gray-300 mb-6 leading-relaxed">
               The destination already contains a file named <strong className="text-white">{conflict.fileName}</strong>. What would you like to do?
             </p>
             
             <div className="flex flex-col gap-2">
               <button 
                 className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded text-sm transition-colors text-left px-4"
                 onClick={() => {
                   import('../lib/ipcBridge').then(({ IPC }) => IPC.resolveConflict(conflict.opId, conflict.fileName, 'replace'));
                   setConflict(null);
                 }}
               >
                 <strong>Replace</strong> the file in the destination
               </button>
               <button 
                 className="w-full bg-[#2a2d2e] hover:bg-[#333] border border-[#444] text-white py-2 rounded text-sm transition-colors text-left px-4"
                 onClick={() => {
                   import('../lib/ipcBridge').then(({ IPC }) => IPC.resolveConflict(conflict.opId, conflict.fileName, 'skip'));
                   setConflict(null);
                 }}
               >
                 <strong>Skip</strong> this file
               </button>
               <button 
                 className="w-full bg-[#2a2d2e] hover:bg-[#333] border border-[#444] text-white py-2 rounded text-sm transition-colors text-left px-4"
                 onClick={() => {
                   import('../lib/ipcBridge').then(({ IPC }) => IPC.resolveConflict(conflict.opId, conflict.fileName, 'keepboth'));
                   setConflict(null);
                 }}
               >
                 <strong>Keep both</strong> (rename the copied file)
               </button>
             </div>
           </div>
         </div>
      )}

      {/* Custom Context Menu */}
      {contextMenu && (
        <div 
          className="fixed z-[100] bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px]"
          style={{ top: contextMenu.y, left: contextMenu.x }}
          onClick={(e) => e.stopPropagation()} // Prevent closing immediately when clicking inside
        >
          {contextMenu.entityId === null ? (
            // Empty Space Context Menu
            <>
              <div className="px-3 py-1 flex items-center gap-2 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => {
                 setContextMenu(null);
              }}>
                 <RefreshCw size={14} /> Refresh
              </div>
              <div className="relative group">
                 <div className="px-3 py-1 flex justify-between items-center hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">
                    <div className="flex items-center gap-2">Sort By</div>
                    {config.enableContextSubmenus && <ChevronRight size={14} className="ml-4 opacity-70" />}
                 </div>
                 {config.enableContextSubmenus && (
                     <div className="hidden group-hover:block absolute top-0 left-full ml-1 bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[160px] z-[120]">
                         <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={(e) => { e.stopPropagation(); setContextMenu(null); }}>Name</div>
                         <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={(e) => { e.stopPropagation(); setContextMenu(null); }}>Date Modified</div>
                         <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={(e) => { e.stopPropagation(); setContextMenu(null); }}>Type</div>
                         <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={(e) => { e.stopPropagation(); setContextMenu(null); }}>Size</div>
                     </div>
                 )}
              </div>
              <div className="h-[1px] bg-[#444] my-1"></div>
              <div className="relative group">
                 <div className="px-3 py-1 flex justify-between items-center hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">
                    <div className="flex items-center gap-2">New</div>
                    {config.enableContextSubmenus && <ChevronRight size={14} className="ml-4 opacity-70" />}
                 </div>
                 {config.enableContextSubmenus && (
                     <div className="hidden group-hover:block absolute top-0 left-[98%] bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[160px] z-[120]">
                         <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={(e) => { 
                             e.stopPropagation(); 
                             import('../lib/ipcBridge').then(({ IPC }) => IPC.executeFsOperation(`new-folder-${Date.now()}`, 'create-dir', `${contextMenu.path}/New folder`, ''));
                             setContextMenu(null); 
                         }}><Folder size={14} className="text-[#dcb67a]" /> Folder</div>
                         <div className="h-[1px] bg-[#444] my-1"></div>
                         <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={(e) => { 
                             e.stopPropagation(); 
                             import('../lib/ipcBridge').then(({ IPC }) => IPC.executeFsOperation(`new-file-${Date.now()}`, 'create-file', `${contextMenu.path}/New Text Document.txt`, ''));
                             setContextMenu(null); 
                         }}><FileText size={14} className="text-[#eee]" /> Text Document</div>
                         <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 flex items-center gap-2" onClick={(e) => { e.stopPropagation(); setContextMenu(null); }}><File size={14} className="text-gray-400" /> Empty File</div>
                     </div>
                 )}
              </div>
              <div className="h-[1px] bg-[#444] my-1"></div>
              <div className="px-3 py-1 flex items-center gap-2 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setContextMenu(null)}>
                 <Settings size={14} /> Properties
              </div>
            </>
          ) : (
            // Entity Context Menu (File/Folder)
            <>
              {contextMenu.isDirectory ? (
                <>
                  <div className="px-3 py-1 flex items-center gap-2 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 font-bold" onClick={() => {
                     import('../lib/ipcBridge').then(({ IPC }) => IPC.shellExecute('open', `${contextMenu.path}/${contextMenu.entityName}`));
                     setContextMenu(null);
                  }}>
                     <FolderOpen size={14} /> Open
                  </div>
                  <div className="px-3 py-1 flex items-center gap-2 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => {
                     setContextMenu(null);
                     // Note: You can implement an addTab logic here
                  }}>
                     Open in New Tab
                  </div>
                </>
              ) : (
                <>
                  <div className="px-3 py-1 flex items-center gap-2 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200 font-bold" onClick={() => {
                     import('../lib/ipcBridge').then(({ IPC }) => IPC.shellExecute('open', `${contextMenu.path}/${contextMenu.entityName}`));
                     setContextMenu(null);
                  }}>
                     Open
                  </div>
                  <div className="relative group">
                     <div className="px-3 py-1 flex justify-between items-center hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => {
                         if (!config.enableContextSubmenus) {
                            import('../lib/ipcBridge').then(({ IPC }) => IPC.shellExecute('openWith', `${contextMenu.path}/${contextMenu.entityName}`));
                            setContextMenu(null);
                         }
                     }}>
                        <div className="flex items-center gap-2"><PlayCircle size={14} /> Open With</div>
                        {config.enableContextSubmenus && <ChevronRight size={14} className="ml-4 opacity-70" />}
                     </div>
                     {config.enableContextSubmenus && (
                         <div className="hidden group-hover:block absolute top-0 left-[98%] bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[160px] z-[120]">
                             <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={(e) => { e.stopPropagation(); import('../lib/ipcBridge').then(({ IPC }) => IPC.shellExecute('openWith', `${contextMenu.path}/${contextMenu.entityName}`)); setContextMenu(null); }}>Choose Default App...</div>
                             <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={(e) => { e.stopPropagation(); setContextMenu(null); }}>Notepad</div>
                             <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={(e) => { e.stopPropagation(); setContextMenu(null); }}>Visual Studio Code</div>
                         </div>
                     )}
                  </div>
                </>
              )}
              <div className="h-[1px] bg-[#444] my-1"></div>
              
              <div className="relative group">
                 <div className="px-3 py-1 flex justify-between items-center hover:bg-[#007acc] cursor-pointer text-sm text-gray-200">
                    <div className="flex items-center gap-2"><Monitor size={14} /> Open in...</div>
                    <ChevronRight size={14} className="ml-4 opacity-70" />
                 </div>
                 <div className="hidden group-hover:block absolute top-[10%] left-[98%] bg-[#1f1f1f] border border-[#444] shadow-xl rounded-md py-1 min-w-[200px] z-[120]">
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={(e) => {
                       import('../lib/ipcBridge').then(({ IPC }) => IPC.shellExecute('openTerminal', `${contextMenu.path}/${contextMenu.entityName}`));
                       setContextMenu(null);
                    }}>
                       Open in Terminal
                    </div>
                    <div className="px-3 py-1 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={(e) => {
                       import('../lib/ipcBridge').then(({ IPC }) => IPC.shellExecute('openExplorer', `${contextMenu.path}/${contextMenu.entityName}`));
                       setContextMenu(null);
                    }}>
                       Show in Explorer
                    </div>
                 </div>
              </div>

              <div className="h-[1px] bg-[#444] my-1"></div>
              
              <div className="px-3 py-1 flex items-center gap-2 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => {
                 import('../lib/ipcBridge').then(({ IPC }) => IPC.shellExecute('compress', `${contextMenu.path}/${contextMenu.entityName}`));
                 setContextMenu(null);
              }}>
                 <Archive size={14} /> Compress to Zip
              </div>
              <div className="px-3 py-1 flex items-center gap-2 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => {
                 import('../lib/ipcBridge').then(({ IPC }) => IPC.shellExecute('copyPath', `${contextMenu.path}/${contextMenu.entityName}`));
                 setContextMenu(null);
              }}>
                 <Clipboard size={14} /> Copy Path
              </div>
              <div className="px-3 py-1 flex items-center gap-2 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => {
                 setIsSmartToolsOpen(true);
                 setContextMenu(null);
              }}>
                 <Sparkles size={14} className="text-yellow-400" /> Smart Rename
              </div>
              <div className="h-[1px] bg-[#444] my-1"></div>
              <div className="px-3 py-1 flex items-center gap-2 hover:bg-[#e81123] cursor-pointer text-sm text-gray-200" onClick={() => {
                 import('../lib/ipcBridge').then(({ IPC }) => IPC.executeFsOperation(`del-${Date.now()}`, 'delete', `${contextMenu.path}/${contextMenu.entityName}`, ''));
                 setContextMenu(null);
              }}>
                 <Scissors size={14} /> Delete
              </div>
              <div className="px-3 py-1 flex items-center gap-2 hover:bg-[#007acc] cursor-pointer text-sm text-gray-200" onClick={() => setContextMenu(null)}>
                 <Settings size={14} /> Properties
              </div>
            </>
          )}
        </div>
      )}

      {toastMessage && <Toast message={toastMessage} onClose={() => setToastMessage(null)} />}
    </div>
  );
}
