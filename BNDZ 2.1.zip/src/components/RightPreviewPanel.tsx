import React, { useState, useEffect } from 'react';
import { useAppConfig } from '../data/configContext';
import { FSEntity } from '../types';
import { File, Folder, Image, Music, FileText, Code, Settings, PlayCircle, ShieldUser, KeyRound, HardDrive } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface RightPreviewPanelProps {
  entity: FSEntity | null;
}

export default function RightPreviewPanel({ entity }: RightPreviewPanelProps) {
  const { config } = useAppConfig();
  const [thumbnailNative, setThumbnailNative] = useState<string | null>(null);

  // C# Wiring: hydrate high-resolution thumbnail based on focused entity
  useEffect(() => {
     if (entity && config.highResNativeWindowsThumbnails !== false) {
        setThumbnailNative(null);
        let active = true;
        import('../lib/ipcBridge').then(({ IPC }) => {
           IPC.getNativeThumbnailBase64(entity.path || '').then(base64 => {
               if (active && base64) {
                  setThumbnailNative(base64);
               }
           });
        });
        return () => { active = false; };
     } else {
        setThumbnailNative(null);
     }
  }, [entity?.id, config.highResNativeWindowsThumbnails]);
  
  if (!entity) {
    return (
      <div className="w-full h-full border-l border-[#282830] bg-[#111111] flex flex-col items-center justify-center text-[#666] p-4 shrink-0 shadow-[-4px_0_15px_rgba(0,0,0,0.2)] z-10 select-none">
        <File size={48} className="mb-4 opacity-20" />
        <span className="text-[13px]">Select a file to preview</span>
      </div>
    );
  }

  const isDir = entity.type === 'directory';
  const ext = !isDir ? (entity as any).extension?.toLowerCase() || '' : '';
  const isImage = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'].includes(ext);
  const isAudio = ['mp3', 'wav', 'ogg', 'flac'].includes(ext);
  const isVideo = ['mp4', 'mkv', 'avi', 'mov'].includes(ext);
  const isTextRaw = ['txt', 'md', 'log', 'csv'].includes(ext);
  const isCode = ['js', 'ts', 'jsx', 'tsx', 'cs', 'json', 'html', 'css', 'xml'].includes(ext);

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024, sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getPreviewIcon = () => {
     if (isDir) return <Folder size={80} className="text-[#dcb67a]" />;
     if (isImage) return <Image size={80} className="text-purple-400" />;
     if (isAudio) return <Music size={80} className="text-sky-400" />;
     if (isCode) return <Code size={80} className="text-emerald-400" />;
     if (isTextRaw) return <FileText size={80} className="text-amber-400" />;
     return <File size={80} className="text-gray-400" />;
  };

  const showThumb = config.previewAsThumbnail;
  const zoom = config.selectConfig || "100%";
  const animDuration = config.richTransitionAnimations !== false ? 0.15 : 0;

  return (
    <div className="w-full h-full border-l border-[#282830] bg-[#151515] flex flex-col shrink-0 shadow-[-4px_0_15px_rgba(0,0,0,0.2)] z-10 overflow-hidden text-[#e0e0e0]">
       {/* Toolbar / Header */}
       <div className="bg-[#1e1e1e] border-b border-[#333] px-2 py-1.5 flex justify-between items-center z-10 shrink-0 select-none">
          <span className="text-[11px] font-bold text-gray-300 uppercase tracking-wider">Preview Details</span>
          <div className="flex gap-1">
             <div className="p-1 hover:bg-[#333] rounded cursor-pointer"><Settings size={12} className="text-gray-400" /></div>
          </div>
       </div>
       
       <div className="flex-1 overflow-y-auto no-scrollbar relative flex flex-col styled-scrollbar bg-[#111]">
          <AnimatePresence mode="wait">
             <motion.div 
                key={entity.id}
                initial={{ opacity: 0, y: animDuration > 0 ? 10 : 0 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: animDuration > 0 ? -10 : 0 }}
                transition={{ duration: animDuration, ease: "easeOut" }}
                className="flex flex-col flex-1"
             >
                {/* Visual Thumbnail Area */}
                <div className={`w-full h-[240px] bg-[#080808] border-b border-[#222] flex items-center justify-center p-4 relative shrink-0 ${showThumb ? 'pattern-checkerboard' : ''}`}>
                    <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-10 pointer-events-none"></div>
                    
                    <div className={`transition-transform duration-300 ${zoom === "Fit to width" ? "scale-[1.2]" : zoom === "Fit to window" ? "w-full h-full p-2" : "scale-100"}`}>
                        {thumbnailNative ? (
                           thumbnailNative === 'mocked_base64_ready' ? (
                               <div className="flex flex-col items-center drop-shadow-2xl">
                                   {getPreviewIcon()}
                               </div>
                           ) : (
                               <img src={`data:image/png;base64,${thumbnailNative}`} className="max-w-[200px] max-h-[200px] object-contain drop-shadow-2xl" alt="Preview Thumbnail" />
                           )
                        ) : (
                           <div className="animate-pulse">
                              <div className="w-[80px] h-[80px] bg-[#222] rounded-lg"></div>
                           </div>
                        )}
                    </div>
                    
                    <div className="absolute bottom-2 right-2 flex gap-1 shadow-md">
                       {isDir ? (
                          <span className="bg-black/90 text-[#dcb67a] text-[9px] px-2 py-0.5 rounded-[2px] uppercase font-bold border border-[#dcb67a]/40 shadow-inner tracking-wider">DIR</span>
                       ) : ext && (
                          <span className="bg-black/90 text-white text-[9px] px-2 py-0.5 rounded-[2px] uppercase font-bold border border-white/20 shadow-inner tracking-wider">{ext}</span>
                       )}
                    </div>
                </div>

                {/* Dense Metadata Panel */}
                <div className="p-4 flex-1 bg-[#111] flex flex-col gap-4">
                    {/* Primary Identifier */}
                    <div className="pb-3 border-b border-[#282830]">
                       <h2 className="text-[14px] font-bold text-white break-words leading-tight">{entity.name}</h2>
                       <div className="text-[11px] text-gray-500 mt-1 uppercase tracking-widest font-mono">
                          {isDir ? 'File Folder' : `${ext.toUpperCase()} File`}
                       </div>
                    </div>

                    {/* Quick Stats Grid */}
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid grid-cols-[80px_1fr] gap-y-2 text-[11px] font-mono leading-relaxed">
                       <div className="text-gray-500 flex items-center gap-1"><HardDrive size={10} /> {isDir ? 'Size on disk:' : 'Size:'}</div>
                       <div className="text-sky-300">
                          {isDir ? '-- (Calculate in BG)' : ((entity as any).size != null ? formatSize((entity as any).size) : '--')}
                       </div>
                       {isDir && (
                          <>
                             <div className="text-gray-500">Contents:</div>
                             <div className="text-gray-300">-- Files, -- Folders</div>
                          </>
                       )}

                       <div className="text-gray-500">Created:</div>
                       <div className="text-gray-300">{(entity as any).created ? new Date((entity as any).created).toLocaleString() : '--'}</div>

                       <div className="text-gray-500">Modified:</div>
                       <div className="text-gray-300">{new Date(entity.modified).toLocaleString()}</div>
                    </motion.div>

                    {/* Security & Access Box */}
                    <div className="mt-2 border border-[#282830] bg-[#151515] rounded-[4px] p-3 shadow-inner">
                       <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-widest font-bold text-gray-400 mb-2">
                          <ShieldUser size={12} className="text-emerald-400" /> Access Properties
                       </div>
                       
                       <div className="grid grid-cols-[80px_1fr] gap-y-1.5 text-[11px] font-mono">
                          <div className="text-gray-500">Owner:</div>
                          <div className="text-gray-300 flex items-center">BUILTIN\\Administrators</div>
                          
                          <div className="text-gray-500 flex items-center gap-1"><KeyRound size={10} /> ACL:</div>
                          <div className="text-gray-300">Full Control</div>
                       </div>
                       
                       <div className="mt-3 pt-3 border-t border-[#282830] flex gap-4">
                          <label className="flex items-center gap-1.5 cursor-not-allowed">
                             <input type="checkbox" className="accent-sky-500 bg-[#222] border-[#444] rounded-sm" readOnly checked={(entity as any).readOnly !== false} /> 
                             <span className="text-[11px] text-gray-300">Read-only</span>
                          </label>
                          <label className="flex items-center gap-1.5 cursor-not-allowed">
                             <input type="checkbox" className="accent-sky-500 bg-[#222] border-[#444] rounded-sm" readOnly checked={(entity as any).hidden === true} /> 
                             <span className="text-[11px] text-gray-300">Hidden</span>
                          </label>
                       </div>
                    </div>
                </div>
             </motion.div>
          </AnimatePresence>
       </div>
    </div>
  );
}
