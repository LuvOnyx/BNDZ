import React, { useState, Suspense } from 'react';
import { Settings, Search, Filter, Database, Check, X, Plus, Puzzle } from 'lucide-react';
import { FSEntity } from '../types';
import { usePluginRegistry } from '../data/PluginRegistryContext';

// Lazy loaded plugins
const PropertiesPlugin = React.lazy(() => import('./plugins/PropertiesPlugin'));
const FindPlugin = React.lazy(() => import('./plugins/FindPlugin'));
const FiltersPlugin = React.lazy(() => import('./plugins/FiltersPlugin'));
const MetadataPlugin = React.lazy(() => import('./plugins/MetadataPlugin'));

export default function BottomPluginPanel({ entity, config, drives = [], focusedPath = "" }: { entity: FSEntity | null, config: any, drives?: any[], focusedPath?: string }) {
   const { installedPlugins, togglePluginInstall } = usePluginRegistry();

   const allPlugins = [
      { id: 'properties', name: 'Properties', icon: Settings, component: PropertiesPlugin },
      { id: 'find', name: 'Find', icon: Search, component: FindPlugin },
      { id: 'filters', name: 'Filters', icon: Filter, component: FiltersPlugin },
      { id: 'metadata', name: 'Metadata', icon: Database, component: MetadataPlugin },
   ];

   const [activeTab, setActiveTab] = useState('properties');
   const [isConfiguring, setIsConfiguring] = useState(false);

   // Render active plugin content
   const renderPluginContent = () => {
      const plugin = allPlugins.find(p => p.id === activeTab);
      if (!plugin) return null;

      // Ensure we only show content if it's installed
      if (!installedPlugins.includes(activeTab)) {
         return (
            <div className="flex-1 flex flex-col items-center justify-center text-[#555] font-sans text-[13px] bg-[#181818] border border-[#333] rounded-[4px] shadow-inner relative">
               <div className="w-[80px] h-[80px] border border-[#333] rounded-full flex items-center justify-center mb-4 bg-[#111]">
                  <Puzzle size={24} className="text-[#444]" />
               </div>
               <span className="text-gray-400 font-bold tracking-tight mb-1 text-[16px]">Module "{plugin.name}" Offline</span>
               <span className="text-[12px] text-[#555]">This plugin module is unloaded in the store.</span>
            </div>
         );
      }

      const PluginComponent = plugin.component;
      return (
         <Suspense fallback={<div className="flex-1 p-4 flex items-center justify-center text-gray-500 text-xs">Loading {plugin.name}...</div>}>
            <PluginComponent entity={entity} config={config} drives={drives} focusedPath={focusedPath} />
         </Suspense>
      );
   };

   return (
      <div className="w-full h-full bg-[#151515] flex flex-col border-t border-[#333] shadow-[0_-4px_15px_rgba(0,0,0,0.2)] text-[#e0e0e0] select-none rounded-t-lg">
         {/* Tabs */}
         <div className="flex bg-[#1a1a1a] border-b border-[#333] justify-between items-center pr-2 shrink-0 h-[32px]">
            <div className="flex h-full overflow-x-auto no-scrollbar styled-scrollbar">
               {allPlugins.filter(p => installedPlugins.includes(p.id)).map((tab) => (
                  <div 
                     key={tab.id}
                     className={`flex items-center gap-2 px-4 h-full text-[12px] cursor-pointer border-t-[3px] transition-colors group relative ${
                        activeTab === tab.id 
                           ? 'border-t-sky-500 bg-[#151515] text-white' 
                           : 'border-t-transparent text-gray-400 hover:text-white hover:bg-[#222]'
                     }`}
                     onClick={() => setActiveTab(tab.id)}
                  >
                     <tab.icon size={12} />
                     <span>{tab.name}</span>
                     {isConfiguring && (
                        <div 
                           className="ml-2 w-[14px] h-[14px] flex items-center justify-center rounded-sm hover:bg-red-500/20 hover:text-red-400 text-gray-500"
                           onClick={(e) => { 
                              e.stopPropagation(); 
                              togglePluginInstall(tab.id); 
                              if (activeTab === tab.id) {
                                  const next = installedPlugins.filter(p => p !== tab.id);
                                  if (next.length > 0) setActiveTab(next[0]);
                              }
                           }}
                        >
                           <X size={10} />
                        </div>
                     )}
                  </div>
               ))}
               {installedPlugins.length === 0 && (
                  <div className="px-4 py-1.5 text-[12px] text-gray-500 italic">No plugins installed</div>
               )}
            </div>
            
            <div className="flex gap-2 shrink-0">
               <button 
                  className={`flex items-center gap-1.5 px-2 py-0.5 text-[11px] rounded-sm transition-colors border ${isConfiguring ? 'bg-sky-500/20 text-sky-400 border-sky-500/50' : 'bg-[#222] text-gray-400 border-[#333] hover:text-white hover:bg-[#333]'}`}
                  onClick={() => setIsConfiguring(!isConfiguring)}
               >
                  <Plus size={12} /> Plugin Store
               </button>
            </div>
         </div>

         {/* Configuration Panel - Plugin Store Modal */}
         {isConfiguring && (
            <div className="bg-[#111] p-3 border-b border-[#333] shrink-0 relative">
               <div className="absolute right-3 top-3 cursor-pointer text-gray-500 hover:text-white" onClick={() => setIsConfiguring(false)}>
                  <X size={16} />
               </div>
               <div className="text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-2">Plugin Store - Available Modules</div>
               <div className="flex flex-wrap gap-2">
                  {allPlugins.map(plugin => {
                     const isInstalled = installedPlugins.includes(plugin.id);
                     return (
                        <div 
                           key={plugin.id}
                           className={`flex items-center gap-2 px-3 py-1.5 text-[12px] rounded-[4px] cursor-pointer border transition-colors ${ isInstalled ? 'bg-sky-900/30 border-sky-500 text-sky-300' : 'bg-[#222] border-[#444] text-gray-300 hover:bg-[#333]' }`}
                           onClick={() => {
                              togglePluginInstall(plugin.id);
                              if (isInstalled && activeTab === plugin.id) {
                                  const next = installedPlugins.filter(p => p !== plugin.id);
                                  if (next.length > 0) setActiveTab(next[0]);
                              }
                           }}
                        >
                           <plugin.icon size={12} />
                           {plugin.name}
                           {isInstalled ? <Check size={12} className="ml-1" /> : <Plus size={12} className="ml-1 opacity-50" />}
                        </div>
                     )
                  })}
               </div>
            </div>
         )}
         
         {/* Content */}
         <div className="flex-1 overflow-y-auto p-0 flex gap-6 min-h-0 bg-[#111] styled-scrollbar">
            {renderPluginContent()}
         </div>
      </div>
   );
}
