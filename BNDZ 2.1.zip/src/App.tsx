/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import BNDZUI from './components/BNDZUI';
import ConfigurationDialog from './components/ConfigurationDialog';
import { ConfigProvider } from './data/configContext';
import { PluginRegistryProvider } from './data/PluginRegistryContext';

export default function App() {
  const [configOpen, setConfigOpen] = useState(false);

  return (
    <ConfigProvider>
      <PluginRegistryProvider>
        <div className="absolute inset-0 overflow-hidden bg-[#1e1e1e] text-[#e0e0e0]">
          <BNDZUI onOpenConfig={() => setConfigOpen(true)} />
          {configOpen && (
             <ConfigurationDialog onClose={() => setConfigOpen(false)} />
          )}
        </div>
      </PluginRegistryProvider>
    </ConfigProvider>
  );
}
