const fs = require('fs');
let code = fs.readFileSync('src/components/BNDZUI.tsx', 'utf-8');
code = code.replace(/FileText, ChevronDown, ChevronRight, Terminal/, "FileText, ChevronDown, ChevronRight, PanelBottom");
fs.writeFileSync('src/components/BNDZUI.tsx', code);
