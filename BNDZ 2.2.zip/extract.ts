import { execSync } from 'child_process';
execSync('unzip -q "BNDZ 1.8.zip" -d extracted', { stdio: 'inherit' });
