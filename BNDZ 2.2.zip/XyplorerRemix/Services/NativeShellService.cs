using System;
using System.Drawing;
using Microsoft.WindowsAPICodePack.Shell;
using System.IO;

namespace XyplorerRemix.Services
{
    public class NativeShellService
    {
        public NativeShellService()
        {
        }

        public string GetNativeThumbnailBase64(string filePath)
        {
            try
            {
                if (string.IsNullOrEmpty(filePath) || (!File.Exists(filePath) && !Directory.Exists(filePath)))
                    return "";

                // Attempt to get a high-quality Extra Large thumbnail
                using var fileObj = ShellObject.FromParsingName(filePath);
                using var bitmap = fileObj.Thumbnail.ExtraLargeBitmap;
                if (bitmap != null)
                {
                    using var ms = new MemoryStream();
                    bitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                    return Convert.ToBase64String(ms.ToArray());
                }
            }
            catch
            {
                try
                {
                    // Fallback to basic icon extraction
                    var icon = System.Drawing.Icon.ExtractAssociatedIcon(filePath);
                    if (icon != null)
                    {
                        using var bitmap = icon.ToBitmap();
                        using var ms = new MemoryStream();
                        bitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                        return Convert.ToBase64String(ms.ToArray());
                    }
                }
                catch { }
            }
            return "";
        }
    }
}
