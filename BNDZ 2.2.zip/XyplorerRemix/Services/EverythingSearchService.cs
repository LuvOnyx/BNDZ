using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using EverythingNet.Core;
using EverythingNet.Query;

namespace XyplorerRemix.Services
{
    public class EverythingSearchService
    {
        public EverythingSearchService()
        {
        }

        public IEnumerable<object> Search(string query, int limit = 1000)
        {
            // Prepare backend for zero-latency global search using EverythingNet
            var results = new List<object>();
            try
            {
                // In production, uncomment if EverythingState.IsStarted() is required
                // if (EverythingState.IsStarted())
                // {
                    var everything = new Everything();
                    var queryResult = everything.Search().Name.Contains(query);
                    foreach (var item in queryResult.Take(limit))
                    {
                        bool isDir = item.IsFolder;
                        long size = 0;
                        if (!isDir && item.Size.HasValue) size = item.Size.Value;

                        results.Add(new {
                            id = Guid.NewGuid().ToString(),
                            name = item.Name,
                            type = isDir ? "directory" : "file",
                            size = size,
                            modified = item.ModificationTime?.ToString("O") ?? DateTime.Now.ToString("O"),
                            created = item.CreationTime?.ToString("O") ?? DateTime.Now.ToString("O"),
                            accessed = item.AccessTime?.ToString("O") ?? DateTime.Now.ToString("O"),
                            extension = isDir ? "" : (Path.GetExtension(item.Name)?.TrimStart('.') ?? ""),
                            path = "/" + item.FullPath.Replace("\\", "/")
                        });
                    }
                // }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Search failed: {ex.Message}");
            }
            return results;
        }
    }
}
