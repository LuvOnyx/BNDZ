using System;
using System.IO;
using System.Windows;
using System.Windows.Input;
using System.Threading.Tasks;
using System.Text.Json;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Timers;
using System.Linq;
using XyplorerRemix.Services;
// using Microsoft.Web.WebView2.Core;

namespace XyplorerRemix
{
    public partial class MainWindow : Window
    {
        private readonly FileManagementService _fileService;
        private readonly AiAssistantService _aiService;
        private readonly ShellIntegrationService _shellIntegrationService;
        private readonly FileOperationService _fileOperationService;
        private string _currentPath = "C:\\";

        private ConcurrentDictionary<string, FileSystemWatcher> _watchers = new();
        private ConcurrentQueue<object> _fseventBuffer = new();
        private Timer _debounceTimer;

        // Using TaskCompletionSource to wait for frontend conflict resolution
        private ConcurrentDictionary<string, TaskCompletionSource<string>> _conflictResolvers = new();

        public MainWindow(FileManagementService fileService, AiAssistantService aiService, ShellIntegrationService shellIntegrationService)
        {
            InitializeComponent();
            _fileService = fileService;
            _aiService = aiService;
            _shellIntegrationService = shellIntegrationService;
            _fileOperationService = new FileOperationService();
            
            SetupDebouncedWatcher();
            this.Loaded += MainWindow_Loaded;
            InitializeWebViewAsync();
        }

        private void SetupDebouncedWatcher()
        {
            _debounceTimer = new Timer(150); // 150ms debounce window to batch rapid SSD events
            _debounceTimer.AutoReset = true;
            _debounceTimer.Elapsed += (s, e) => FlushFsEvents();
            _debounceTimer.Start();
        }

        private void MonitorDirectory(string path)
        {
            // Normalize path for Windows FileSystemWatcher
            path = path.Replace("/", "\\");
            if (!Directory.Exists(path)) return;
            
            if (_watchers.ContainsKey(path)) return;

            var watcher = new FileSystemWatcher(path)
            {
                NotifyFilter = NotifyFilters.FileName | NotifyFilters.DirectoryName | NotifyFilters.LastWrite,
                EnableRaisingEvents = true
            };

            watcher.Created += (s, e) => QueueFsEvent("Created", path, e.Name);
            watcher.Deleted += (s, e) => QueueFsEvent("Deleted", path, e.Name);
            watcher.Changed += (s, e) => QueueFsEvent("Changed", path, e.Name);
            watcher.Renamed += (s, e) => QueueFsEvent("Renamed", path, e.Name, e.OldName);

            _watchers[path] = watcher;
        }

        private void QueueFsEvent(string type, string dir, string name, string oldName = null)
        {
            _fseventBuffer.Enqueue(new { type, dir = dir.Replace("\\", "/"), name, oldName });
        }

        private void FlushFsEvents()
        {
            if (_fseventBuffer.IsEmpty) return;

            var batch = new List<object>();
            while (_fseventBuffer.TryDequeue(out var ev))
            {
                batch.Add(ev);
            }

            var payload = new { type = "FS_EVENT_BATCH", payload = batch };
            var json = JsonSerializer.Serialize(payload, new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });

            Dispatcher.InvokeAsync(() => 
            {
                // Send batched payload back to the React frontend
                // MainWebView.CoreWebView2.PostWebMessageAsJson(json);
                Console.WriteLine($"[Mock] Posting {batch.Count} debounced FS events to WebView2");
            });
        }

        private async void InitializeWebViewAsync()
        {
            // Note: This assumes a WebView2 control named 'MainWebView' is added to MainWindow.xaml.
            // Explicitly await initialization before attaching message handler to prevent null references
            // await MainWebView.EnsureCoreWebView2Async(null);
            // MainWebView.CoreWebView2.WebMessageReceived += CoreWebView2_WebMessageReceived;
        }

        private async void CoreWebView2_WebMessageReceived(object sender, object /* CoreWebView2WebMessageReceivedEventArgs */ e)
        {
            try
            {
                // dynamic message = e.TryGetWebMessageAsString();
                string messageStr = "{ \"type\": \"SYNC_FOLDERS\", \"payload\": { \"source\": \"/C:/src\", \"target\": \"/C:/dest\" } }"; // Mock
                
                using var doc = JsonDocument.Parse(messageStr);
                var root = doc.RootElement;
                if (!root.TryGetProperty("type", out var typeProp)) return;

                string type = typeProp.GetString();
                if (type == "EXECUTE_FS_OPERATION")
                {
                    var payload = root.GetProperty("payload");
                    string operationId = payload.GetProperty("operationId").GetString() ?? Guid.NewGuid().ToString();
                    string action = payload.GetProperty("action").GetString() ?? "copy";
                    string source = payload.GetProperty("source").GetString() ?? "";
                    string target = payload.GetProperty("target").GetString() ?? "";
                    bool bypassRecycleBin = payload.TryGetProperty("bypassRecycleBin", out var brProp) ? brProp.GetBoolean() : false;

                    // Run as a background task
                    _ = _fileOperationService.ExecuteOperationAsync(operationId, action, source, target, bypassRecycleBin,
                        onProgress: (opId, percentage, currentFile, bytesTransferred, totalBytes, speedBytesPerSecond, itemsCompleted, totalItems) =>
                        {
                            var evt = new { type = "PROGRESS_UPDATE", payload = new { operationId = opId, percentage, currentFile, bytesTransferred, totalBytes, speedBytesPerSecond, itemsCompleted, totalItems } };
                            Dispatcher.InvokeAsync(() => {
                                MainWebView.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(evt));
                            });
                        },
                        onConflict: async (opId, fileName, srcPath, destPath) =>
                        {
                            var evt = new { type = "CONFLICT_DETECTED", payload = new { operationId = opId, fileName, sourcePath = srcPath, destPath } };
                            var tcs = new TaskCompletionSource<string>();
                            string conflictKey = $"{opId}:{fileName}";
                            _conflictResolvers[conflictKey] = tcs;

                            Dispatcher.InvokeAsync(() => {
                                MainWebView.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(evt));
                            });

                            return await tcs.Task;
                        });
                }
                else if (type == "START_DRAG")
                {
                    var payload = root.GetProperty("payload");
                    string path = payload.GetProperty("path").GetString() ?? "";
                    if (path.StartsWith("/")) path = path.Substring(1);
                    path = path.Replace("/", "\\");

                    Dispatcher.InvokeAsync(() => {
                        try
                        {
                            var dataObject = new DataObject(DataFormats.FileDrop, new string[] { path });
                            DragDrop.DoDragDrop(this, dataObject, DragDropEffects.Copy | DragDropEffects.Move | DragDropEffects.Link);
                        }
                        catch { }
                    });
                }
                else if (type == "CLEAR_THUMBNAIL_CACHE")
                {
                    Dispatcher.InvokeAsync(() => {
                        Console.WriteLine("[Mock] Native thumbnail cache cleared.");
                    });
                }
                else if (type == "RESOLVE_CONFLICT")
                {
                    var payload = root.GetProperty("payload");
                    string operationId = payload.GetProperty("operationId").GetString() ?? "";
                    string fileName = payload.GetProperty("fileName").GetString() ?? "";
                    string resolution = payload.GetProperty("resolution").GetString() ?? "skip"; // "replace", "skip", "keepboth"
                    string conflictKey = $"{operationId}:{fileName}";

                    if (_conflictResolvers.TryGetValue(conflictKey, out var tcs))
                    {
                        tcs.SetResult(resolution);
                        _conflictResolvers.TryRemove(conflictKey, out _);
                    }
                }
                else if (type == "SHELL_EXECUTE")
                {
                    var payload = root.GetProperty("payload");
                    string action = payload.GetProperty("action").GetString() ?? "";
                    string path = payload.GetProperty("path").GetString() ?? "";
                    
                    if (path.StartsWith("/")) path = path.Substring(1);
                    path = path.Replace("/", "\\");
                    if (path.EndsWith(":") && path.Length == 2) path += "\\";
                    if (action == "open")
                    {
                        if (File.Exists(path) || Directory.Exists(path))
                        {
                            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo { FileName = path, UseShellExecute = true });
                        }
                    }
                    else if (action == "openWith")
                    {
                        if (File.Exists(path) || Directory.Exists(path))
                        {
                             System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo { FileName = "rundll32.exe", Arguments = $"shell32.dll,OpenAs_RunDLL {path}", UseShellExecute = true });
                        }
                    }
                    else if (action == "copyPath")
                    {
                        Dispatcher.Invoke(() => {
                           System.Windows.Clipboard.SetText(path);
                        });
                    }
                    else if (action == "compress")
                    {
                        // Mock compress for now as ZipArchive requires extra setup
                        Console.WriteLine($"[Mock] Compress to zip requested for: {path}");
                    }
                    else if (action == "properties")
                    {
                        if (File.Exists(path) || Directory.Exists(path))
                        {
                            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo { FileName = path, Verb = "properties", UseShellExecute = true });
                        }
                    }
                }
                else if (type == "GET_SUB_DIRECTORIES")
                {
                    var payload = root.GetProperty("payload");
                    string path = payload.GetProperty("path").GetString() ?? "";
                    if (path.StartsWith("/")) path = path.Substring(1);
                    path = path.Replace("/", "\\");
                    if (path.EndsWith(":") && path.Length == 2) path += "\\";
                    bool showHidden = payload.TryGetProperty("showHidden", out var shElement) && shElement.GetBoolean();
                    var idProp = root.TryGetProperty("id", out var idElement) ? idElement.GetString() : null;

                    _ = Task.Run(() => 
                    {
                        var results = new List<object>();
                        try
                        {
                            if (Directory.Exists(path))
                            {
                                foreach (var dir in Directory.GetDirectories(path))
                                {
                                    var di = new DirectoryInfo(dir);
                                    if (!showHidden && (di.Attributes & FileAttributes.Hidden) == FileAttributes.Hidden) continue;

                                    results.Add(new {
                                        id = Guid.NewGuid().ToString(),
                                        name = di.Name,
                                        type = "directory",
                                        path = dir.Replace("\\", "/"),
                                        size = 0,
                                        modified = di.LastWriteTime.ToString("O")
                                    });
                                }
                            }
                        }
                        catch { }

                        var response = new { type = "SUBDIR_RESULT", id = idProp, payload = results };
                        var jsonOptions = new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };
                        string responseJson = JsonSerializer.Serialize(response, jsonOptions);

                        Dispatcher.InvokeAsync(() => {
                            // MainWebView.CoreWebView2.PostWebMessageAsJson(responseJson);
                            Console.WriteLine($"[Mock] Got Subdirectories. Sent to WebView2.");
                        });
                    });
                }
                else if (type == "SHOW_CONTEXT_MENU")
                {
                    var payload = root.GetProperty("payload");
                    string path = payload.GetProperty("path").GetString() ?? "";
                    if (path.StartsWith("/")) path = path.Substring(1);
                    path = path.Replace("/", "\\");
                    if (path.EndsWith(":") && path.Length == 2) path += "\\";
                    int x = payload.GetProperty("x").GetInt32();
                    int y = payload.GetProperty("y").GetInt32();

                    Dispatcher.InvokeAsync(() => {
                        // Normally use Vanara NativeShellService to display native popup context menu at coordinates.
                        System.Diagnostics.Debug.WriteLine($"[Mock] Showing native context menu for {path} at {x},{y}");
                    });
                }
                else if (type == "SYNC_FOLDERS")
                {
                    var payload = root.GetProperty("payload");
                    string source = payload.GetProperty("source").GetString() ?? "";
                    string target = payload.GetProperty("target").GetString() ?? "";
                    
                    var id = root.TryGetProperty("id", out var idProp) ? idProp.GetString() : null;

                    await SyncDirectoriesTrueAsync(source, target);

                    // Send response back
                    // MainWebView.CoreWebView2.PostWebMessageAsJson("{\"id\": \"" + id + "\", \"result\": \"ok\"}");
                }
                else if (type == "AI_BATCH_RENAME")
                {
                    // Call the AI Service
                }
                else if (type == "WATCH_DIR")
                {
                    var payload = root.GetProperty("payload");
                    string path = payload.GetProperty("path").GetString() ?? "";
                    if (path.StartsWith("/")) path = path.Substring(1);
                    path = path.Replace("/", "\\");
                    if (path.EndsWith(":") && path.Length == 2) path += "\\";
                    MonitorDirectory(path);
                }
                else if (type == "GET_DRIVES")
                {
                    var idProp = root.TryGetProperty("id", out var idElement) ? idElement.GetString() : null;
                    var drives = DriveInfo.GetDrives().Where(d => d.IsReady).Select(d => new {
                        name = "/" + d.Name.Replace("\\", ""),
                        label = d.VolumeLabel,
                        totalSpace = d.TotalSize,
                        freeSpace = d.TotalFreeSpace,
                        fileSystem = d.DriveFormat
                    }).ToList();
                    
                    var response = new { type = "DRIVES_RESULT", id = idProp, payload = drives };
                    Dispatcher.InvokeAsync(() => {
                        // MainWebView.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(response));
                        Console.WriteLine($"[Mock] returning {drives.Count} drive(s) to WebView2");
                    });
                }
                else if (type == "PERFORM_GLOBAL_SEARCH")
                {
                    var payload = root.GetProperty("payload");
                    string query = payload.GetProperty("query").GetString() ?? "";
                    int limit = payload.TryGetProperty("limit", out var limitEl) && limitEl.ValueKind == JsonValueKind.Number ? limitEl.GetInt32() : 1000;
                    var idProp = root.TryGetProperty("id", out var idElement) ? idElement.GetString() : null;

                    _ = Task.Run(() => 
                    {
                        var searchSvc = new EverythingSearchService();
                        var results = searchSvc.Search(query, limit);

                        var response = new { type = "GLOBAL_SEARCH_RESULT", id = idProp, payload = results };
                        var jsonOptions = new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };
                        string responseJson = JsonSerializer.Serialize(response, jsonOptions);

                        Dispatcher.InvokeAsync(() => {
                            // MainWebView.CoreWebView2.PostWebMessageAsJson(responseJson);
                            Console.WriteLine($"[Mock] Got {results.Count()} search hits. Sent to WebView2.");
                        });
                    });
                }
                else if (type == "GET_THUMBNAIL")
                {
                    var payload = root.GetProperty("payload");
                    string path = payload.GetProperty("path").GetString() ?? "";
                    if (path.StartsWith("/")) path = path.Substring(1);
                    path = path.Replace("/", "\\");
                    if (path.EndsWith(":") && path.Length == 2) path += "\\";
                    var idProp = root.TryGetProperty("id", out var idElement) ? idElement.GetString() : null;

                    _ = Task.Run(() => 
                    {
                        var nativeSvc = new NativeShellService();
                        string base64 = nativeSvc.GetNativeThumbnailBase64(path);

                        var response = new { type = "THUMBNAIL_RESULT", id = idProp, payload = string.IsNullOrEmpty(base64) ? null : base64 };
                        var jsonOptions = new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };
                        string responseJson = JsonSerializer.Serialize(response, jsonOptions);

                        Dispatcher.InvokeAsync(() => {
                            // MainWebView.CoreWebView2.PostWebMessageAsJson(responseJson);
                            Console.WriteLine($"[Mock] Got thumbnail. Sent to WebView2.");
                        });
                    });
                }
                else if (type == "SHELL_INTEGRATION")
                {
                    var payload = root.GetProperty("payload");
                    string action = payload.GetProperty("action").GetString() ?? "";
                    if (action == "setDefault")
                    {
                        bool enable = payload.GetProperty("enable").GetBoolean();
                        _shellIntegrationService.SetAsDefaultFileManager(enable);
                    }
                    else if (action == "setContextMenu")
                    {
                        bool enable = payload.GetProperty("enable").GetBoolean();
                        _shellIntegrationService.SetInContextMenu(enable);
                    }
                    else if (action == "relaunchAdmin")
                    {
                        _shellIntegrationService.RelaunchAsAdministrator();
                    }
                }
                else if (type == "SAVE_SETTINGS")
                {
                    try
                    {
                        var payload = root.GetProperty("payload");
                        string jsonString = payload.GetRawText();
                        string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                        string bndzData = Path.Combine(appData, "BNDZ64");
                        if (!Directory.Exists(bndzData)) Directory.CreateDirectory(bndzData);
                        File.WriteAllText(Path.Combine(bndzData, "BNDZ.ini"), jsonString);
                        Console.WriteLine("Saved settings to " + Path.Combine(bndzData, "BNDZ.ini"));
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error saving settings: {ex.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing WebView message: {ex.Message}");
            }
        }
        
        /// <summary>
        /// True asynchronous directory synchronizer utilizing non-blocking I/O streams to saturate NVMe/SSD throughput.
        /// </summary>
        private async Task SyncDirectoriesTrueAsync(string sourceDir, string targetDir)
        {
            // Standardize paths (mock logic handles virtual-local normalization)
            sourceDir = sourceDir.Replace("/", "\\");
            targetDir = targetDir.Replace("/", "\\");
            
            if (!Directory.Exists(sourceDir)) return;
            Directory.CreateDirectory(targetDir);

            // Enumerate files lazily to reduce memory footprint and avoid scanning blocks
            var files = Directory.EnumerateFiles(sourceDir, "*.*", SearchOption.AllDirectories);
            var tasks = new List<Task>();

            foreach (var file in files)
            {
                string refPath = Path.GetRelativePath(sourceDir, file);
                string destPath = Path.Combine(targetDir, refPath);
                
                string destDir = Path.GetDirectoryName(destPath);
                if (!string.IsNullOrEmpty(destDir) && !Directory.Exists(destDir))
                    Directory.CreateDirectory(destDir);

                // Concurrent, true async I/O file copying avoids blocking ThreadPool threads
                tasks.Add(CopyFileAsync(file, destPath));
                
                // Throttle concurrency if needed to avoid exhaustion, optimizing for SSDs
                if (tasks.Count >= Environment.ProcessorCount * 4)
                {
                    var completedTask = await Task.WhenAny(tasks);
                    tasks.Remove(completedTask);
                }
            }
            
            await Task.WhenAll(tasks);
        }

        private async Task CopyFileAsync(string sourceFile, string destinationFile)
        {
            const int bufferSize = 4096 * 1024; // 4MB buffer for SSDs
            using var sourceStream = new FileStream(sourceFile, FileMode.Open, FileAccess.Read, FileShare.Read, bufferSize, FileOptions.Asynchronous | FileOptions.SequentialScan);
            using var destinationStream = new FileStream(destinationFile, FileMode.Create, FileAccess.Write, FileShare.None, bufferSize, FileOptions.Asynchronous | FileOptions.SequentialScan);
            
            await sourceStream.CopyToAsync(destinationStream);
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            LoadDirectory(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile));
        }

        private void LoadDirectory(string path)
        {
            if (Directory.Exists(path))
            {
                _currentPath = path;
                AddressBar.Text = _currentPath;
                var items = _fileService.GetFilesAndDirectories(_currentPath);
                FileListView.ItemsSource = items;
                StatusText.Text = $"{items.Count} items loaded.";
            }
        }

        private void AddressBar_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                LoadDirectory(AddressBar.Text);
            }
        }

        private void UpButton_Click(object sender, RoutedEventArgs e)
        {
            var parent = Directory.GetParent(_currentPath);
            if (parent != null)
            {
                LoadDirectory(parent.FullName);
            }
        }

        private void AiSearchButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("AI Semantic Search initialized.\nExample: 'Find all unorganized tax documents from last month'.\n\n(Awaiting external inference endpoint)", "AI Assistant", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void BatchRename_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Batch Rename Window opened.\nSupports pattern matching, regex, and AI contextual naming.", "Batch Renaming Tool", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
