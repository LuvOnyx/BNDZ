import { useState, useEffect } from "react";
import { Folder, File } from "lucide-react";
import { IPC } from "../lib/ipcBridge";
import { useAppConfig } from "../data/configContext";
import { FSEntity } from "../types";

// Local cache to prevent flashing
const _thumbnailCache: Record<string, string> = {};

export function ThumbnailIcon({ entity, isDir, path, size = 16 }: { entity: FSEntity, isDir: boolean, path: string, size?: number }) {
  const { config } = useAppConfig();
  const [thumb, setThumb] = useState<string | null>(entity.iconBase64 || _thumbnailCache[path] || null);

  useEffect(() => {
    if (thumb || !config.enableNativeThumbnails) return;
    
    let isMounted = true;
    IPC.getNativeThumbnailBase64(path).then(res => {
      if (res && isMounted) {
         const fullData = res.startsWith('data:') ? res : `data:image/png;base64,${res}`;
         _thumbnailCache[path] = fullData;
         setThumb(fullData);
      }
    });

    return () => { isMounted = false; };
  }, [path, config.enableNativeThumbnails, thumb]);

  if (thumb) {
     return <img src={thumb} alt="" style={{ width: size, height: size }} className="object-contain" />;
  }
  return isDir ? <Folder size={size} className="text-[#dcb67a]" /> : <File size={size} className="text-[#eee]" />;
}
