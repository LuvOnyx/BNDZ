import React from 'react';
import { Dialog, DialogContent, DialogTitle, DialogDescription, DialogHeader, DialogTrigger } from "./ui/dialog";
import { Check, Plus } from 'lucide-react';
import { usePluginRegistry } from '../data/PluginRegistryContext';
import { allPlugins } from './BottomPluginPanel';

export function PluginStoreDialog({ children }: { children: React.ReactNode }) {
    const { installedPlugins, togglePluginInstall } = usePluginRegistry();

    return (
        <Dialog>
            {children}
            <DialogContent className="bg-[#1e1e1e] border-[#444] text-gray-200 sm:max-w-[500px]">
                <DialogHeader>
                    <DialogTitle className="text-[14px]">Plugin Store</DialogTitle>
                    <DialogDescription className="text-[12px] text-gray-400">
                        Install or uninstall tools for the bottom panel.
                    </DialogDescription>
                </DialogHeader>

                <div className="flex flex-col gap-2 mt-4 max-h-[60vh] overflow-y-auto no-scrollbar pr-2">
                    {allPlugins.map(plugin => {
                        const isInstalled = installedPlugins.includes(plugin.id);
                        return (
                            <div 
                                key={plugin.id}
                                className={`flex items-center justify-between px-3 py-2 text-[12px] rounded-[4px] cursor-pointer border transition-colors ${ isInstalled ? 'bg-sky-900/30 border-sky-500/50' : 'bg-[#222] border-[#444] hover:bg-[#333]' }`}
                                onClick={() => togglePluginInstall(plugin.id)}
                            >
                                <div className="flex items-center gap-3">
                                    <plugin.icon size={16} className={isInstalled ? 'text-sky-400' : 'text-gray-400'} />
                                    <span className={isInstalled ? 'text-white' : 'text-gray-300'}>{plugin.name}</span>
                                </div>
                                <div>
                                    {isInstalled ? <Check size={14} className="text-sky-400" /> : <Plus size={14} className="text-gray-500" />}
                                </div>
                            </div>
                        )
                    })}
                </div>
            </DialogContent>
        </Dialog>
    );
}
