import React, { useState } from 'react';
import { Layers, Copy, Scissors, Trash } from 'lucide-react';
import { IPC } from '../../lib/ipcBridge';

export const DropStackPluginDef = {
    id: "drop-stack",
    name: "Drop Stack",
    icon: Layers
};

export default function DropStackPlugin({ activeTab, drives, config, entity, focusedPath }: any) {
    const [staged, setStaged] = useState<any[]>([]);

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        try {
            const data = e.dataTransfer.getData("application/bndz-file");
            if (data) {
                const parsed = JSON.parse(data);
                // In a real app we'd fetch the entity details, here we construct a stub or we expect the entity info in drop
                setStaged(prev => [...prev, { path: `${parsed.sourcePath}/${parsed.entityId}`, name: parsed.entityId }]);
            }
        } catch {}
    };

    const handleCopyAll = () => {
        if (!focusedPath) return;
        staged.forEach((item, i) => IPC.executeFsOperation(`stack-copy-${i}`, 'copy', item.path, focusedPath));
        setStaged([]);
    };

    const handleMoveAll = () => {
        if (!focusedPath) return;
        staged.forEach((item, i) => IPC.executeFsOperation(`stack-move-${i}`, 'move', item.path, focusedPath));
        setStaged([]);
    };

    return (
        <div 
            className="w-full h-full p-4 flex flex-col"
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
        >
            <div className="flex justify-between items-center mb-4">
                <span className="text-[13px] font-bold text-gray-200">Drop Stack (Virtual Clipboard)</span>
                <div className="flex gap-2">
                    <button onClick={handleCopyAll} className="px-3 py-1 bg-[#007acc] hover:bg-sky-600 rounded text-[11px] flex items-center gap-1"><Copy size={12}/> Copy Here</button>
                    <button onClick={handleMoveAll} className="px-3 py-1 bg-[#264f78] hover:bg-sky-700 rounded text-[11px] flex items-center gap-1"><Scissors size={12}/> Move Here</button>
                    <button onClick={() => setStaged([])} className="px-3 py-1 bg-red-900/50 hover:bg-red-800 rounded text-[11px] flex items-center gap-1"><Trash size={12}/> Clear</button>
                </div>
            </div>
            
            <div className="flex-1 border border-[#333] bg-[#111] overflow-y-auto w-full p-2 text-[11px]">
                {staged.length === 0 ? (
                    <div className="w-full h-full flex items-center justify-center text-[#555] italic">Drag items from the file list and drop here...</div>
                ) : (
                    staged.map((it, idx) => (
                        <div key={idx} className="flex justify-between border-b border-[#222] py-1">
                            <span>{it.name}</span>
                            <span className="text-[#666] truncate pl-4 max-w-[50%]">{it.path}</span>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
}
