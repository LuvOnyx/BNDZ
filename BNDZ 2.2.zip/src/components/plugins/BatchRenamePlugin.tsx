import React, { useState, useEffect } from 'react';
import { Replace } from 'lucide-react';
import { IPC } from '../../lib/ipcBridge';

export const BatchRenamePluginDef = {
    id: "batch-rename",
    name: "Batch Rename",
    icon: Replace
};

export default function BatchRenamePlugin({ activeTab, drives, config, entity, focusedPath, selectedItems }: any) {
    const [pattern, setPattern] = useState("<name>");
    const [searchFor, setSearchFor] = useState("");
    const [replaceWith, setReplaceWith] = useState("");

    const previewRenames = (items: string[]) => {
        return items.map((oldName, i) => {
            let newName = pattern.replace(/<name>/g, oldName);
            newName = newName.replace(/<#+>/g, (match) => {
                const len = match.length - 2; // length of '#'
                return (i + 1).toString().padStart(len, '0');
            });
            if (searchFor) {
                newName = newName.split(searchFor).join(replaceWith);
            }
            return { oldName, newName };
        });
    };

    // If selectedItems isn't passed fully in current architecture, we will just use a mock array to showcase UI.
    const items = selectedItems || ["ExampleFile1.txt", "ExampleFile2.png", "Holiday_2023.jpg"];
    const previews = previewRenames(items);

    const handleCommit = () => {
        if (!focusedPath) return;
        previews.forEach((p, idx) => {
            if (p.oldName !== p.newName) {
                IPC.executeFsOperation(`rename-batch-${idx}`, 'move', `${focusedPath}/${p.oldName}`, `${focusedPath}/${p.newName}`);
            }
        });
    };

    return (
        <div className="w-full h-full p-4 flex flex-col text-[12px]">
            <div className="flex justify-between items-center mb-2">
                <span className="text-[13px] font-bold text-gray-200 flex items-center gap-2"><Replace size={14}/> Batch Rename</span>
                <button onClick={handleCommit} className="px-3 py-1 bg-emerald-700 hover:bg-emerald-600 rounded text-white text-[11px]">Commit Rename</button>
            </div>
            
            <div className="flex gap-4 mb-4">
                <div className="flex-1">
                    <label className="text-[#888] mb-1 block">Rename Pattern (use &lt;name&gt;, &lt;##&gt;)</label>
                    <input type="text" value={pattern} onChange={e => setPattern(e.target.value)} className="w-full bg-[#111] border border-[#333] px-2 py-1 outline-none text-white focus:border-sky-500" />
                </div>
                <div className="flex-1">
                    <label className="text-[#888] mb-1 block">Search For</label>
                    <input type="text" value={searchFor} onChange={e => setSearchFor(e.target.value)} className="w-full bg-[#111] border border-[#333] px-2 py-1 outline-none text-white focus:border-sky-500" />
                </div>
                <div className="flex-1">
                    <label className="text-[#888] mb-1 block">Replace With</label>
                    <input type="text" value={replaceWith} onChange={e => setReplaceWith(e.target.value)} className="w-full bg-[#111] border border-[#333] px-2 py-1 outline-none text-white focus:border-sky-500" />
                </div>
            </div>

            <div className="flex-1 border border-[#333] bg-[#111] overflow-y-auto w-full p-0">
                <table className="w-full text-left border-collapse">
                    <thead className="bg-[#1a1a1a] sticky top-0 border-b border-[#333]">
                        <tr>
                            <th className="p-2 font-medium text-[#888]">Original Name</th>
                            <th className="p-2 font-medium text-[#888]">New Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        {previews.map((p, i) => (
                            <tr key={i} className="border-b border-[#222]">
                                <td className="p-2 text-[#aaa]">{p.oldName}</td>
                                <td className="p-2 text-white">{p.newName}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
