import React from 'react';
import { Database } from 'lucide-react';

export default function MetadataPlugin() {
    return (
        <div className="flex-1 flex flex-col items-center justify-center text-[#555] font-sans text-[13px] bg-[#181818] border border-[#333] rounded-[4px] shadow-inner relative m-4">
            <div className="w-[80px] h-[80px] border border-[#333] rounded-full flex items-center justify-center mb-4 bg-[#111]">
                <Database size={24} className="text-[#444]" />
            </div>
            <span className="text-gray-400 font-bold tracking-tight mb-1 text-[16px]">Metadata Module Ready</span>
            <span className="text-[12px] text-[#555]">Metadata tools go here.</span>
        </div>
    );
}
