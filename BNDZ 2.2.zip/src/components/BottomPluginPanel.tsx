import React, { useState, Suspense } from 'react';
import { Settings, Search, Filter, Database, Check, X, Plus, Puzzle, Layers, Replace } from 'lucide-react';
import { FSEntity } from '../types';
import { usePluginRegistry } from '../data/PluginRegistryContext';
import { PluginStoreDialog } from './PluginStoreDialog';
import { DialogTrigger } from './ui/dialog';

// Lazy loaded plugins
const PropertiesPlugin = React.lazy(() => import('./plugins/PropertiesPlugin'));
const FindPlugin = React.lazy(() => import('./plugins/FindPlugin'));
const FiltersPlugin = React.lazy(() => import('./plugins/FiltersPlugin'));
const MetadataPlugin = React.lazy(() => import('./plugins/MetadataPlugin'));
const DropStackPlugin = React.lazy(() => import('./plugins/DropStackPlugin'));
const BatchRenamePlugin = React.lazy(() => import('./plugins/BatchRenamePlugin'));

export const allPlugins = [
   { id: 'properties', name: 'Properties', icon: Settings, component: PropertiesPlugin },
   { id: 'find', name: 'Find', icon: Search, component: FindPlugin },
   { id: 'filters', name: 'Filters', icon: Filter, component: FiltersPlugin },
   { id: 'metadata', name: 'Metadata', icon: Database, component: MetadataPlugin },
   { id: 'drop-stack', name: 'Drop Stack', icon: Layers, component: DropStackPlugin },
   { id: 'batch-rename', name: 'Batch Rename', icon: Replace, component: BatchRenamePlugin },
];

export default function BottomPluginPanel({ entity, config, drives = [], focusedPath = "", selectedItems = [] }: { entity: FSEntity | null, config: any, drives?: any[], focusedPath?: string, selectedItems?: string[] }) {
   const { installedPlugins, togglePluginInstall } = usePluginRegistry();

   const [activeTab, setActiveTab] = useState('properties');

   // Render active plugin content
   const renderPluginContent = () => {
      const plugin = allPlugins.find(p => p.id === activeTab);
      if (!plugin) return null;

      // Ensure we only show content if it's installed
      if (!installedPlugins.includes(activeTab)) {
         return (
            <div className="flex-1 flex flex-col items-center justify-center text-[#555] font-sans text-[13px] bg-[#181818] border border-[#333] rounded-[4px] shadow-inner relative">
               <div className="w-[80px] h-[80px] border border-[#333] rounded-full flex items-center justify-center mb-4 bg-[#111]">
                  <Puzzle size={24} className="text-[#444]" />
               </div>
               <span className="text-gray-400 font-bold tracking-tight mb-1 text-[16px]">Module "{plugin.name}" Offline</span>
               <span className="text-[12px] text-[#555]">This plugin module is unloaded in the store.</span>
            </div>
         );
      }

      const PluginComponent = plugin.component;
      return (
         <Suspense fallback={<div className="flex-1 p-4 flex items-center justify-center text-gray-500 text-xs">Loading {plugin.name}...</div>}>
            <PluginComponent entity={entity} config={config} drives={drives} focusedPath={focusedPath} selectedItems={selectedItems} />
         </Suspense>
      );
   };

   return (
      <div className="w-full h-full bg-[#151515] flex flex-col border-t border-[#333] shadow-[0_-4px_15px_rgba(0,0,0,0.2)] text-[#e0e0e0] select-none rounded-t-lg">
         {/* Tabs */}
         <div className="flex bg-[#1a1a1a] border-b border-[#333] justify-between items-center pr-2 shrink-0 h-[32px]">
            <div className="flex h-full overflow-x-auto no-scrollbar styled-scrollbar">
               {allPlugins.filter(p => installedPlugins.includes(p.id)).map((tab) => (
                  <div 
                     key={tab.id}
                     className={`flex items-center gap-2 px-4 h-full text-[12px] cursor-pointer border-t-[3px] transition-colors group relative ${
                        activeTab === tab.id 
                           ? 'border-t-sky-500 bg-[#151515] text-white' 
                           : 'border-t-transparent text-gray-400 hover:text-white hover:bg-[#222]'
                     }`}
                     onClick={() => setActiveTab(tab.id)}
                  >
                     <tab.icon size={12} />
                     <span>{tab.name}</span>
                  </div>
               ))}
               {installedPlugins.length === 0 && (
                  <div className="px-4 py-1.5 text-[12px] text-gray-500 italic">No plugins installed</div>
               )}
            </div>
            
            <div className="flex gap-2 shrink-0">
               <PluginStoreDialog>
                  <DialogTrigger asChild>
                     <button className="flex items-center gap-1.5 px-2 py-0.5 text-[11px] rounded-sm transition-colors border bg-[#222] text-gray-400 border-[#333] hover:text-white hover:bg-[#333]">
                        <Plus size={12} /> Plugin Store
                     </button>
                  </DialogTrigger>
               </PluginStoreDialog>
            </div>
         </div>
         
         {/* Content */}
         <div className="flex-1 overflow-y-auto p-0 flex gap-6 min-h-0 bg-[#111] styled-scrollbar">
            {renderPluginContent()}
         </div>
      </div>
   );
}
