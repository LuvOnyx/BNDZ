import React from "react";
import { useAppConfig } from "../data/configContext";
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors } from "@dnd-kit/core";
import { arrayMove, SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy, useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

const SortableCategory: React.FC<{ id: string; children: React.ReactNode }> = ({ id, children }) => {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div ref={setNodeRef} style={style} className="mb-4">
      {/* Grabbable handle zone for header */}
      <div {...attributes} {...listeners} className="cursor-grab active:cursor-grabbing px-3 pb-1 pt-1 uppercase text-[#666] text-[10px] font-bold tracking-wider mb-1 border-b border-[#222]">
        {id === 'storage' ? 'Storage Units' : id === 'quick' ? 'Quick Access' : 'Navigation Tree'}
      </div>
      <div>{children}</div>
    </div>
  );
}

export function LeftSidebar({ drivesContent, quickAccessContent, treeContent }: any) {
  const { config, updateConfig } = useAppConfig();
  const items = config.sidebarOrder || ['storage', 'quick', 'tree'];

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const handleDragEnd = (event: any) => {
    const { active, over } = event;
    if (active.id !== over.id) {
      const oldIndex = items.indexOf(active.id);
      const newIndex = items.indexOf(over.id);
      updateConfig({ sidebarOrder: arrayMove(items, oldIndex, newIndex) });
    }
  };

  return (
    <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
      <SortableContext items={items} strategy={verticalListSortingStrategy}>
        <div className="w-full h-full text-[#d4d4d4] text-[12px]">
          {items.map((id: string) => {
             const content = id === 'storage' ? drivesContent : id === 'quick' ? quickAccessContent : treeContent;
             if (!content) return null;
             return (
               <SortableCategory key={id} id={id}>
                 {content}
               </SortableCategory>
             );
          })}
        </div>
      </SortableContext>
    </DndContext>
  );
}
