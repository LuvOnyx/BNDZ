import React, { createContext, useContext, ReactNode } from 'react';
import { useAppConfig } from './configContext';

interface PluginRegistryContextType {
    installedPlugins: string[];
    togglePluginInstall: (id: string) => void;
}

const PluginRegistryContext = createContext<PluginRegistryContextType>({
    installedPlugins: [],
    togglePluginInstall: () => {},
});

export const PluginRegistryProvider = ({ children }: { children: ReactNode }) => {
    const { config, updateConfig } = useAppConfig();

    const installedPlugins = config.installedPlugins || ['properties', 'find', 'filters', 'metadata'];

    const togglePluginInstall = (id: string) => {
        const nextInstalled = installedPlugins.includes(id) 
            ? installedPlugins.filter((p: string) => p !== id)
            : [...installedPlugins, id];
        
        updateConfig({ installedPlugins: nextInstalled });
    };

    return (
        <PluginRegistryContext.Provider value={{ installedPlugins, togglePluginInstall }}>
            {children}
        </PluginRegistryContext.Provider>
    );
};

export const usePluginRegistry = () => useContext(PluginRegistryContext);
