import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface AppConfig {
    [key: string]: any;
    enableContextSubmenus: boolean;
    showTopMenubar: boolean;
    enableHistoryNavigation: boolean;
    sortFoldersFirst: boolean;
    isDefaultFileManager: boolean;
    inContextMenu: boolean;
    enableEverythingSearch: boolean;
    enableNativeThumbnails: boolean;
    clearThumbnailCacheOnExit: boolean;
    bypassRecycleBin: boolean;
    enableGlobalSearchPrefix: boolean;
    globalSearchLimit: number;
    pinnedFavorites?: Array<{ name: string, path: string, icon: string }>;
    sidebarOrder?: string[];
    installedPlugins?: string[];
    showHiddenSystemFoldersInTree: boolean;
    useNativeOSContextMenu: boolean;
    previewCategories: Array<{n: string, d: string, c: boolean}>;
    previewFormats: Array<{i: string, n: string, c: boolean}>;
    colorFilters: Array<{i: number, c: boolean, t: string, style: string}>;
}

export const defaultConfig: AppConfig = {
    enableContextSubmenus: true,
    showTopMenubar: true,
    fileTaggingFeature: true,
    userDefinedCommands: true,
    scripting: true,
    dualPaneFeature: true,
    tabsets: true,
    enableHistoryNavigation: true,
    sortFoldersFirst: true,
    isDefaultFileManager: false,
    inContextMenu: false,
    enableEverythingSearch: true,
    enableNativeThumbnails: true,
    clearThumbnailCacheOnExit: false,
    bypassRecycleBin: false,
    enableGlobalSearchPrefix: true,
    globalSearchLimit: 1000,
    pinnedFavorites: [],
    sidebarOrder: ['storage', 'quick', 'tree'],
    showHiddenSystemFoldersInTree: false,
    useNativeOSContextMenu: true,
    previewCategories: [
        {n:"Text Files", d:"bat, inf, ini, txt ...", c:true},
        {n:"Document Files", d:"docx, odt, pdf, xlsx ...", c:true},
        {n:"Web Files", d:"htm, svg, url, xml, zip ...", c:true},
        {n:"Font Files", d:"fon, otf, pfm, ttf ...", c:true},
        {n:"Image Files", d:"gif, jpg, png, raw ...", c:true},
        {n:"Audio Files", d:"flac, mp3, ogg, wav ...", c:true},
        {n:"Video Files", d:"avi, mp4, mpg, wmv ...", c:true},
        {n:"Preview as Thumbnail", d:"afphoto, slddrw, webp ...", c:true},
        {n:"User-Defined Preview Handlers", d:"", c:true}
    ],
    previewFormats: [
        {i:"txt", n:"*.accurip, ACCURIP File", c:true},
        {i:"txt", n:"*.adml, ADML File", c:true},
        {i:"txt", n:"*.admx, ADMX File", c:true},
        {i:"txt", n:"*.ahk, AHK File", c:true},
        {i:"txt", n:"*.asc, ASC File", c:true},
        {i:"txt", n:"*.asm, Assembler Source", c:true},
        {i:"txt", n:"*.asp, aspfile", c:true},
        {i:"txt", n:"*.aspx, ASPX File", c:true},
        {i:"txt", n:"*.au3, AU3 File", c:true},
        {i:"txt", n:"*.b64, B64 File", c:true},
        {i:"txt", n:"*.bas, BAS File", c:true},
        {i:"bat", n:"*.bat, Windows Batch File", c:true},
        {i:"txt", n:"*.c, C File", c:true},
        {i:"cer", n:"*.cer, Security Certificate", c:true},
        {i:"txt", n:"*.cfg, CFG File", c:true},
        {i:"txt", n:"*.cls, CLS File", c:true}
    ],
    colorFilters: [
        {i: 1, c: true, t: "len:>260 //overlong filenames", style: "bg-[#E05B5B] text-white px-1"},
        {i: 2, c: true, t: "attr:junction", style: "text-[#8F66D6] px-1"},
        {i: 3, c: true, t: "attr:system", style: "bg-[#F4D03F] text-black px-1"},
        {i: 4, c: true, t: "attr:encrypted", style: "text-[#2ECC71] px-1"},
        {i: 5, c: true, t: "attr:compressed", style: "text-[#3498DB] px-1"},
        {i: 6, c: true, t: "ageM: <= 30 n //modified in the last 30 mins", style: "bg-[#82E05B] text-black px-1"},
        {i: 7, c: true, t: "ageM: d //modified today", style: "bg-[#82E05B] text-white px-1"},
        {i: 8, c: true, t: "attr:d", style: "text-[#B6B6B6] px-1"},
        {i: 9, c: true, t: "size:0 //empty files", style: "bg-[#FDFDFD] text-[#3498DB] px-1"},
        {i: 10, c: true, t: "B:prop:#empty:2|f-s //empty folders", style: "bg-transparent text-white px-1 border border-white"},
        {i: 11, c: true, t: "L:prop:#nosubs:2 //folders without subs", style: "text-[#3498DB] px-1"},
        {i: 12, c: true, t: "*.exe;*.bat", style: "text-[#E74C3C] px-1"},
        {i: 13, c: true, t: "*.htm;*.html;*.php", style: "text-[#3498DB] px-1"},
        {i: 14, c: true, t: "*.txt;*.ini", style: "text-[#3498DB] px-1"},
        {i: 15, c: true, t: "*.png;*.jpg;*.gif;*.bmp", style: "text-[#9B59B6] px-1"},
        {i: 16, c: true, t: "*.zip;*.rar", style: "text-[#F39C12] px-1"},
        {i: 17, c: true, t: "*.dll;*.ocx", style: "text-[#E74C3C] px-1"},
        {i: 18, c: true, t: "*.mp3;*.wav", style: "text-[#3498DB] px-1"}
    ]
};

const ConfigContext = createContext<{ config: AppConfig; updateConfig: (v: Partial<AppConfig>) => void }>({
    config: defaultConfig,
    updateConfig: () => {}
});

export const ConfigProvider = ({ children }: { children: ReactNode }) => {
    const [config, setConfig] = useState<AppConfig>(() => {
        try {
            const saved = localStorage.getItem('bndz_settings_v1');
            if (saved) return { ...defaultConfig, ...JSON.parse(saved) };
        } catch (e) {
            console.error('Failed to load settings', e);
        }
        return defaultConfig;
    });

    const updateConfig = (newVals: Partial<AppConfig>) => {
        setConfig(prev => {
            const merged = { ...prev, ...newVals };
            try {
                localStorage.setItem('bndz_settings_v1', JSON.stringify(merged));
                import('../lib/ipcBridge').then(({ IPC }) => {
                    if ('bndzIsDefaultFileManager' in newVals) {
                        IPC.setAsDefaultManager(!!newVals.bndzIsDefaultFileManager);
                    }
                    if ('bndzInShellContextMenu' in newVals) {
                        IPC.setInContextMenu(!!newVals.bndzInShellContextMenu);
                    }
                    IPC.saveSettings(merged);
                });
            } catch (e) {
                console.error('Failed to save settings', e);
            }
            return merged;
        });
    };

    return <ConfigContext.Provider value={{ config, updateConfig }}>{children}</ConfigContext.Provider>;
};

export const useAppConfig = () => useContext(ConfigContext);
