const fs = require('fs');
let code = fs.readFileSync('src/components/BNDZUI.tsx', 'utf-8');

// Replace imports
code = code.replace(/import \{ Panel, Group as PanelGroup, Separator as PanelResizeHandle \} from 'react-resizable-panels';\n/, "");

// Replace main arch
code = code.replace(
/\{(\/\* Main Split Architecture \*\/)\}\s*<PanelGroup direction="vertical" className="flex-1 overflow-hidden">\s*<Panel minSize=\{30\} className="flex flex-col min-h-0">\s*<PanelGroup direction="horizontal" className="flex flex-1 overflow-hidden min-h-0">\s*\{\/\* Sidebar Tree \*\/}\s*<Panel defaultSize=\{20\} minSize=\{10\} maxSize=\{50\} id="sidebar" order=\{1\}>\s*<div className="w-full h-full bg-\[\#111111\] overflow-y-auto py-2 shrink-0 no-scrollbar"/m,
`{/* Main Split Architecture */}
      <div className="flex flex-1 overflow-hidden min-h-0 relative">
         {/* Sidebar Tree */}
         <div className="w-[280px] shrink-0 border-r border-[#282830] bg-[#111111] overflow-y-auto py-2 no-scrollbar"`
);

// End of Sidebar Panel
code = code.replace(
/<\/div>\s*<\/Panel>\s*<PanelResizeHandle className="w-1 bg-\[\#282830\] transition-colors hover:bg-sky-500 cursor-col-resize shrink-0 z-20" \/>\s*\{\/\* Multi-Pane Content Area \*\/\}\s*<Panel className="flex-1 flex overflow-hidden bg-\[\#202020\]" minSize=\{30\} id="main" order=\{2\}>/m,
`</div>
         {/* Multi-Pane Content Area */}
         <div className="flex-1 flex flex-col overflow-hidden bg-[#202020] relative">
            <div className="flex flex-1 overflow-hidden min-h-0">`
);

// Under content area (renderPane)
code = code.replace(
/\{config\.dualPaneFeature !== false && isDualPane && panes\[1\] && \(\s*<>\s*<div className="w-1 bg-\\[\#282830\\] cursor-col-resize shrink-0 shadow-\[inset_0_0_2px_rgba\(0,0,0,0\.5\)\] z-20"><\/div>\s*\{renderPane\(panes\[1\], 1\)\}\s*<\/>\s*\)\}\s*<\/Panel>\s*\{isPreviewPanelOpen && <PanelResizeHandle className="w-1 bg-\[\#282830\] transition-colors hover:bg-sky-500 cursor-col-resize shrink-0 z-20" \/>\}\s*\{isPreviewPanelOpen && \(\s*<Panel defaultSize=\{25\} minSize=\{15\} maxSize=\{40\} id="preview" order=\{3\}>\s*<RightPreviewPanel \s*entity=\{focusedItemId \? getEntityByPath\(fileSystem, focusedItemId\) : null\} \s*\/>\s*<\/Panel>\s*\)\}\s*<\/PanelGroup>\s*<\/Panel>\s*\{isBottomPanelOpen && <PanelResizeHandle className="h-1 bg-\[\#282830\] transition-colors hover:bg-sky-500 cursor-row-resize shrink-0 z-20" \/>\}\s*\{isBottomPanelOpen && \(\s*<Panel defaultSize=\{30\} minSize=\{15\} maxSize=\{60\} id="bottom-panel" order=\{2\} className="flex min-h-0">\s*<BottomPluginPanel entity=\{focusedItemId \? getEntityByPath\(fileSystem, focusedItemId\) : null\} \/>\s*<\/Panel>\s*\)\}\s*<\/PanelGroup>/m,
`{config.dualPaneFeature !== false && isDualPane && panes[1] && (
                     <>
                        <div className="w-1 bg-[#282830] cursor-col-resize shrink-0 shadow-[inset_0_0_2px_rgba(0,0,0,0.5)] z-20"></div>
                        {renderPane(panes[1], 1)}
                     </>
                  )}
            </div>
            {isBottomPanelOpen && (
               <div className="h-[250px] shrink-0 border-t border-[#282830] flex min-h-0 relative z-20 shadow-[0_-4px_15px_rgba(0,0,0,0.3)]">
                  <BottomPluginPanel entity={focusedItemId ? getEntityByPath(fileSystem, focusedItemId) : null} />
               </div>
            )}
         </div>

         {isPreviewPanelOpen && (
            <div className="w-[300px] shrink-0 border-l border-[#282830] bg-[#111111] overflow-y-auto z-10 flex min-h-0">
               <RightPreviewPanel 
                  entity={focusedItemId ? getEntityByPath(fileSystem, focusedItemId) : null} 
               />
            </div>
         )}
      </div>`
);


fs.writeFileSync('src/components/BNDZUI.tsx', code);
