const fs = require('fs');
let code = fs.readFileSync('src/components/BNDZUI.tsx', 'utf-8');
code = code.replace(/\{expanded \? '▼' : '▶'\}/g, '{expanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}');
code = code.replace(/<span className="text-\[10px\] ml-4">▶<\/span>/g, '<ChevronRight size={14} className="ml-4 opacity-70" />');
fs.writeFileSync('src/components/BNDZUI.tsx', code);
