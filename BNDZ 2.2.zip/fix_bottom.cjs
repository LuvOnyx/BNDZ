const fs = require('fs');
let code = fs.readFileSync('src/components/BNDZUI.tsx', 'utf-8');
code = code.replace(/import RightPreviewPanel from '.\/RightPreviewPanel';/, "import RightPreviewPanel from './RightPreviewPanel';\nimport BottomPluginPanel from './BottomPluginPanel';");
fs.writeFileSync('src/components/BNDZUI.tsx', code);
