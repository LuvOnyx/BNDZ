const fs = require('fs');
let code = fs.readFileSync('src/components/BNDZUI.tsx', 'utf-8');

code = code.replace(
/\{isPreviewPanelOpen && \(\s*<>\s*<PanelResizeHandle className="w-1 bg-\[#282830\] transition-colors hover:bg-sky-500 cursor-col-resize shrink-0 z-20" \/>\s*<Panel defaultSize=\{25\} minSize=\{15\} maxSize=\{40\} id="preview" order=\{3\}>\s*<RightPreviewPanel\s*entity=\{focusedItemId \? getEntityByPath\(fileSystem, focusedItemId\) : null\}\s*\/>\s*<\/Panel>\s*<\/>\s*\)}/,
`{isPreviewPanelOpen && <PanelResizeHandle className="w-1 bg-[#282830] transition-colors hover:bg-sky-500 cursor-col-resize shrink-0 z-20" />}
               {isPreviewPanelOpen && (
                  <Panel defaultSize={25} minSize={15} maxSize={40} id="preview" order={3}>
                     <RightPreviewPanel 
                        entity={focusedItemId ? getEntityByPath(fileSystem, focusedItemId) : null} 
                     />
                  </Panel>
               )}`
);

code = code.replace(
/\{isBottomPanelOpen && \(\s*<>\s*<PanelResizeHandle className="h-1 bg-\[#282830\] transition-colors hover:bg-sky-500 cursor-row-resize shrink-0 z-20" \/>\s*<Panel defaultSize=\{30\} minSize=\{15\} maxSize=\{60\} id="bottom-panel" order=\{2\} className="flex min-h-0">\s*<BottomPluginPanel entity=\{focusedItemId \? getEntityByPath\(fileSystem, focusedItemId\) : null\} \/>\s*<\/Panel>\s*<\/>\s*\)}/,
`{isBottomPanelOpen && <PanelResizeHandle className="h-1 bg-[#282830] transition-colors hover:bg-sky-500 cursor-row-resize shrink-0 z-20" />}
         {isBottomPanelOpen && (
            <Panel defaultSize={30} minSize={15} maxSize={60} id="bottom-panel" order={2} className="flex min-h-0">
               <BottomPluginPanel entity={focusedItemId ? getEntityByPath(fileSystem, focusedItemId) : null} />
            </Panel>
         )}`
);

code = code.replace(/import \{ Panel, Group as PanelGroup, Separator as PanelResizeHandle \}/, "import { Panel, Group as PanelGroup, Separator as PanelResizeHandle }");
code = code.replace(/Terminal\s*\}/g, 'PanelBottom }');
code = code.replace(/icon=\{Terminal\}/g, 'icon={PanelBottom}');

fs.writeFileSync('src/components/BNDZUI.tsx', code);
