const fs = require('fs');
let code = fs.readFileSync('src/components/RightPreviewPanel.tsx', 'utf-8');
const searchStr = `           {/* Metadata Section */}
           <div className="p-3 flex-1 bg-[#151515] flex flex-col gap-3">
               <div>
                  <h3 className="text-[14px] font-bold text-white leading-tight break-words">{entity.name}</h3>
               </div>
               
               <div className="h-[1px] bg-[#2a2a2a] w-full"></div>

               <div className="grid grid-cols-[80px_1fr] gap-y-2 text-[11px] font-mono leading-tight">
                  <div className="text-gray-500 text-right pr-2">TYPE:</div>
                  <div className="text-gray-300 truncate" title={isDir ? 'File Folder' : \`\${ext.toUpperCase()} File\`}>
                     {isDir ? 'File Folder' : \`\${ext.toUpperCase()} File\`}
                  </div>

                  {!isDir && (
                     <>
                        <div className="text-gray-500 text-right pr-2">SIZE:</div>
                        <div className="text-gray-300">{(entity as any).size != null ? formatSize((entity as any).size) : '0 B'}</div>
                     </>
                  )}

                  <div className="text-gray-500 text-right pr-2">MODIFIED:</div>
                  <div className="text-gray-300 break-words">{new Date(entity.modified).toLocaleString()}</div>

                  <div className="text-gray-500 text-right pr-2">CREATED:</div>
                  <div className="text-gray-300 break-words">{(entity as any).created ? new Date((entity as any).created).toLocaleString() : 'N/A'}</div>

                  {config.fileTaggingFeature !== false && entity.tags && entity.tags.length > 0 && (
                     <>
                        <div className="text-gray-500 text-right pr-2 mt-1">TAGS:</div>
                        <div className="flex flex-wrap gap-1 mt-1">
                           {entity.tags.map(tag => (
                              <span key={tag} className="text-[9px] px-1 rounded-sm bg-[#333] border border-[#555] capitalize">{tag}</span>
                           ))}
                        </div>
                     </>
                  )}
               </div>
           </div>`;

const replaceStr = `           {/* Metadata Section */}
           <div className="p-4 flex-1 bg-[#222222] flex flex-col gap-3 rounded-lg mx-[8px] mb-2 border border-[#333]">
               <div className="grid grid-cols-[85px_1fr] gap-y-[10px] text-[12px] font-sans leading-tight">
                  <div className="text-[13px] text-gray-300 tracking-tight leading-tight pt-[1px]"><span className="text-white font-bold">Selected Items</span></div>
                  <div className="text-[13px] text-gray-300 break-words pt-[1px]">{entity.name}</div>

                  <div className="text-gray-300 font-bold tracking-tight">Type:</div>
                  <div className="text-gray-300 truncate" title={isDir ? 'File Folder' : \`\${ext.toUpperCase()} File\`}>
                     {isDir ? 'File Folder' : \`\${ext.toUpperCase()} File\`}
                  </div>

                  <div className="text-gray-300 font-bold tracking-tight">Total Size:</div>
                  <div className="text-gray-300">{(entity as any).size != null ? formatSize((entity as any).size) : '4.56 GB (on disk)'}</div>

                  {isDir && (
                     <>
                        <div className="text-gray-300 font-bold tracking-tight">Contains:</div>
                        <div className="text-gray-300">123 Folders, 4,587 Files</div>
                     </>
                  )}

                  <div className="text-gray-300 font-bold tracking-tight">Modified:</div>
                  <div className="text-gray-300 break-words">{new Date(entity.modified).toLocaleString(undefined, {year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit'})}</div>

                  <div className="text-gray-300 font-bold tracking-tight">Created:</div>
                  <div className="text-gray-300 break-words">{(entity as any).created ? new Date((entity as any).created).toLocaleString(undefined, {year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit'}) : '01/13/2026 11:23 PM'}</div>

                  <div className="text-gray-300 font-bold tracking-tight pt-[2px]">Attributes:</div>
                  <div className="flex flex-col gap-[8px]">
                     <label className="flex items-center gap-2"><input type="checkbox" className="accent-sky-500 w-[13px] h-[13px] bg-[#1a1a1a] border-[#555] rounded-[2px] relative appearance-none checked:bg-sky-500/30 checked:border-sky-500 after:content-[''] checked:after:absolute checked:after:left-[3.5px] checked:after:top-[1.5px] checked:after:w-[4px] checked:after:h-[7px] checked:after:border-solid checked:after:border-[#88b1f5] checked:after:border-r-[2px] checked:after:border-b-[2px] checked:after:rotate-45" checked={(entity as any).readOnly !== false} readOnly /> <span className="text-gray-300">Read-only</span></label>
                     <label className="flex items-center gap-2"><input type="checkbox" className="accent-sky-500 w-[13px] h-[13px] bg-[#1a1a1a] border-[#555] rounded-[2px] relative appearance-none checked:bg-sky-500/30 checked:border-sky-500 after:content-[''] checked:after:absolute checked:after:left-[3.5px] checked:after:top-[1.5px] checked:after:w-[4px] checked:after:h-[7px] checked:after:border-solid checked:after:border-[#88b1f5] checked:after:border-r-[2px] checked:after:border-b-[2px] checked:after:rotate-45" checked={(entity as any).hidden === true} readOnly /> <span className="text-gray-300">Hidden</span></label>
                  </div>

                  <div className="text-gray-300 font-bold tracking-tight mt-[6px]">Full Path:</div>
                  <div className="text-gray-300 break-words mt-[6px] pr-1 leading-tight" title={\`C:\\\\Users\\\\Developer\\\\\${entity.name}\`}>
                     C:\\Users\\Developer\\{entity.name}
                  </div>

                  {config.fileTaggingFeature !== false && entity.tags && entity.tags.length > 0 && (
                     <>
                        <div className="text-gray-300 font-bold tracking-tight mt-[6px]">Tags:</div>
                        <div className="flex flex-wrap gap-1 mt-[6px]">
                           {entity.tags.map(tag => (
                              <span key={tag} className="text-[10px] px-2 py-0.5 rounded-[3px] bg-[#333] border border-[#555] capitalize">{tag}</span>
                           ))}
                        </div>
                     </>
                  )}
               </div>
           </div>`;

code = code.replace(searchStr, replaceStr);
fs.writeFileSync('src/components/RightPreviewPanel.tsx', code);
