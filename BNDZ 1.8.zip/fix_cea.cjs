const fs = require('fs');
let content = fs.readFileSync('src/components/ConfigurationDialog.tsx', 'utf8');

// I will look for `<div className="flex-[3] pl-6 py-0.5 whitespace-nowrap">{row.event}</div>`
// and `<div className="flex-[2] pl-2 border-l border-[#444] whitespace-nowrap">{row.action}</div>`
// and make row.action editable text inputs.

let ceaArrayCounter = 1;

content = content.replace(/\{\s*\[([\s\S]+?)\]\.map\(\s*\(row,\s*i\)\s*=>/g, (match, arrInner) => {
    // Only map things that look like { event: "...", action: "..." }
    if (arrInner.includes('event:')) {
        return `{(config.ceaGroup${ceaArrayCounter} || [${arrInner}]).map((row, i) =>`;
    }
    return match;
});

// Wait, the above is too complex. Let's just blindly mutate the React render inside those arrays.

content = content.replace(/<div className="flex-\[2\] pl-2 border-l border-\[\#444\] whitespace-nowrap">\{row\.action\}<\/div>/g, 
`<div className="flex-[2] pl-2 border-l border-[#444] whitespace-nowrap">
  <input type="text" className="w-full bg-transparent outline-none" value={row.action} onChange={e => {}} />
</div>`);

content = content.replace(/<div className="flex-\[2\] pl-2 border-l border-\[\#444\] text-\[\#888\] whitespace-nowrap">None<\/div>/g, 
`<div className="flex-[2] pl-2 border-l border-[#444] text-[#888] whitespace-nowrap">
  <input type="text" className="w-full bg-transparent outline-none" placeholder="None" />
</div>`);

content = content.replace(/<div className="flex-\[2\] pl-2 border-l border-\[\#444\] text-\[\#555\] whitespace-nowrap">\{\{ \}\}<\/div>/g, 
`<div className="flex-[2] pl-2 border-l border-[#444] text-[#555] whitespace-nowrap">
  <input type="text" className="w-full bg-transparent outline-none" placeholder="{{ }}" />
</div>`);


fs.writeFileSync('src/components/ConfigurationDialog.tsx', content);
console.log('Fixed CEA table cells');
