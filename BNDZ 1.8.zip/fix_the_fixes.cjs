const fs = require('fs');

let content = fs.readFileSync('src/components/ConfigurationDialog.tsx', 'utf8');

// Fix \ escaping quote
content = content.replace(/"Thumbnails\\"/g, '"Thumbnails\\\\"')

content = content.replace(/\/\s*value=\{config\.unwired/g, 'value={config.unwired');
content = content.replace(/\/\s*value=\{config\.Config/g, 'value={config.Config');
content = content.replace(/\/\s*value=\{config\.readOnly/g, 'value={config.readOnly');

fs.writeFileSync('src/components/ConfigurationDialog.tsx', content);
console.log('Fixed syntax loops');
