const fs = require('fs');

let content = fs.readFileSync('src/components/ConfigurationDialog.tsx', 'utf8');

let matchCount = 0;
let counter = 1;

content = content.replace(/<input[^>]+value="([^"]+)"[^>]*readOnly[^>]*>/g, (match, val) => {
    // Only target hex codes or path strings.
    matchCount++;
    let configKey = `readOnlyConfig${counter++}`;
    
    // Make them editable inputs holding the value as default
    return match
        .replace(`value="${val}"`, `value={config.${configKey} || "${val}"} onChange={e => updateConfig({ ${configKey}: e.target.value })}`)
        .replace(/readOnly/g, '');
});

fs.writeFileSync('src/components/ConfigurationDialog.tsx', content);
console.log('Fixed ' + matchCount + ' readOnly string inputs');
