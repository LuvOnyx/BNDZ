const fs = require('fs');
let content = fs.readFileSync('src/components/SmartToolsDialog.tsx', 'utf8');

if (!content.includes('const [settings, setSettings]')) {
    content = content.replace('export default function SmartToolsDialog({ onClose }: { onClose: () => void }) {', 'export default function SmartToolsDialog({ onClose }: { onClose: () => void }) {\n  const [settings, setSettings] = React.useState<any>({});');
}

let matchCount = 0;
content = content.replace(/<Checkbox\s+label=\{((?:<span.*?>.*?<\/span>)|(?:\".*?\"))\}\s+checked=\{(true|false)\}\s*\/>/g, (match, labelGroup, boolVal) => {
    let text = labelGroup.replace(/<[^>]+>/g, '').replace(/\"/g, '');
    let keyName = text.replace(/[^a-zA-Z0-9]/g, ' ').split(' ').map((w,i) => i===0 ? w.toLowerCase() : w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join('');
    if (!keyName) keyName = 'unknownKey' + Math.floor(Math.random()*1000);
    matchCount++;
    return `<Checkbox label={${labelGroup.startsWith('"') ? labelGroup : `${labelGroup}`}} checked={settings.${keyName} ?? ${boolVal}} onChange={e => setSettings((s: any) => ({...s, [\`${keyName}\`]: e.target.checked}))} />`;
});

content = content.replace(/<Checkbox label=\"([^\"]+)\" checked=\{(true|false)\} \/>/g, (match, labelGroup, boolVal) => {
    let keyName = labelGroup.replace(/[^a-zA-Z0-9]/g, ' ').split(' ').map((w,i) => i===0 ? w.toLowerCase() : w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join('');
    matchCount++;
    return `<Checkbox label="${labelGroup}" checked={settings.${keyName} ?? ${boolVal}} onChange={e => setSettings((s: any) => ({...s, [\`${keyName}\`]: e.target.checked}))} />`;
});

content = content.replace(/<Checkbox label=\{((?:<span.*?>.*?<\/span>)|(?:\".*?\"))\}\s*\/>/g, (match, labelGroup) => {
    let text = labelGroup.replace(/<[^>]+>/g, '').replace(/\"/g, '');
    let keyName = text.replace(/[^a-zA-Z0-9]/g, ' ').split(' ').map((w,i) => i===0 ? w.toLowerCase() : w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join('');
    if (!keyName) keyName = 'unknownKey' + Math.floor(Math.random()*1000);
    matchCount++;
    return `<Checkbox label={${labelGroup.startsWith('"') ? labelGroup : `${labelGroup}`}} checked={settings.${keyName} ?? false} onChange={e => setSettings((s: any) => ({...s, [\`${keyName}\`]: e.target.checked}))} />`;
});

fs.writeFileSync('src/components/SmartToolsDialog.tsx', content);
console.log('Replaced ' + matchCount + ' checkboxes in SmartToolsDialog');
