const fs = require('fs');
let content = fs.readFileSync('src/components/ConfigurationDialog.tsx', 'utf8');

let matchCount = 0;
// 1. checked={true} or checked={false}
content = content.replace(/<Checkbox\s+label=\{((?:<span.*?>.*?<\/span>)|(?:\".*?\"))\}\s+checked=\{(true|false)\}\s*\/>/g, (match, labelGroup, boolVal) => {
    let text = labelGroup.replace(/<[^>]+>/g, '').replace(/\"/g, '');
    let keyName = text.replace(/[^a-zA-Z0-9]/g, ' ').split(' ').map((w,i) => i===0 ? w.toLowerCase() : w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join('');
    if (!keyName) keyName = 'unknownKey' + Math.floor(Math.random()*1000);
    matchCount++;
    return `<Checkbox label={${labelGroup.startsWith('"') ? labelGroup : `${labelGroup}`}} checked={config.${keyName} ?? ${boolVal}} onChange={e => updateConfig({ ${keyName}: e.target.checked })} />`;
});

// 2. checked=true/false with simple string
content = content.replace(/<Checkbox label=\"([^\"]+)\" checked=\{(true|false)\} \/>/g, (match, labelGroup, boolVal) => {
    let keyName = labelGroup.replace(/[^a-zA-Z0-9]/g, ' ').split(' ').map((w,i) => i===0 ? w.toLowerCase() : w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join('');
    matchCount++;
    return `<Checkbox label="${labelGroup}" checked={config.${keyName} ?? ${boolVal}} onChange={e => updateConfig({ ${keyName}: e.target.checked })} />`;
});

// 3. no checked prop
content = content.replace(/<Checkbox label=\{((?:<span.*?>.*?<\/span>)|(?:\".*?\"))\}\s*\/>/g, (match, labelGroup) => {
    let text = labelGroup.replace(/<[^>]+>/g, '').replace(/\"/g, '');
    let keyName = text.replace(/[^a-zA-Z0-9]/g, ' ').split(' ').map((w,i) => i===0 ? w.toLowerCase() : w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join('');
    if (!keyName) keyName = 'unknownKey' + Math.floor(Math.random()*1000);
    matchCount++;
    return `<Checkbox label={${labelGroup.startsWith('"') ? labelGroup : `${labelGroup}`}} checked={config.${keyName} ?? false} onChange={e => updateConfig({ ${keyName}: e.target.checked })} />`;
});

fs.writeFileSync('src/components/ConfigurationDialog.tsx', content);
console.log('Replaced ' + matchCount + ' checkboxes');
