/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { VirtualDirectory, FSEntity, VirtualFile } from "../types";

// Helper ISO strings
const dateNow = () => new Date().toISOString();
const dateAgo = (days: number) => {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString();
};

export const initialTags = [
  { name: "urgent", color: "#ef4444", label: "Urgent 🔴" },
  { name: "progress", color: "#3b82f6", label: "In Progress 🔵" },
  { name: "archive", color: "#10b981", label: "Reference 🟢" },
  { name: "csharp", color: "#a855f7", label: "C# Solution 🟣" },
  { name: "raw", color: "#f59e0b", label: "Draft 🟡" }
];

export function createInitialFileSystem(): VirtualDirectory {
  return {
    id: "root-dir",
    name: "C:",
    type: "directory",
    tags: [],
    created: dateAgo(20),
    modified: dateAgo(1),
    children: {
      "Users": {
        id: "users-dir",
        name: "Users",
        type: "directory",
        tags: [],
        created: dateAgo(20),
        modified: dateAgo(5),
        children: {
          "Developer": {
            id: "dev-dir",
            name: "Developer",
            type: "directory",
            tags: [],
            created: dateAgo(20),
            modified: dateAgo(1),
            children: {
              "BNDZ_CSharp_Windows_App": {
                id: "project-dir",
                name: "BNDZ_CSharp_Windows_App",
                type: "directory",
                tags: ["csharp"],
                created: dateAgo(10),
                modified: dateAgo(1),
                children: {
                  "BNDZ.sln": {
                    id: "sln-file",
                    name: "BNDZ.sln",
                    type: "file",
                    extension: "sln",
                    size: 940,
                    tags: ["csharp"],
                    created: dateAgo(10),
                    modified: dateAgo(3),
                    content: `Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio Version 17
VisualStudioVersion = 17.8.34309.116
MinimumVisualStudioVersion = 10.0.40219.1
Project("{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}") = "BNDZ.Core", "BNDZ.Core\\BNDZ.Core.csproj", "{C4B2E1D2-A9F3-4318-912E-DFCDFE19C281}"
Project("{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}") = "BNDZ.UI", "BNDZ.UI\\BNDZ.UI.csproj", "{D18CE281-BFCE-4D4F-8812-3D718BC1E14E}"
Global
\tGlobalSection(SolutionConfigurationPlatforms) = preSolution
\t\tDebug|Any CPU = Debug|Any CPU
\t\tRelease|Any CPU = Release|Any CPU
\tEndGlobalSection
EndGlobal`
                  },
                  "BNDZ.Core": {
                    id: "core-dir",
                    name: "BNDZ.Core",
                    type: "directory",
                    tags: ["csharp"],
                    created: dateAgo(10),
                    modified: dateAgo(2),
                    children: {
                      "Program.cs": {
                        id: "program-cs",
                        name: "Program.cs",
                        type: "file",
                        extension: "cs",
                        size: 2150,
                        tags: ["csharp"],
                        created: dateAgo(10),
                        modified: dateAgo(1),
                        content: `using System;
using System.IO;
using System.Windows.Forms;
using BNDZ.Core.Services;

namespace BNDZ.Core
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the C# Windows File Explorer application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            // Initialize Core Registry for Customizable Themes and Paths
            Logger.Info("Bootstrapping BNDZ Core Layer...");
            var exploreEngine = new ExplorerEngine("C:\\\\");
            
            // Start main core loops for batched indexes
            exploreEngine.InitializeIndexAsync().GetAwaiter().GetResult();
            
            // Run Windows Forms Application entry Form
            Application.Run(new MainWindow(exploreEngine));
        }
    }
}`
                      },
                      "ExplorerEngine.cs": {
                        id: "engine-cs",
                        name: "ExplorerEngine.cs",
                        type: "file",
                        extension: "cs",
                        size: 4890,
                        tags: ["csharp", "progress"],
                        created: dateAgo(9),
                        modified: dateAgo(1),
                        content: `using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace BNDZ.Core.Services
{
    public class ExplorerEngine
    {
        private string _activeDirectory;
        private Dictionary<string, List<string>> _customTags;

        public ExplorerEngine(string defaultRoot)
        {
            _activeDirectory = defaultRoot;
            _customTags = new Dictionary<string, List<string>>();
        }

        public async Task InitializeIndexAsync()
        {
            // Crawl directory details as a background task
            await Task.Run(() => {
                Logger.Info($"Scanning directory branches under {_activeDirectory}");
                // Index cached tags database for faster AI retrieval
            });
        }

        public List<FileSystemInfo> GetDirectoryContents(string path)
        {
            if (!Directory.Exists(path))
                throw new DirectoryNotFoundException("Path doesn't exist.");

            var items = new List<FileSystemInfo>();
            var dir = new DirectoryInfo(path);
            items.AddRange(dir.GetDirectories());
            items.AddRange(dir.GetFiles());
            return items;
        }

        public void AssignTag(string filePath, string tag)
        {
            if (!_customTags.ContainsKey(filePath))
                _customTags[filePath] = new List<string>();

            if (!_customTags[filePath].Contains(tag))
            {
                _customTags[filePath].Add(tag);
                Logger.Info($"File '{filePath}' tagged with '{tag}' successfully.");
            }
        }
    }
}`
                      },
                      "App.config": {
                        id: "app-config",
                        name: "App.config",
                        type: "file",
                        extension: "config",
                        size: 610,
                        tags: ["archive"],
                        created: dateAgo(10),
                        modified: dateAgo(10),
                        content: `<?xml version="1.0" encoding="utf-8" ?>
<configuration>
    <startup> 
        <supportedRuntime version="v4.0" sku=".NETFramework,Version=v4.8" />
    </startup>
    <appSettings>
        <add key="EnableThemeCustomization" value="true" />
        <add key="DualPaneSplitRatio" value="0.5" />
        <add key="InteractiveAISearch" value="active" />
        <add key="DefaultWorkspace" value="C:\\Developer\\BNDZ_CSharp_Windows_App" />
    </appSettings>
</configuration>`
                      }
                    }
                  },
                  "BNDZ.UI": {
                    id: "ui-dir",
                    name: "BNDZ.UI",
                    type: "directory",
                    tags: ["csharp"],
                    created: dateAgo(10),
                    modified: dateAgo(1),
                    children: {
                      "MainWindow.xaml": {
                        id: "main-xaml",
                        name: "MainWindow.xaml",
                        type: "file",
                        extension: "xaml",
                        size: 3410,
                        tags: ["csharp"],
                        created: dateAgo(9),
                        modified: dateAgo(2),
                        content: `<Window x:Class="BNDZ.UI.MainWindow"
        xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="BNDZ - Custom Workspace Client" Height="700" Width="1100"
        Background="#18181D" Foreground="#E2E2EC">
    <Grid>
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/> <!-- Main Menu MenuBar -->
            <RowDefinition Height="Auto"/> <!-- Address/Utility Bar -->
            <RowDefinition Height="*"/>    <!-- Split Dual Explorer Panes -->
            <RowDefinition Height="Auto"/> <!-- Status Analytics Footer -->
        </Grid.RowDefinitions>

        <StackPanel Grid.Row="0" Orientation="Horizontal" Background="#121215" Padding="5">
            <Menu Background="Transparent" Foreground="#E2E2EC">
                <MenuItem Header="_File" />
                <MenuItem Header="_Edit" />
                <MenuItem Header="_View" />
                <MenuItem Header="_AI Services" />
                <MenuItem Header="_Folder Tools" />
            </Menu>
        </StackPanel>

        <TextBox Grid.Row="1" x:Name="AddressBar" Margin="8,4" Height="28" 
                 Background="#1E1E24" Foreground="#E2E2EC" BorderBrush="#2D2D35"
                 VerticalContentAlignment="Center" Padding="4,0"/>

        <Grid Grid.Row="2">
            <Grid.ColumnDefinitions>
                <ColumnDefinition Width="250"/> <!-- Sidebar tree -->
                <ColumnDefinition Width="5"/>   <!-- Splitter -->
                <ColumnDefinition Width="*"/>   <!-- Dual Workspace Panes -->
            </Grid.ColumnDefinitions>

            <!-- Navigation Tree -->
            <TreeView Grid.Column="0" Background="#121215" BorderBrush="Transparent" Margin="2,4"/>

            <GridSplitter Grid.Column="1" HorizontalAlignment="Stretch" Background="#282830"/>

            <!-- Left and Right explorer panels -->
            <Grid Grid.Column="2">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="*"/>
                </Grid.ColumnDefinitions>
                
                <ContentControl Grid.Column="0" x:Name="PaneLeft"/>
                <GridSplitter Grid.Column="1" Width="4" HorizontalAlignment="Stretch" Background="#202025"/>
                <ContentControl Grid.Column="2" x:Name="PaneRight"/>
            </Grid>
        </Grid>
    </Grid>
</Window>`
                      },
                      "MainWindow.xaml.cs": {
                        id: "main-xaml-cs",
                        name: "MainWindow.xaml.cs",
                        type: "file",
                        extension: "cs",
                        size: 3040,
                        tags: ["csharp"],
                        created: dateAgo(9),
                        modified: dateAgo(3),
                        content: `using System;
using System.Windows;
using BNDZ.Core.Services;

namespace BNDZ.UI
{
    public partial class MainWindow : Window
    {
        private readonly ExplorerEngine _engine;

        public MainWindow(ExplorerEngine engine)
        {
            InitializeComponent();
            _engine = engine;
            this.Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            AddressBar.Text = "C:\\\\Developer\\\\BNDZ_CSharp_Windows_App";
            Logger.Success("Dual-pane BNDZ UI Loaded with Fluent styling.");
        }
    }
}`
                      }
                    }
                  },
                  "Unorganized_Downloads": {
                    id: "unorganized-dir",
                    name: "Unorganized_Downloads",
                    type: "directory",
                    tags: ["raw"],
                    created: dateAgo(5),
                    modified: dateAgo(1),
                    children: {
                      "raw_data_332.log": {
                        id: "raw-log",
                        name: "raw_data_332.log",
                        type: "file",
                        extension: "log",
                        size: 4120,
                        tags: ["raw"],
                        created: dateAgo(3),
                        modified: dateAgo(3),
                        content: `[09:12:01] INF INIT: Booting thread pool context.
[09:12:05] WRN IO: System partition C:\\ lacks secondary index caches.
[09:12:12] INF NET: Requesting DNS handshake via 1.1.1.1.
[09:14:10] INF API: Handshake success. Server latency: 45ms.
[09:15:20] ERR TRACE: Object reference null exception at BNDZ.Core.ExplorerEngine.CrawlAsync()\n   at System.Threading.Tasks.Task.Execute()`
                      },
                      "temp_draft_winforms.cs": {
                        id: "draft-cs",
                        name: "temp_draft_winforms.cs",
                        type: "file",
                        extension: "cs",
                        size: 1100,
                        tags: ["raw"],
                        created: dateAgo(2),
                        modified: dateAgo(2),
                        content: `// MOCK DRAFT CODE
using System.Windows.Forms;
namespace DraftApp
{
    public class SimpleForm : Form
    {
        public SimpleForm()
        {
            this.Text = "Temporary WinForms Panel";
            var btn = new Button { Text = "Ping AI" };
            btn.Click += (s, e) => MessageBox.Show("AI ping response default draft value!");
            this.Controls.Add(btn);
        }
    }
}`
                      },
                      "untitled_text.txt": {
                        id: "untitled-txt",
                        name: "untitled_text.txt",
                        type: "file",
                        extension: "txt",
                        size: 140,
                        tags: [],
                        created: dateAgo(4),
                        modified: dateAgo(4),
                        content: `Prepare slides for C# solution workspace.
Remember:
- Implement batch renaming logic
- Enable tag based group layouts
- Add regex search parser`
                      },
                      "invoice_draft_final.docx": {
                        id: "invoice-doc",
                        name: "invoice_draft_final.docx",
                        type: "file",
                        extension: "docx",
                        size: 12400,
                        tags: ["urgent"],
                        created: dateAgo(1),
                        modified: dateAgo(1),
                        content: `MOCK DOCX PROTOCOL HEADER
Invoice #2026-X091
Issued on: 2026-05-30
Billed To: Antigravity Coding Solutions
Total Amount: $4,500.00 USD
Deliverables: Custom Explorer File System shell API in C# for Windows client.`
                      },
                      "screenshot_05-31-2026.png": {
                        id: "screnshot-png",
                        name: "screenshot_05-31-2026.png",
                        type: "file",
                        extension: "png",
                        size: 345000,
                        tags: [],
                        created: dateAgo(1),
                        modified: dateAgo(1),
                        content: `[Binary Image Data Representation: Dual pane mockup of BNDZ Windows File Manager]`
                      },
                      "design_sketch_xy.png": {
                        id: "sketch-png",
                        name: "design_sketch_xy.png",
                        type: "file",
                        extension: "png",
                        size: 182000,
                        tags: [],
                        created: dateAgo(2),
                        modified: dateAgo(2),
                        content: `[Binary Image Data Representation: Hand-drawn design mapping coordinates for horizontal resizers and folder syncing buttons]`
                      },
                      "retro_theme_sound.mp3": {
                        id: "retro-mp3",
                        name: "retro_theme_sound.mp3",
                        type: "file",
                        extension: "mp3",
                        size: 2400000,
                        tags: [],
                        created: dateAgo(3),
                        modified: dateAgo(3),
                        content: `[Audio Wave Data representation: Synthesizer loop for nostalgic Windows 95 startup chime remix]`
                      },
                      "duplicate_readme_1.txt": {
                        id: "dup-readme-1",
                        name: "duplicate_readme_1.txt",
                        type: "file",
                        extension: "txt",
                        size: 610,
                        tags: [],
                        created: dateAgo(5),
                        modified: dateAgo(5),
                        content: `BNDZ - Interactive Testing Environment.
Created to assist in building the smart C# workspace orchestrator.
Use the cleaner panel to discover duplicate copies and empty directories.`
                      },
                      "readme_duplicate.txt": {
                        id: "dup-readme-2",
                        name: "readme_duplicate.txt",
                        type: "file",
                        extension: "txt",
                        size: 610,
                        tags: [],
                        created: dateAgo(5),
                        modified: dateAgo(5),
                        content: `BNDZ - Interactive Testing Environment.
Created to assist in building the smart C# workspace orchestrator.
Use the cleaner panel to discover duplicate copies and empty directories.`
                      },
                      "empty_cache_folder": {
                        id: "empty-dir",
                        name: "empty_cache_folder",
                        type: "directory",
                        tags: [],
                        created: dateAgo(5),
                        modified: dateAgo(5),
                        children: {}
                      },
                      "stale_logs": {
                        id: "stale-logs-dir",
                        name: "stale_logs",
                        type: "directory",
                        tags: [],
                        created: dateAgo(4),
                        modified: dateAgo(4),
                        children: {
                          "log_old.txt": {
                            id: "log-old-txt",
                            name: "log_old.txt",
                            type: "file",
                            extension: "txt",
                            size: 85,
                            tags: [],
                            created: dateAgo(5),
                            modified: dateAgo(5),
                            content: `Older tracking indices completed successfully. Cache cleared.`
                          }
                        }
                      }
                    }
                  },
                  "Backups": {
                    id: "backups-dir",
                    name: "Backups",
                    type: "directory",
                    tags: ["archive"],
                    created: dateAgo(10),
                    modified: dateAgo(1),
                    children: {
                      "Sync_Destination": {
                        id: "sync-dest-dir",
                        name: "Sync_Destination",
                        type: "directory",
                        tags: ["archive"],
                        created: dateAgo(10),
                        modified: dateAgo(5),
                        children: {
                          "readme_backup.txt": {
                            id: "readme-backup",
                            name: "readme_backup.txt",
                            type: "file",
                            extension: "txt",
                            size: 151,
                            tags: ["archive"],
                            created: dateAgo(5),
                            modified: dateAgo(5),
                            content: `Initial snapshot index backup details.`
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  };
}

// TRAVERSAL UTILITIES

// Get entity at absolute path (e.g. "/Users/Developer/BNDZ_CSharp_Windows_App")
// Absolute path format is always relative to root "C:" which represents /
export function getEntityByPath(root: VirtualDirectory, pathStr: string): FSEntity | null {
  if (pathStr === "/" || pathStr === "/C:") {
    return root;
  }

  // Clean path string
  let parts = pathStr.split("/").filter(p => p !== "");
  if (parts.length > 0 && parts[0] === "C:") {
    parts.shift(); // remove C: so we index child paths correctly
  }

  let current: FSEntity = root;

  for (let part of parts) {
    if (current.type !== "directory") return null;
    let next = current.children[part];
    if (!next) return null;
    current = next;
  }

  return current;
}

// Recursively traverse to find all files and folders
export function getAllFilesRecursive(
  node: FSEntity,
  currentPath: string = "/"
): { path: string; file: VirtualFile }[] {
  let list: { path: string; file: VirtualFile }[] = [];
  
  if (node.type === "file") {
    list.push({ path: currentPath, file: node });
  } else {
    const parentPath = currentPath === "/" ? "" : currentPath;
    for (const key of Object.keys(node.children)) {
      list.push(...getAllFilesRecursive(node.children[key], `${parentPath}/${node.name}`));
    }
  }
  return list;
}

// Generate structural flattened directory entries
export function getDirContents(root: VirtualDirectory, pathStr: string): FSEntity[] {
  const entity = getEntityByPath(root, pathStr);
  if (!entity || entity.type !== "directory") {
    return [];
  }
  return Object.values(entity.children);
}

// Deep clone helper
export function deepClone<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj));
}

// In-place updates helper targeting file paths
export function updateFileSystem(
  root: VirtualDirectory,
  pathStr: string,
  updater: (parent: VirtualDirectory) => void
): VirtualDirectory {
  const cloned = deepClone(root);
  let parts = pathStr.split("/").filter(p => p !== "");
  if (parts.length > 0 && parts[0] === "C:") {
    parts.shift();
  }

  let current = cloned;
  for (let part of parts) {
    if (current.children[part] && current.children[part].type === "directory") {
      current = current.children[part] as VirtualDirectory;
    } else {
      // Path folder not found, cannot apply updater
      return root;
    }
  }

  updater(current);
  return cloned;
}
