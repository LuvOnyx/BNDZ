/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface VirtualFile {
  id: string;
  name: string;
  type: "file";
  extension: string;
  size: number; // in bytes
  content: string;
  tags: string[];
  created: string; // ISO date
  modified: string; // ISO date
  isSelected?: boolean;
  iconBase64?: string;
  typeDescription?: string;
}

export interface VirtualDirectory {
  id: string;
  name: string;
  type: "directory";
  children: { [name: string]: VirtualFile | VirtualDirectory };
  tags: string[];
  created: string; // ISO date
  modified: string; // ISO date
  iconBase64?: string;
  typeDescription?: string;
}

export type FSEntity = VirtualFile | VirtualDirectory;

export interface FileSystemState {
  root: VirtualDirectory;
}

export interface ExplorerTab {
  id: string;
  name: string;
  currentPath: string; // absolute path starting with /
  history: string[];   // navigation history
  historyIndex: number;// index in history
  searchQuery: string;
  selectedIds: string[];
  sortBy: "name" | "size" | "type" | "modified";
  sortOrder: "asc" | "desc";
  viewMode: "details" | "list" | "smallGrid" | "largeGrid";
}

export interface ThemeConfig {
  id: string;
  name: string;
  bgColor: string;       // e.g., "bg-[#1e1e24]"
  paneBgColor: string;   // e.g., "bg-[#121215]"
  treeBgColor: string;   // e.g., "bg-[#18181d]"
  textColor: string;     // e.g., "text-[#e2e2ec]"
  accentColor: string;   // e.g., "#d946ef" / bg-[accent]
  accentBg: string;      // e.g., "bg-fuchsia-600/20 text-fuchsia-400 border-fuchsia-500"
  sidebarAccentBg: string; // e.g., "hover:bg-fuchsia-500/10 hover:text-fuchsia-300"
  borderColor: string;   // e.g., "border-zinc-800"
  tabActiveColor: string;// e.g., "bg-[#1e1e24] border-t-2 border-t-fuchsia-500"
  panelHeaderBg: string; // e.g., "bg-[#15151a]"
}

export interface TagMetadata {
  name: string;
  color: string; // CSS color string or Tailwind color
  label: string;
}

export interface SyncProfile {
  source: string;
  target: string;
  syncedAt?: string;
  syncType: "one-way" | "two-way";
}

export interface DriveInfo {
  name: string;
  label: string;
  totalSpace: number;
  freeSpace: number;
}

export interface ShortcutInfo {
  name: string;
  path: string;
  icon: 'desktop' | 'documents' | 'downloads' | 'profile';
}
