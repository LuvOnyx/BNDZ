/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import BNDZUI from './components/BNDZUI';
import ConfigurationDialog from './components/ConfigurationDialog';
import { ConfigProvider } from './data/configContext';

export default function App() {
  const [configOpen, setConfigOpen] = useState(false);

  return (
    <ConfigProvider>
      <div className="w-full h-screen overflow-hidden bg-[#1e1e1e] text-[#e0e0e0]">
        <BNDZUI onOpenConfig={() => setConfigOpen(true)} />
        {configOpen && (
           <ConfigurationDialog onClose={() => setConfigOpen(false)} />
        )}
      </div>
    </ConfigProvider>
  );
}
