import { Checkbox } from './ui/checkbox';
import React, { useState } from 'react';
import { Bot, Wand2, Sparkles, Tags, X, Check, ArrowRight } from 'lucide-react';
import { IPC, RenameOperation } from '../lib/ipcBridge';

export default function SmartToolsDialog({ 
  onClose, 
  selectedFiles = [], 
  onApplyRename 
}: { 
  onClose: () => void, 
  selectedFiles: any[], 
  onApplyRename?: (ops: RenameOperation[]) => void 
}) {
  const [activeTab, setActiveTab] = useState<'rename' | 'tag' | 'organize'>('rename');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [renameInstruction, setRenameInstruction] = useState(() => selectedFiles.length === 1 ? selectedFiles[0].name : "");
  const [error, setError] = useState<string | null>(null);
  const [previewChangesBeforeMovingFiles, setPreviewChangesBeforeMovingFiles] = useState(true);

  const handleExecuteAI = async () => {
    setLoading(true);
    setResult(null);
    setError(null);
    try {
      if (activeTab === 'rename') {
         const names = selectedFiles.map(f => f.name);
         if (names.length === 0) throw new Error("No files selected to rename. Please select files first.");
         
         // Calls Native C# Bridge if available, otherwise routes to Node JS API fallback
         const ops = await IPC.aiBatchRename(names, renameInstruction);
         setResult({ 
           type: 'rename', 
           operations: ops, 
           message: `Successfully structured new naming scheme for ${ops.length} items.` 
         });
      } else {
         setTimeout(() => {
            setLoading(false);
            setResult({ type: 'generic', message: `AI operations completed successfully.` });
         }, 1500);
      }
    } catch (e: any) {
       setError(e.message || "Failed to execute AI request.");
    } finally {
       if (activeTab !== 'tag' && activeTab !== 'organize') setLoading(false);
    }
  };

  return (
    <div className="w-[600px] bg-[#1e1e1e] border border-[#555] shadow-2xl flex flex-col font-sans select-none overflow-hidden rounded-md">
      {/* Title Bar */}
      <div className="bg-[#1a1a1a] border-b border-[#333] px-3 py-2 flex items-center justify-between">
         <div className="text-[13px] text-white flex items-center gap-2 font-medium">
            <Sparkles size={14} className="text-purple-400" />
            AI Smart Operations
         </div>
         <button className="hover:bg-red-500 w-6 h-6 flex items-center justify-center rounded text-gray-400 hover:text-white" onClick={onClose}>
            <X size={14} />
         </button>
      </div>

      <div className="flex border-b border-[#333] bg-[#111]">
        <button 
          className={`flex-1 py-2 text-[12px] flex items-center justify-center gap-2 ${activeTab === 'rename' ? 'bg-[#1e1e1e] border-t-2 border-purple-500 text-white' : 'text-gray-400 hover:bg-[#222]'}`}
          onClick={() => setActiveTab('rename')}
        >
          <Wand2 size={14} /> Smart Rename
        </button>
        <button 
          className={`flex-1 py-2 text-[12px] flex items-center justify-center gap-2 ${activeTab === 'tag' ? 'bg-[#1e1e1e] border-t-2 border-green-500 text-white' : 'text-gray-400 hover:bg-[#222]'}`}
          onClick={() => setActiveTab('tag')}
        >
          <Tags size={14} /> Auto-Tagging
        </button>
        <button 
          className={`flex-1 py-2 text-[12px] flex items-center justify-center gap-2 ${activeTab === 'organize' ? 'bg-[#1e1e1e] border-t-2 border-blue-500 text-white' : 'text-gray-400 hover:bg-[#222]'}`}
          onClick={() => setActiveTab('organize')}
        >
          <Bot size={14} /> Workspace Sync
        </button>
      </div>

      <div className="p-6 text-[12px] text-gray-300 flex-1 min-h-[300px]">
         {activeTab === 'rename' && (
          <div className="space-y-4">
            <p>Use Gemini AI to semantically rename your files based on their content and current naming conventions.</p>
            <div className="bg-[#111] p-3 border border-[#333] rounded">
              <label className="block text-gray-400 mb-1">Target Pattern/Instructions (Optional)</label>
              <input type="text" className="w-full bg-[#1e1e1e] border border-[#555] rounded px-2 py-1 text-white" 
                placeholder="e.g. 'Standardize to camelCase without special characters'" 
                value={renameInstruction} 
                onChange={e => setRenameInstruction(e.target.value)} 
                autoFocus
                onFocus={e => e.target.select()}
              />
            </div>
            <div className="text-gray-400">Items selected: <strong className="text-white">{selectedFiles.length}</strong> items waiting to be scanned</div>
          </div>
        )}

        {activeTab === 'tag' && (
          <div className="space-y-4">
            <p>Automatically ingest file contents (reports, logs, code) and apply semantic tags to unify your workflow.</p>
            <div className="flex gap-2">
              <span className="bg-purple-500/20 text-purple-400 px-2 py-1 rounded border border-purple-500/30">#csharp</span>
              <span className="bg-red-500/20 text-red-400 px-2 py-1 rounded border border-red-500/30">#urgent</span>
              <span className="bg-green-500/20 text-green-400 px-2 py-1 rounded border border-green-500/30">+ Add Dictionary</span>
            </div>
          </div>
        )}

        {activeTab === 'organize' && (
          <div className="space-y-4">
            <p>De-clutter your directory. The AI will group similar files, extract archives, and move stranded documents into appropriate localized folders.</p>
            <label className="flex items-center gap-2 cursor-pointer mt-2">
              <input type="checkbox" className="accent-blue-500" checked={previewChangesBeforeMovingFiles} onChange={e => setPreviewChangesBeforeMovingFiles(e.target.checked)} />
              <span>Preview changes before moving files</span>
            </label>
          </div>
        )}

        {loading && (
          <div className="mt-6 flex flex-col items-center justify-center text-purple-400 gap-2">
            <div className="w-6 h-6 border-2 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
            <span>Analyzing Request via Native AI Bridge...</span>
          </div>
        )}

        {error && (
          <div className="mt-6 p-3 bg-red-500/10 border border-red-500/30 text-red-400 rounded">
            {error}
          </div>
        )}

        {result && result.type === 'rename' && (
          <div className="mt-4 flex flex-col gap-2">
            <div className="p-2 bg-green-500/10 border border-green-500/30 text-green-400 rounded flex items-center gap-2">
              <Check size={16} />
              {result.message}
            </div>
            <div className="max-h-[150px] overflow-y-auto w-full bg-[#111] p-2 rounded border border-[#333]">
               {result.operations.map((op: any, i: number) => (
                  <div key={i} className="flex items-center gap-2 py-1 border-b border-[#222] last:border-0 text-gray-300">
                     <span className="text-gray-500 flex-1 truncate">{op.originalName}</span>
                     <ArrowRight size={12} className="text-purple-400 shrink-0" />
                     <span className="text-white flex-1 truncate font-medium" title={op.reason || ''}>{op.newName}</span>
                  </div>
               ))}
            </div>
            <div className="flex justify-end mt-2">
               <button 
                 onClick={() => { onApplyRename?.(result.operations); onClose(); }} 
                 className="bg-green-600 hover:bg-green-500 text-white px-3 py-1 rounded border border-green-500 flex items-center gap-2 font-medium"
               >
                 <Check size={14} /> Apply to Files
               </button>
            </div>
          </div>
        )}

        {result && result.type === 'generic' && (
          <div className="mt-6 p-3 bg-green-500/10 border border-green-500/30 text-green-400 rounded flex items-center gap-2">
            <Check size={16} />
            {result.message}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="bg-[#1a1a1a] border-t border-[#333] px-4 py-3 flex justify-end gap-2">
         <button className="px-4 py-1.5 text-[12px] bg-[#333] hover:bg-[#444] text-white rounded border border-[#555]" onClick={onClose}>
           Cancel
         </button>
         <button 
           className="px-4 py-1.5 text-[12px] bg-purple-600 hover:bg-purple-500 text-white rounded border border-purple-500 flex items-center gap-2 disabled:opacity-50"
           onClick={handleExecuteAI}
           disabled={loading || (activeTab === 'rename' && selectedFiles.length === 0)}
         >
           <Sparkles size={14} /> Execute AI Routine
         </button>
      </div>
    </div>
  );
}
