import React, { useMemo } from 'react';
import { useAppConfig } from '../data/configContext';
import { FSEntity } from '../types';
import { File, Folder, Image, Music, FileText, Code, Settings, PlayCircle } from 'lucide-react';

interface RightPreviewPanelProps {
  entity: FSEntity | null;
}

export default function RightPreviewPanel({ entity }: RightPreviewPanelProps) {
  const { config } = useAppConfig();
  
  if (!entity) {
    return (
      <div className="w-[300px] border-l border-[#333] bg-[#1a1a1a] flex flex-col items-center justify-center text-[#666] p-4 shrink-0 shadow-[-4px_0_15px_rgba(0,0,0,0.2)] z-10 select-none">
        <File size={48} className="mb-4 opacity-20" />
        <span className="text-[13px]">Select a file to preview</span>
      </div>
    );
  }

  const isDir = entity.type === 'directory';
  const ext = !isDir ? (entity as any).extension?.toLowerCase() || '' : '';
  const isImage = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'].includes(ext);
  const isAudio = ['mp3', 'wav', 'ogg', 'flac'].includes(ext);
  const isVideo = ['mp4', 'mkv', 'avi', 'mov'].includes(ext);
  const isTextRaw = ['txt', 'md', 'log', 'csv'].includes(ext);
  const isCode = ['js', 'ts', 'jsx', 'tsx', 'cs', 'json', 'html', 'css', 'xml'].includes(ext);

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024, sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getPreviewIcon = () => {
     if (isDir) return <Folder size={64} className="text-[#dcb67a]" />;
     if (isImage) return <Image size={64} className="text-purple-400" />;
     if (isAudio) return <Music size={64} className="text-sky-400" />;
     if (isCode) return <Code size={64} className="text-emerald-400" />;
     if (isTextRaw) return <FileText size={64} className="text-amber-400" />;
     return <File size={64} className="text-gray-400" />;
  };

  const showThumb = config.previewAsThumbnail;
  const zoom = config.selectConfig || "100%";

  return (
    <div className="w-[300px] border-l border-[#333] bg-[#151515] flex flex-col shrink-0 shadow-[-4px_0_15px_rgba(0,0,0,0.2)] z-10 overflow-hidden">
       {/* Toolbar / Header */}
       <div className="bg-[#1e1e1e] border-b border-[#333] px-2 py-1.5 flex justify-between items-center z-10 shrink-0">
          <span className="text-[11px] font-bold text-gray-300 uppercase tracking-wider">Preview</span>
          <div className="flex gap-1">
             {/* dummy actions */}
             <div className="p-1 hover:bg-[#333] rounded cursor-pointer"><Settings size={12} className="text-gray-400" /></div>
          </div>
       </div>
       
       <div className="flex-1 overflow-y-auto no-scrollbar relative flex flex-col">
           {/* Preview Area */}
           <div className={`w-full min-h-[220px] bg-[#0c0c0c] border-b border-[#222] flex items-center justify-center p-4 relative ${showThumb ? 'pattern-checkerboard' : ''}`}>
               {/* Decorative backdrop */}
               <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-10 pointer-events-none"></div>
               
               <div className={`transition-all ${zoom === "Fit to width" ? "scale-[1.2]" : zoom === "Fit to window" ? "w-full h-full p-2" : "scale-100"}`}>
                   {isImage ? (
                      <div className="flex flex-col items-center">
                          {getPreviewIcon()}
                          <span className="text-[10px] text-gray-500 mt-2 font-mono">[Image Preview Placeholder]</span>
                      </div>
                   ) : isCode || isTextRaw ? (
                      <div className="flex flex-col items-center">
                          {getPreviewIcon()}
                          <span className="text-[10px] text-gray-500 mt-2 font-mono p-4 text-center">
                             Some line of code or text would appear here natively via syntax highlighter...
                          </span>
                      </div>
                   ) : (
                      getPreviewIcon()
                   )}
               </div>
               
               {/* Overlay labels */}
               <div className="absolute bottom-2 right-2 flex gap-1">
                  {isDir ? (
                     <span className="bg-black/80 text-[#dcb67a] text-[9px] px-1.5 py-0.5 rounded uppercase font-bold border border-[#dcb67a]/30">DIR</span>
                  ) : ext && (
                     <span className="bg-black/80 text-white text-[9px] px-1.5 py-0.5 rounded uppercase font-bold border border-white/20">{ext}</span>
                  )}
               </div>
           </div>

           {/* Metadata Section */}
           <div className="p-3 flex-1 bg-[#151515] flex flex-col gap-3">
               <div>
                  <h3 className="text-[14px] font-bold text-white leading-tight break-words">{entity.name}</h3>
               </div>
               
               <div className="h-[1px] bg-[#2a2a2a] w-full"></div>

               <div className="grid grid-cols-[80px_1fr] gap-y-2 text-[11px] font-mono leading-tight">
                  <div className="text-gray-500 text-right pr-2">TYPE:</div>
                  <div className="text-gray-300 truncate" title={isDir ? 'File Folder' : `${ext.toUpperCase()} File`}>
                     {isDir ? 'File Folder' : `${ext.toUpperCase()} File`}
                  </div>

                  {!isDir && (
                     <>
                        <div className="text-gray-500 text-right pr-2">SIZE:</div>
                        <div className="text-gray-300">{(entity as any).size != null ? formatSize((entity as any).size) : '0 B'}</div>
                     </>
                  )}

                  <div className="text-gray-500 text-right pr-2">MODIFIED:</div>
                  <div className="text-gray-300 break-words">{new Date(entity.modified).toLocaleString()}</div>

                  <div className="text-gray-500 text-right pr-2">CREATED:</div>
                  <div className="text-gray-300 break-words">{(entity as any).created ? new Date((entity as any).created).toLocaleString() : 'N/A'}</div>

                  {config.fileTaggingFeature !== false && entity.tags && entity.tags.length > 0 && (
                     <>
                        <div className="text-gray-500 text-right pr-2 mt-1">TAGS:</div>
                        <div className="flex flex-wrap gap-1 mt-1">
                           {entity.tags.map(tag => (
                              <span key={tag} className="text-[9px] px-1 rounded-sm bg-[#333] border border-[#555] capitalize">{tag}</span>
                           ))}
                        </div>
                     </>
                  )}
               </div>

               {/* Audio/Video extra info based on config */}
               {(isAudio || isVideo) && config.audioVideoPreview !== false && (
                   <div className="mt-4 border border-[#333] bg-[#0a0a0a] rounded p-2 text-[10px] text-gray-400">
                      <div className="flex items-center gap-2 mb-1">
                         <PlayCircle size={12} className="text-sky-500" />
                         <span className="font-bold text-gray-300">Media Information</span>
                         {((isAudio && config.muteAudioInRawPreview) || (isVideo && config.muteVideoOnPlay)) && (
                            <span className="ml-auto text-red-400 uppercase text-[9px] bg-red-900/40 px-1 rounded border border-red-500/50">Muted</span>
                         )}
                      </div>
                      <div className="grid grid-cols-[60px_1fr] gap-y-1 font-mono">
                         <div className="text-gray-500">Duration:</div><div>00:03:45</div>
                         <div className="text-gray-500">Bitrate:</div><div>320 kbps</div>
                         {isVideo && <><div className="text-gray-500">Res:</div><div>1920x1080</div></>}
                      </div>
                      {/* Fake media player controls */}
                      <div className="w-full bg-[#1e1e1e] h-1 mt-2 rounded flex overflow-hidden relative">
                          <div className="w-[30%] bg-sky-500 h-full"></div>
                      </div>
                      {config.autoplayAudioVideo && <div className="mt-1 text-sky-400 uppercase text-[9px]">Autoplaying</div>}
                   </div>
               )}
           </div>
       </div>
    </div>
  );
}
