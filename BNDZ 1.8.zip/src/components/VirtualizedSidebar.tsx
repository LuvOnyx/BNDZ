import React from 'react';
import { Tree } from 'react-arborist';
import { Folder } from 'lucide-react';

interface SidebarProps {
  data: any[];
}

export default function VirtualizedSidebar({ data }: SidebarProps) {
  // Placeholder component for Phase 12 
  // Preparing for directory tree replacement with robust virtualization
  
  return (
    <div className="w-full h-full text-[#d4d4d4] text-[12px] bg-[#111111]">
      <Tree
        data={data}
        rowHeight={24}
        width="100%"
        height={600} // Will be responsive in future
        indent={12}
        paddingTop={8}
        paddingBottom={8}
        className="virtualized-tree no-scrollbar"
      >
        {({ node, style, dragHandle }: any) => (
          <div 
            style={style} 
            ref={dragHandle} 
            className={`flex items-center px-2 cursor-pointer whitespace-nowrap 
              ${node.isSelected ? 'bg-[#264f78]' : 'hover:bg-[#2a2d2e]'}`}
            onClick={() => node.select()}
            onDoubleClick={() => node.toggle()}
          >
            {node.children && node.children.length > 0 ? (
              <span 
                className="w-3 text-gray-500 text-[10px] mr-[2px] flex justify-center hover:text-white"
                onClick={(e) => { e.stopPropagation(); node.toggle(); }}
              >
                {node.isOpen ? '▼' : '▶'}
              </span>
            ) : (
                <span className="w-3 mr-[2px]"></span>
            )}
            
            <Folder size={14} className="text-[#dcb67a] mr-[6px] shrink-0" />
            <span>{node.data.name}</span>
          </div>
        )}
      </Tree>
    </div>
  );
}
