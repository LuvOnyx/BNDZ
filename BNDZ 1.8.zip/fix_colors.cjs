const fs = require('fs');
let content = fs.readFileSync('src/components/ConfigurationDialog.tsx', 'utf8');

let index = 0;
content = content.replace(/<input type="color" defaultValue="([^"]+)"/g, (match, def) => {
    index++;
    let keyName = 'colorConfig' + index;
    return `<input type="color" value={config.${keyName} ?? "${def}"} onChange={e => updateConfig({${keyName}: e.target.value})}`;
});

// also fix standard selects that don't have onChange
let selIndex = 0;
content = content.replace(/<select className="([^"]+)">/g, (match, cls) => {
    selIndex++;
    let keyName = 'selectConfig' + selIndex;
    return `<select className="${cls}" value={config.${keyName} || ""} onChange={e => updateConfig({${keyName}: e.target.value})}>`;
});

fs.writeFileSync('src/components/ConfigurationDialog.tsx', content);
console.log('Fixed ' + index + ' inputs');
