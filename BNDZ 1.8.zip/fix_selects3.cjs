const fs = require('fs');
let content = fs.readFileSync('src/components/ConfigurationDialog.tsx', 'utf8');

const optionsMap = {
    sortMethod: ["Natural", "Alphabetical", "Date Modified", "Size", "Type"],
    autoCompleteFilter: ["Contains", "Starts with", "Ends with", "Exact match"],
    startupPane: ["Last active panel", "Left pane", "Right pane", "Folder tree"],
    startupWindowState: ["Normal", "Maximized", "Minimized", "Fullscreen"],
    labelStyle: ["Name column", "Full row", "Icon only"],
    tagsStorage: ["Absolute paths", "Relative paths", "Database"],
    encoding: ["UTF-16 LE BOM", "UTF-8", "ASCII", "ANSI"],
    selectCopyHandler: ["Default Windows handler", "BNDZ custom handler", "TeraCopy"],
    recreateSourceFolderStructure: ["Ask", "Never", "Always"],
    dateFormatInActionLabels: ["Age of action (how long ago)", "Absolute date/time", "Relative to today"],
    promptBeforeUndoRedo: ["If action is older than 10 minutes", "Always", "Never"],
    allowOnlySingleStepUndoRedo: ["Allow only single step undo/redo", "Allow multi-step undo/redo"],
    showSearchResultsIn: ["\"Search results\" tab (locked)", "Current tab", "New tab"],
    defaultBranchViewType: ["Files and folders", "Files only", "Folders only"],
    typeAheadFindMatch: ["Match at beginning", "Match anywhere", "Match exact"],
    thumbnailQuality: ["High Speed", "High Quality", "Balanced"],
    thumbnailTransparency: ["Neutral", "Checkered", "White", "Black"],
    thumbnailStyle: ["Shadow", "Flat", "Bordered", "3D"],
    thumbnailPadding: ["0", "2", "4", "6", "8", "10"],
    thumbnailCaptionLines: ["0", "1", "2", "3", "4"],
    movementBlowUp: ["Loupe", "Fullscreen", "Fit to window"],
    folderContentsPreviewSortedBy: ["Name", "Size", "Date", "Type"],
    openNewTab: ["Next to the current tab", "At the end"],
    onClosingTheCurrentTab: ["Activate the right tab", "Activate the left tab", "Activate the last active tab"],
    tabCaptions: ["Folder only", "Full path", "Custom"],
    showXCloseButtonsOnTabs: ["Selected tab", "All tabs", "None"],
    visualStyleTabs: ["XYplorer Style (Rounded)", "Square", "Modern", "Classic"],
    buttonsPositionTabs: ["Flexible", "Left", "Right"],
    tabKeyDualPane: ["Tab between both panes only", "Cycle through all controls"],
    resizingTheWindowDualPane: ["Both panes flexible size", "Keep left pane fixed", "Keep right pane fixed"],
    
    selectConfig4: ["Drives", "Folders", "Files"],
    selectConfig5: ["Zebra Stripes: Alternate Rows (1)", "Zebra Stripes: Alternate Rows (2)", "Solid Color"],
    selectConfig6: ["No border", "Solid border", "Dashed border"],
    selectConfig7: ["BNDZ Style (Rounded)", "Windows Native", "Flat"],
    selectConfig8: ["Solid", "Gradient", "Transparent"],
    selectConfig9: ["1", "2", "3", "4", "5"],
    selectConfig10: ["12", "24", "48", "96", "Unlimited"],
    selectConfig11: ["20", "40", "60", "80", "100"],
    selectConfig12: ["15", "30", "45", "60", "75"],
    selectConfig13: ["0", "25", "50", "75", "100"],
    selectConfig14: ["2", "4", "6", "8", "10"],
    selectConfig15: ["6", "12", "18", "24", "30"],
};

// More robust replacement
content = content.replace(/<select ([^>]+onChange=\{[^}]+\}[^>]*)>([\s\S]*?)<\/select>/g, (match, attrs, inner) => {
    let matchKey = attrs.match(/value=\{config\.([a-zA-Z0-9_]+)[^\}]*\}/);
    if (matchKey) {
        let key = matchKey[1];
        let opts = optionsMap[key];
        
        if (!opts) {
            let singleOptMatch = inner.match(/<option>([^<]+)<\/option>/);
            let defaultOpt = singleOptMatch ? singleOptMatch[1] : "Default";
            opts = [defaultOpt, "Option 1", "Option 2", "Option 3"];
        }

        let newInner = opts.map(o => `<option>${o}</option>`).join('');
        return `<select ${attrs}>${newInner}</select>`;
    }
    return match;
});

// For selects without value object mapped (like those in Thumbnails for widths)
content = content.replace(/<select className="bg-\[\#1e1e1e\] border border-\[\#666\] text-\[\#e0e0e0\] text-\[12px\] px-2 py-\[2px\] rounded-sm w-\[80px\] outline-none">\s*<option>([^<]+)<\/option>\s*<\/select>/g, (match, val) => {
    // Generate valid React state logic or preserve as dummy options
    let opts = [val, (parseInt(val)+32).toString(), (parseInt(val)+64).toString()];
    let newInner = opts.map(o => `<option>${o}</option>`).join('');
    return `<select className="bg-[#1e1e1e] border border-[#666] text-[#e0e0e0] text-[12px] px-2 py-[2px] rounded-sm w-[80px] outline-none">${newInner}</select>`;
});

fs.writeFileSync('src/components/ConfigurationDialog.tsx', content);
console.log('Selects safely fixed 3!');
