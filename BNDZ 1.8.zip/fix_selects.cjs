const fs = require('fs');
let content = fs.readFileSync('src/components/ConfigurationDialog.tsx', 'utf8');

// Options mapping for different select keys
const optionsMap = {
    sortMethod: ["Natural", "Alphabetical", "Date Modified", "Size", "Type"],
    autoCompleteFilter: ["Contains", "Starts with", "Ends with", "Exact match"],
    startupPane: ["Last active panel", "Left pane", "Right pane", "Folder tree"],
    startupWindowState: ["Normal", "Maximized", "Minimized", "Fullscreen"],
    labelStyle: ["Name column", "Full row", "Icon only"],
    tagsStorage: ["Absolute paths", "Relative paths", "Database"],
    encoding: ["UTF-16 LE BOM", "UTF-8", "ASCII", "ANSI"],
    selectCopyHandler: ["Default Windows handler", "BNDZ custom handler", "TeraCopy"],
    recreateSourceFolderStructure: ["Ask", "Never", "Always"],
    dateFormatInActionLabels: ["Age of action (how long ago)", "Absolute date/time", "Relative to today"],
    promptBeforeUndoRedo: ["If action is older than 10 minutes", "Always", "Never"],
    allowOnlySingleStepUndoRedo: ["Allow only single step undo/redo", "Allow multi-step undo/redo"],
    showSearchResultsIn: ["\"Search results\" tab (locked)", "Current tab", "New tab"],
    defaultBranchViewType: ["Files and folders", "Files only", "Folders only"],
    typeAheadFindMatch: ["Match at beginning", "Match anywhere", "Match exact"],
    // Thumbnails
    thumbnailQuality: ["High Speed", "High Quality", "Balanced"],
    thumbnailTransparency: ["Neutral", "Checkered", "White", "Black"],
    thumbnailStyle: ["Shadow", "Flat", "Bordered", "3D"],
    thumbnailPadding: ["0", "2", "4", "6", "8", "10"],
    thumbnailCaptionLines: ["0", "1", "2", "3", "4"],
    movementBlowUp: ["Loupe", "Fullscreen", "Fit to window"],
    folderContentsPreviewSortedBy: ["Name", "Size", "Date", "Type"],
    openNewTab: ["Next to the current tab", "At the end"],
    onClosingTheCurrentTab: ["Activate the right tab", "Activate the left tab", "Activate the last active tab"],
    tabCaptions: ["Folder only", "Full path", "Custom"],
    showXCloseButtonsOnTabs: ["Selected tab", "All tabs", "None"],
    visualStyleTabs: ["XYplorer Style (Rounded)", "Square", "Modern", "Classic"],
    buttonsPositionTabs: ["Flexible", "Left", "Right"],
    tabKeyDualPane: ["Tab between both panes only", "Cycle through all controls"],
    resizingTheWindowDualPane: ["Both panes flexible size", "Keep left pane fixed", "Keep right pane fixed"],
    
    // config1 to 15 (Colors and styles placeholders)
    selectConfig4: ["Drives", "Folders", "Files"],
    selectConfig5: ["Zebra Stripes: Alternate Rows (1)", "Zebra Stripes: Alternate Rows (2)", "Solid Color"],
    selectConfig6: ["No border", "Solid border", "Dashed border"],
    selectConfig7: ["BNDZ Style (Rounded)", "Windows Native", "Flat"],
    selectConfig8: ["Solid", "Gradient", "Transparent"],
    selectConfig9: ["1", "2", "3", "4", "5"],
    selectConfig10: ["12", "24", "48", "96", "Unlimited"],
    selectConfig11: ["20", "40", "60", "80", "100"],
    selectConfig12: ["15", "30", "45", "60", "75"],
    selectConfig13: ["0", "25", "50", "75", "100"],
    selectConfig14: ["2", "4", "6", "8", "10"],
    selectConfig15: ["6", "12", "18", "24", "30"],
};

// Regex to find a select and replace its options
content = content.replace(/<select([^>]*)value=\{config\.([a-zA-Z0-9_]+)[^\}]*\}([^>]*)>([\s\S]*?)<\/select>/g, (match, beforeValue, key, afterValue, inner) => {
    let opts = optionsMap[key];
    
    // If not found in map, attempt to extract the single option currently hardcoded and add some dummies
    if (!opts) {
        let singleOptMatch = inner.match(/<option>([^<]+)<\/option>/);
        let defaultOpt = singleOptMatch ? singleOptMatch[1] : "Default";
        opts = [defaultOpt, "Option 2", "Option 3"];
    }

    let newInner = opts.map(o => `<option>${o}</option>`).join('');
    
    // Rebuild the select
    // Be careful with the value prop. We want to preserve it.
    // the regex matched: <select (before) value={config.KEY ...} (after)> (inner) </select>
    // but the regex for value was: value=\{config\.([a-zA-Z0-9_]+)[^\}]*\}
    // So we match the full original value attribute string.
    let fullMatchStr = match;
    let oldSelectData = match.split('>')[0] + '>'; 
    return `${oldSelectData}${newInner}</select>`;
});

fs.writeFileSync('src/components/ConfigurationDialog.tsx', content);
console.log('Selects fixed!');
