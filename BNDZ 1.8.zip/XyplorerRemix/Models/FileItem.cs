using System;
using System.Collections.Generic;

namespace XyplorerRemix.Models
{
    public class FileItem
    {
        public string Name { get; set; } = string.Empty;
        public string Path { get; set; } = string.Empty;
        public string Extension { get; set; } = string.Empty;
        public long Size { get; set; }
        public bool IsDirectory { get; set; }
        public DateTime DateModified { get; set; }
        public DateTime DateCreated { get; set; }
        
        public string IconBase64 { get; set; } = string.Empty;
        public string FileTypeDescription { get; set; } = string.Empty;
        
        // Smart Tagging Support
        public List<string> Tags { get; set; } = new List<string>();
        
        public string DisplaySize => IsDirectory ? "" : FormatSize(Size);

        private static string FormatSize(long bytes)
        {
            string[] sizes = { "B", "KB", "MB", "GB", "TB" };
            double len = bytes;
            int order = 0;
            while (len >= 1024 && order < sizes.Length - 1)
            {
                order++;
                len = len / 1024;
            }
            return $"{len:0.##} {sizes[order]}";
        }
    }
}
