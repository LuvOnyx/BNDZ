using System;
using System.Collections.Generic;
using System.IO;

namespace XyplorerRemix.Models
{
    public class DirectorySyncProfile
    {
        public string SourcePath { get; set; } = string.Empty;
        public string TargetPath { get; set; } = string.Empty;
        public bool IsTwoWaySync { get; set; } = false;
        public DateTime LastSynced { get; set; }
    }
}
