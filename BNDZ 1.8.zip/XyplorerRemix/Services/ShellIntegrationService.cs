using System;
using System.Diagnostics;
using System.Reflection;
using Microsoft.Win32;
using System.Windows;

namespace XyplorerRemix.Services
{
    public class ShellIntegrationService
    {
        private const string DirectoryShellKey = @"Software\Classes\Directory\shell";
        private const string FolderShellKey = @"Software\Classes\Folder\shell";
        private const string AppKeyName = "BNDZFileManager";
        
        public void SetAsDefaultFileManager(bool enable)
        {
            try
            {
                string exePath = Assembly.GetExecutingAssembly().Location;
                exePath = Process.GetCurrentProcess()?.MainModule?.FileName ?? exePath;
                string command = $"\"{exePath}\" \"%1\"";

                if (enable)
                {
                    using (RegistryKey key = Registry.CurrentUser.CreateSubKey($@"{FolderShellKey}\{AppKeyName}"))
                    {
                        key.SetValue("", "Open with BNDZ");
                        using (var cmdKey = key.CreateSubKey("command"))
                        {
                            cmdKey.SetValue("", command);
                        }
                    }
                    using (RegistryKey key = Registry.CurrentUser.CreateSubKey(FolderShellKey))
                    {
                        key.SetValue("", AppKeyName);
                    }
                    using (RegistryKey key = Registry.CurrentUser.CreateSubKey(DirectoryShellKey))
                    {
                        key.SetValue("", AppKeyName);
                    }
                }
                else
                {
                    using (RegistryKey key = Registry.CurrentUser.OpenSubKey(FolderShellKey, true))
                    {
                        if (key != null)
                        {
                            key.SetValue("", "explore"); 
                            key.DeleteSubKeyTree(AppKeyName, false);
                        }
                    }
                    using (RegistryKey key = Registry.CurrentUser.OpenSubKey(DirectoryShellKey, true))
                    {
                        if (key != null)
                        {
                            key.DeleteValue("", false);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error modifying registry: {ex.Message}");
            }
        }

        public void SetInContextMenu(bool enable)
        {
            try
            {
                string exePath = Process.GetCurrentProcess()?.MainModule?.FileName ?? Assembly.GetExecutingAssembly().Location;
                string command = $"\"{exePath}\" \"%1\"";
                string contextMenuKey = $@"{DirectoryShellKey}\BNDZContextMenu";

                if (enable)
                {
                    using (RegistryKey key = Registry.CurrentUser.CreateSubKey(contextMenuKey))
                    {
                        key.SetValue("", "Open in BNDZ");
                        key.SetValue("Icon", $"\"{exePath}\",0");
                        using (var cmdKey = key.CreateSubKey("command"))
                        {
                            cmdKey.SetValue("", command);
                        }
                    }
                }
                else
                {
                    using (RegistryKey key = Registry.CurrentUser.OpenSubKey(DirectoryShellKey, true))
                    {
                        key?.DeleteSubKeyTree("BNDZContextMenu", false);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error modifying registry: {ex.Message}");
            }
        }

        public void RelaunchAsAdministrator()
        {
            try
            {
                string exePath = Process.GetCurrentProcess()?.MainModule?.FileName;
                if (string.IsNullOrEmpty(exePath)) return;

                var startInfo = new ProcessStartInfo
                {
                    FileName = exePath,
                    UseShellExecute = true,
                    Verb = "runas"
                };

                Process.Start(startInfo);
                Application.Current.Shutdown();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Elevation cancelled or failed: {ex.Message}");
            }
        }
    }
}
