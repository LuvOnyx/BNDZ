using System;
using System.Collections.Generic;
using EverythingNet.Core;
using EverythingNet.Query;

namespace XyplorerRemix.Services
{
    public class EverythingSearchService
    {
        public EverythingSearchService()
        {
        }

        public IEnumerable<string> Search(string query)
        {
            // Prepare backend for zero-latency global search using EverythingNet
            var results = new List<string>();
            try
            {
                if (EverythingState.IsStarted())
                {
                    var everything = new Everything();
                    var queryResult = everything.Search().Name.Contains(query);
                    foreach (var item in queryResult)
                    {
                        results.Add(item.FullPath);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Search failed: {ex.Message}");
            }
            return results;
        }
    }
}
