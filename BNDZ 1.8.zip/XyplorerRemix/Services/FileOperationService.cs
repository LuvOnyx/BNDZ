using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

namespace XyplorerRemix.Services
{
    public class FileOperationService
    {
        public delegate void ProgressCallback(string operationId, double percentage, string currentFile, long bytesTransferred, long totalBytes, double speedBytesPerSecond, int itemsCompleted, int totalItems);
        public delegate Task<string> ConflictCallback(string operationId, string fileName, string sourcePath, string destPath);

        public async Task ExecuteOperationAsync(
            string operationId, 
            string action, // "copy", "move", "delete"
            string sourceFile, 
            string targetDir, 
            ProgressCallback onProgress, 
            ConflictCallback onConflict)
        {
            await Task.Run(async () => 
            {
                if (action == "delete")
                {
                    if (File.Exists(sourceFile))
                    {
                        File.Delete(sourceFile);
                    }
                    else if (Directory.Exists(sourceFile))
                    {
                        Directory.Delete(sourceFile, true);
                    }
                    onProgress(operationId, 100, sourceFile, 0, 0, 0, 1, 1);
                    return;
                }

                // Normalizing paths
                sourceFile = sourceFile.Replace("/", "\\");
                targetDir = targetDir.Replace("/", "\\");
                if (!Directory.Exists(targetDir))
                {
                    Directory.CreateDirectory(targetDir);
                }

                bool isDirectory = Directory.Exists(sourceFile);
                List<string> filesToProcess = new List<string>();

                if (isDirectory)
                {
                    filesToProcess = Directory.GetFiles(sourceFile, "*.*", SearchOption.AllDirectories).ToList();
                }
                else if (File.Exists(sourceFile))
                {
                    filesToProcess.Add(sourceFile);
                }
                else
                {
                    return; // Does not exist
                }

                long totalBytes = 0;
                foreach (var f in filesToProcess)
                {
                    totalBytes += new FileInfo(f).Length;
                }

                long copiedBytes = 0;
                int totalItems = filesToProcess.Count;
                int itemsCompleted = 0;
                var sw = System.Diagnostics.Stopwatch.StartNew();

                var tasks = new List<Task>();
                foreach (var file in filesToProcess)
                {
                    string refPath = isDirectory ? Path.GetRelativePath(sourceFile, file) : Path.GetFileName(file);
                    string destPath = Path.Combine(targetDir, refPath);

                    string destDir = Path.GetDirectoryName(destPath);
                    if (!string.IsNullOrEmpty(destDir) && !Directory.Exists(destDir))
                        Directory.CreateDirectory(destDir);

                    // True async I/O
                    tasks.Add(ProcessSingleFileAsync(operationId, action, file, destPath, ref totalBytes, ref copiedBytes, ref itemsCompleted, totalItems, sw, onProgress, onConflict));

                    if (tasks.Count >= Environment.ProcessorCount * 4) // SSD max throughput throttle
                    {
                        var completedTask = await Task.WhenAny(tasks);
                        tasks.Remove(completedTask);
                    }
                }

                await Task.WhenAll(tasks);

                if (action == "move" && isDirectory) 
                {
                    // Clean up after moves
                    Directory.Delete(sourceFile, true);
                }
            });
        }

        private async Task ProcessSingleFileAsync(
            string operationId,
            string action,
            string sourceFile, 
            string destPath, 
            ref long totalBytes, 
            ref long copiedBytes,
            ref int itemsCompleted,
            int totalItems,
            System.Diagnostics.Stopwatch sw,
            ProgressCallback onProgress,
            ConflictCallback onConflict)
        {
            string finalDestPath = destPath;
            bool skip = false;

            if (File.Exists(finalDestPath))
            {
                var resolution = await onConflict(operationId, Path.GetFileName(sourceFile), sourceFile, finalDestPath);
                if (resolution == "skip")
                {
                    skip = true;
                    long size = new FileInfo(sourceFile).Length;
                    Interlocked.Add(ref copiedBytes, size);
                    Interlocked.Increment(ref itemsCompleted);
                    double speed = sw.Elapsed.TotalSeconds > 0 ? (double)Interlocked.Read(ref copiedBytes) / sw.Elapsed.TotalSeconds : 0;
                    onProgress(operationId, (double)copiedBytes / totalBytes * 100, sourceFile, copiedBytes, totalBytes, speed, itemsCompleted, totalItems);
                }
                else if (resolution == "replace")
                {
                    File.Delete(finalDestPath);
                }
                else if (resolution == "keepboth")
                {
                    string dir = Path.GetDirectoryName(finalDestPath);
                    string name = Path.GetFileNameWithoutExtension(finalDestPath);
                    string ext = Path.GetExtension(finalDestPath);
                    int counter = 1;
                    do
                    {
                        finalDestPath = Path.Combine(dir, $"{name} ({counter}){ext}");
                        counter++;
                    } while (File.Exists(finalDestPath));
                }
            }

            if (!skip)
            {
                await CopyFileToDestinationWithProgressAsync(operationId, sourceFile, finalDestPath, ref totalBytes, ref copiedBytes, ref itemsCompleted, totalItems, sw, onProgress);
                
                if (action == "move")
                {
                    File.Delete(sourceFile);
                }
            }
        }

        private async Task CopyFileToDestinationWithProgressAsync(
            string operationId,
            string sourceFile, 
            string destinationFile, 
            ref long totalBytes, 
            ref long copiedBytes,
            ref int itemsCompleted,
            int totalItems,
            System.Diagnostics.Stopwatch sw,
            ProgressCallback onProgress)
        {
            const int bufferSize = 4096 * 1024; // 4MB buffer for NVMe saturation
            using var sourceStream = new FileStream(sourceFile, FileMode.Open, FileAccess.Read, FileShare.Read, bufferSize, FileOptions.Asynchronous | FileOptions.SequentialScan);
            using var destinationStream = new FileStream(destinationFile, FileMode.Create, FileAccess.Write, FileShare.None, bufferSize, FileOptions.Asynchronous | FileOptions.SequentialScan);
            
            byte[] buffer = new byte[bufferSize];
            int bytesRead;

            while ((bytesRead = await sourceStream.ReadAsync(buffer, 0, buffer.Length)) > 0)
            {
                await destinationStream.WriteAsync(buffer, 0, bytesRead);
                Interlocked.Add(ref copiedBytes, bytesRead);
                
                double speed = sw.Elapsed.TotalSeconds > 0 ? (double)Interlocked.Read(ref copiedBytes) / sw.Elapsed.TotalSeconds : 0;
                onProgress(operationId, (double)Interlocked.Read(ref copiedBytes) / totalBytes * 100, sourceFile, Interlocked.Read(ref copiedBytes), totalBytes, speed, itemsCompleted, totalItems);
            }
            Interlocked.Increment(ref itemsCompleted);
            
            double finalSpeed = sw.Elapsed.TotalSeconds > 0 ? (double)Interlocked.Read(ref copiedBytes) / sw.Elapsed.TotalSeconds : 0;
            onProgress(operationId, (double)Interlocked.Read(ref copiedBytes) / totalBytes * 100, sourceFile, Interlocked.Read(ref copiedBytes), totalBytes, finalSpeed, itemsCompleted, totalItems);
        }
    }
}
