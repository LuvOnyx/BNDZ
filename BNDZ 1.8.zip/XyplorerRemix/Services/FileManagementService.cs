using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using Windows.Win32;
using Windows.Win32.UI.Shell;
using Windows.Win32.Foundation;
using Windows.Win32.Graphics.Gdi;
using System.Drawing;
using System.Drawing.Imaging;
using XyplorerRemix.Models;

namespace XyplorerRemix.Services
{
    public class FileManagementService
    {
        public List<FileItem> GetFilesAndDirectories(string path)
        {
            var items = new List<FileItem>();

            try
            {
                var dirInfo = new DirectoryInfo(path);

                // Add Directories
                foreach (var dir in dirInfo.GetDirectories())
                {
                    items.Add(new FileItem
                    {
                        Name = dir.Name,
                        Path = dir.FullName,
                        IsDirectory = true,
                        DateModified = dir.LastWriteTime,
                        DateCreated = dir.CreationTime,
                        FileTypeDescription = "File folder",
                        IconBase64 = GetIconBase64(dir.FullName, isDirectory: true)
                    });
                }

                // Add Files
                foreach (var file in dirInfo.GetFiles())
                {
                    items.Add(new FileItem
                    {
                        Name = file.Name,
                        Path = file.FullName,
                        Extension = file.Extension,
                        Size = file.Length,
                        IsDirectory = false,
                        DateModified = file.LastWriteTime,
                        DateCreated = file.CreationTime,
                        FileTypeDescription = GetFileTypeDescription(file.FullName),
                        IconBase64 = GetIconBase64(file.FullName, isDirectory: false)
                    });
                }
            }
            catch (UnauthorizedAccessException)
            {
                // Handle permission issues
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error reading path {path}: {ex.Message}");
            }

            return items;
        }

        private string GetFileTypeDescription(string path)
        {
            if (!OperatingSystem.IsWindows()) return "File";

            SHFILEINFO fileInfo = default;
            uint flags = PInvoke.SHGFI_TYPENAME;
            
            PInvoke.SHGetFileInfo(
                path,
                0,
                ref fileInfo,
                (uint)Marshal.SizeOf<SHFILEINFO>(),
                flags);

            return fileInfo.szTypeName.ToString();
        }

        private string GetIconBase64(string path, bool isDirectory)
        {
            if (!OperatingSystem.IsWindows()) return "";

            SHFILEINFO fileInfo = default;
            uint flags = PInvoke.SHGFI_ICON | PInvoke.SHGFI_SMALLICON;
            
            var res = PInvoke.SHGetFileInfo(
                path,
                0, // FILE_ATTRIBUTE_NORMAL
                ref fileInfo,
                (uint)Marshal.SizeOf<SHFILEINFO>(),
                flags);

            if (res != 0 && fileInfo.hIcon != IntPtr.Zero)
            {
                try
                {
                    using var icon = Icon.FromHandle(fileInfo.hIcon);
                    using var bmp = icon.ToBitmap();
                    using var ms = new MemoryStream();
                    bmp.Save(ms, ImageFormat.Png);
                    PInvoke.DestroyIcon(new HICON(fileInfo.hIcon));
                    return "data:image/png;base64," + Convert.ToBase64String(ms.ToArray());
                }
                catch
                {
                    // Ignore extraction errors
                }
            }
            return "";
        }

        public bool BatchRename(List<string> filePaths, string pattern, int startIndex = 1)
        {
            // Simple batch rename replacing {n} with index
            try
            {
                int index = startIndex;
                foreach (var filePath in filePaths)
                {
                    var fileInfo = new FileInfo(filePath);
                    if (fileInfo.Exists)
                    {
                        string newName = pattern.Replace("{n}", index.ToString()) + fileInfo.Extension;
                        string newPath = Path.Combine(fileInfo.DirectoryName ?? "", newName);
                        File.Move(filePath, newPath);
                        index++;
                    }
                }
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
