using System.Windows;
using Microsoft.Extensions.DependencyInjection;
using XyplorerRemix.Services;

namespace XyplorerRemix
{
    public partial class App : Application
    {
        public static ServiceProvider ServiceProvider { get; private set; }

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            var serviceCollection = new ServiceCollection();
            ConfigureServices(serviceCollection);
            ServiceProvider = serviceCollection.BuildServiceProvider();

            var mainWindow = ServiceProvider.GetRequiredService<MainWindow>();
            mainWindow.Show();
        }

        private void ConfigureServices(IServiceCollection services)
        {
            // Core Application Services
            services.AddSingleton<FileManagementService>();
            services.AddSingleton<AiAssistantService>();
            services.AddSingleton<ShellIntegrationService>();
            services.AddSingleton<NativeShellService>();
            services.AddSingleton<EverythingSearchService>();
            
            // UI Windows
            services.AddTransient<MainWindow>();
        }
    }
}
