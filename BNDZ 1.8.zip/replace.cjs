const fs = require('fs');
let content = fs.readFileSync('src/data/initialFS.ts', 'utf8');
content = content.replace(/XyplorerRemix/g, 'BNDZ');
content = content.replace(/Xyplorer Remix/g, 'BNDZ');
content = content.replace(/Xyplorer/gi, 'BNDZ');
fs.writeFileSync('src/data/initialFS.ts', content, 'utf8');
console.log('done');
