const fs = require('fs');

let content = fs.readFileSync('src/components/ConfigurationDialog.tsx', 'utf8');

let matchCount = 0;
// We'll replace <input type="text" ... /> without a value attribute.
// To avoid messy regex, we'll just replace the matching ones sequentially.

// Using a replacer to assign generic config keys based on adjacent text or a counter.
let counter = 1;

content = content.replace(/<input([^>]+)type="(text|number)"([^>]*)>/g, (match, before, type, after) => {
    // If it already has value= or onChange=, skip
    if (match.includes('value=') || match.includes('onChange=')) return match;
    
    // Also if it's readOnly, we probably shouldn't wire it? But the user says all options must work.
    if (match.includes('readOnly')) {
        after = after.replace(/readOnly/g, ''); // make it editable
    }

    // Try to extract a placeholder or defaultValue to guide the config key, 
    // or just use generic textConfig${counter}
    let configKey = `unwiredConfig${counter++}`;
    
    let defaultValue = "''";
    if (match.includes('defaultValue=')) {
         let defMatch = match.match(/defaultValue="([^"]+)"/);
         if (defMatch) defaultValue = `"${defMatch[1]}"`;
    }

    matchCount++;
    if (type === "number") {
         return `<input${before}type="number"${after.replace(/defaultValue="[^"]*"/, '')} value={config.${configKey} || ${defaultValue}} onChange={e => updateConfig({ ${configKey}: e.target.value })} />`.replace('/> />', '/>');
    } else {
         return `<input${before}type="text"${after.replace(/defaultValue="[^"]*"/, '')} value={config.${configKey} || ${defaultValue}} onChange={e => updateConfig({ ${configKey}: e.target.value })} />`.replace('/> />', '/>');
    }
});

fs.writeFileSync('src/components/ConfigurationDialog.tsx', content);
console.log('Fixed ' + matchCount + ' inputs');
