/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialization utility for GoogleGenAI
let aiClient: GoogleGenAI | null = null;
function getAIClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
      throw new Error("GEMINI_API_KEY environment variable is not configured yet. Set it in the Secrets manager.");
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// ---------------- GLOBAL API ROUTES ----------------

// 1. AI-Powered Smart File Organizer
app.post("/api/gemini/organize", async (req, res) => {
  try {
    const { files } = req.body;
    if (!files || !Array.isArray(files)) {
      return res.status(400).json({ error: "No files list provided for organization." });
    }

    const ai = getAIClient();
    const prompt = `Analyze this list of unsorted/messy files representing a desktop workspace or C# project. 
Group them logically into targeted directories (e.g. "Core", "UI", "Assets", "Logs", "Documents", "Media"). Reorganize them efficiently.

For each file in the following list, provide:
- The recommended target directory (relative name e.g. "Core" or "Logs")
- A list of appropriate semantic tags (choose from "urgent", "progress", "archive", "csharp", "raw" or custom tags like "log", "image")
- A short human-friendly explanation of why.

Files List:
${JSON.stringify(files, null, 2)}
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            organization: {
              type: Type.ARRAY,
              description: "Reorganization schema mapping file names to target paths",
              items: {
                type: Type.OBJECT,
                properties: {
                  fileName: { type: Type.STRING },
                  targetFolder: { type: Type.STRING, description: "Name of the target logical directory to place this file in." },
                  tags: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: "Proposed tags related to content context."
                  },
                  explanation: { type: Type.STRING, description: "Logical explanation for this file sort." }
                },
                required: ["fileName", "targetFolder", "tags", "explanation"]
              }
            }
          },
          required: ["organization"]
        }
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("Empty response from AI client");
    }
    res.json(JSON.parse(text));
  } catch (error: any) {
    console.error("AI Organize Error:", error);
    res.status(500).json({ error: error.message || "Failed to organize workspace" });
  }
});

// 2. AI-Powered Batch Renaming Assistant
app.post("/api/gemini/batch-rename", async (req, res) => {
  try {
    const { filenames, customInstructions } = req.body;
    if (!filenames || !Array.isArray(filenames)) {
      return res.status(400).json({ error: "Missing file list parameter" });
    }

    const ai = getAIClient();
    const prompt = `You are a professional file systems batch renamer. 
Follow these instructions precisely to map input filenames to their sanitized or stylized counterparts.

Instructions:
"${customInstructions || 'Clean special characters, replace spaces with underscores, and normalize files into standard casing format.'}"

List of file names to rename:
${JSON.stringify(filenames, null, 4)}
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            renamedFiles: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  originalName: { type: Type.STRING },
                  newName: { type: Type.STRING },
                  reason: { type: Type.STRING }
                },
                required: ["originalName", "newName", "reason"]
              }
            }
          },
          required: ["renamedFiles"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("Empty response from AI batch-rename worker.");
    res.json(JSON.parse(text));
  } catch (error: any) {
    console.error("AI Batch Rename Error:", error);
    res.status(500).json({ error: error.message || "Failed to batch rename" });
  }
});

// 3. AI-Powered Search and Analytics grounding Index
app.post("/api/gemini/search", async (req, res) => {
  try {
    const { query, fileIndex } = req.body;
    if (!query) {
      return res.status(400).json({ error: "Search query string is required" });
    }

    const ai = getAIClient();
    const prompt = `You are an intelligent file system indexing and search bot. 
Analyze the user's natural language search query and find corresponding file nodes from the active workspace file index. 

User Search Intent: "${query}"

Workspace Index:
${JSON.stringify(fileIndex, null, 2)}

Filter items that conceptualize the user's request. Return a JSON structure ranking matched items by a float score from 0.0 to 1.0, paired with an explanation. Set score to 0.0 for things not fitting the criteria at all.
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            matches: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  path: { type: Type.STRING, description: "Full logical workspace path of the element" },
                  score: { type: Type.NUMBER, description: "Match score representing relevance (0.0 to 1.0)" },
                  reason: { type: Type.STRING, description: "Reason why this file is relative to search context" }
                },
                required: ["path", "score", "reason"]
              }
            }
          },
          required: ["matches"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("Empty search indexing response.");
    res.json(JSON.parse(text));
  } catch (error: any) {
    console.error("AI Search Error:", error);
    res.status(500).json({ error: error.message || "Failed to search workspace via AI" });
  }
});

// 4. General Assistant Chat
app.post("/api/gemini/chat", async (req, res) => {
  try {
    const { messages } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: "Message timeline array is required" });
    }

    const ai = getAIClient();
    
    // Build context history
    const systemPayload = "You are a senior Windows systems developer, power-user, and virtual workspace advisor representing Xyplorer Remix. You offer insightful guidelines, batch-renaming script snippets (C# / CMD / PowerShell), custom file-organization architectures, metadata designs, and helpful C# developer advice.";
    
    const formattedMessages = messages.map((m: any) => ({
      role: m.role === "user" ? "user" : "model",
      parts: [{ text: m.content }]
    }));

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: formattedMessages,
      config: {
        systemInstruction: systemPayload,
      }
    });

    res.json({ reply: response.text });
  } catch (error: any) {
    console.error("AI Chat Error:", error);
    res.status(500).json({ error: error.message || "Failed to communicate with AI chat hub" });
  }
});

// Verification check
app.get("/api/health", (req, res) => {
  res.json({ status: "healthy", apiConfigured: !!process.env.GEMINI_API_KEY });
});

// ---------------- VITE / FRONTEND SERVING ----------------

async function setupServer() {
  if (process.env.NODE_ENV !== "production") {
    // Vite middleware for lightning-fast frontend bundling in dev mode
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Serve production build files
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Xyplorer Remix] Full-stack Server started at http://localhost:${PORT}`);
  });
}

setupServer().catch((error) => {
  console.error("Critical server configuration failure:", error);
});
