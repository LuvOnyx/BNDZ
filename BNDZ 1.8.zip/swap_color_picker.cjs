const fs = require('fs');
let content = fs.readFileSync('src/components/ConfigurationDialog.tsx', 'utf8');

if (!content.includes("import { ColorPicker } from './color-picker';")) {
  content = content.replace("import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';", "import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';\nimport { ColorPicker } from './color-picker';");
}

let count = 0;
// old format: <input type="color" defaultValue="#F0F0F0" className="w-full h-full p-0 border-none cursor-pointer" />
// new format: <input type="color" value={config.colorConfig1 ?? "#F0F0F0"} onChange={e => updateConfig({colorConfig1: e.target.value})} className="w-full h-full p-0 border-none cursor-pointer" />
// wait, we can just replace all <input type="color" ... /> with ColorPicker
content = content.replace(/<div className="w-\[60px\] border-l border-\[\#444\]"><input type="color" value=\{config\.([^ ]+) \?\? \"([^\"]+)\"\} onChange=\{e => updateConfig\(\{[^:]+: e\.target\.value\}\)\}[^>]+><\/div>/g, (match, keyName, defColor) => {
    count++;
    return `<ColorPicker value={config.${keyName} || "${defColor}"} onChange={(val) => updateConfig({${keyName}: val})} />`;
});

// There is one exception for <input type="color" value={config.... /> without the trailing tag because of JSX syntax. Let's just do a greedy match inside the container
content = content.replace(/<div className="w-\[60px\] border-l border-\[\#444\]">.*?<input type="color" value=\{config\.([a-zA-Z0-9_]+) \?\? \"([^\"]+)\"\} onChange=\{[^\}]+\}[^>]+><\/div>/g, (match, keyName, defColor) => {
    count++;
    return `<ColorPicker value={config.${keyName} || "${defColor}"} onChange={(val) => updateConfig({${keyName}: val})} />`;
});

// Wait, I fixed it to:
// <input type="color" value={config.colorConfig1 ?? "#F0F0F0"} onChange={e => updateConfig({colorConfig1: e.target.value})} className="w-full h-full p-0 border-none cursor-pointer" />
content = content.replace(/<input type="color" value=\{config\.([a-zA-Z0-9_]+) \?\? \"([^\"]+)\"\} onChange=\{[^\}]+\} className=\"[^\"]+\" \/>/g, (match, keyName, defColor) => {
    count++;
    return `<ColorPicker value={config.${keyName} || "${defColor}"} onChange={(val) => updateConfig({${keyName}: val})} />`;
});

fs.writeFileSync('src/components/ConfigurationDialog.tsx', content);
console.log('Replaced ' + count + ' color pickers');
