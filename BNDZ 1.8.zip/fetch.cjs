const https = require('node:https');

function fetchUrl(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(data));
    }).on('error', reject);
  });
}

(async () => {
    const urls = [
        'https://uiverse.io/bociKond/spotty-elephant-13',
        'https://uiverse.io/terenceodonoghue/rare-cow-16',
        'https://uiverse.io/Cybercom682/empty-wolverine-58'
    ];
    for (const url of urls) {
        const html = await fetchUrl(url);
        const match = html.match(/"htmlCode":"(.*?)","cssCode":"(.*?)"/);
        // Sometimes it's inside hydration state.
        // Let's just find anything resembling the code.
        const titleRegex = /<title>(.*?)<\/title>/;
        console.log("===", url, "===");
        const codeMatch = html.match(/"code":"(.*?)"/g);
        const htmlCodeMatch = html.match(/"html":"(.*?)"/);
        const cssCodeMatch = html.match(/"css":"(.*?)"/);
        const jsonMatch = html.match(/id="__REMIX_CONTEXT">.*?\]\)"/);
        
        console.log("title:", (html.match(titleRegex) || [])[1]);
        
        const preMatch = html.match(/<pre.*?>(.*?)<\/pre>/s);
        
        // try looking for common React props in the SSR html.
        // It's a remix app, we can extract from window.__remixContext
        try {
            const contextStr = html.split('window.__remixContext = ')[1].split(';')[0];
            const parsed = JSON.parse(contextStr);
            console.log("Found remix context!");
        } catch(e) {}
        
        const lines = html.split('\n');
        for (const line of lines) {
            if (line.includes('htmlCode') || line.includes('cssCode')) {
                console.log("Found line with codes:", line.substring(0, 500));
            }
        }
    }
})();
