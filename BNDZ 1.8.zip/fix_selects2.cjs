const fs = require('fs');
let content = fs.readFileSync('src/components/ConfigurationDialog.tsx', 'utf8');

const optionsMap = {
    sortMethod: ["Natural", "Alphabetical", "Date Modified", "Size", "Type"],
    autoCompleteFilter: ["Contains", "Starts with", "Ends with", "Exact match"],
    startupPane: ["Last active panel", "Left pane", "Right pane", "Folder tree"],
    startupWindowState: ["Normal", "Maximized", "Minimized", "Fullscreen"],
    labelStyle: ["Name column", "Full row", "Icon only"],
    tagsStorage: ["Absolute paths", "Relative paths", "Database"],
    encoding: ["UTF-16 LE BOM", "UTF-8", "ASCII", "ANSI"],
    selectCopyHandler: ["Default Windows handler", "BNDZ custom handler", "TeraCopy"],
    recreateSourceFolderStructure: ["Ask", "Never", "Always"],
    dateFormatInActionLabels: ["Age of action (how long ago)", "Absolute date/time", "Relative to today"],
    promptBeforeUndoRedo: ["If action is older than 10 minutes", "Always", "Never"],
    allowOnlySingleStepUndoRedo: ["Allow only single step undo/redo", "Allow multi-step undo/redo"],
    showSearchResultsIn: ["\"Search results\" tab (locked)", "Current tab", "New tab"],
    defaultBranchViewType: ["Files and folders", "Files only", "Folders only"],
    typeAheadFindMatch: ["Match at beginning", "Match anywhere", "Match exact"],
    // Thumbnails
    thumbnailQuality: ["High Speed", "High Quality", "Balanced"],
    thumbnailTransparency: ["Neutral", "Checkered", "White", "Black"],
    thumbnailStyle: ["Shadow", "Flat", "Bordered", "3D"],
    thumbnailPadding: ["0", "2", "4", "6", "8", "10"],
    thumbnailCaptionLines: ["0", "1", "2", "3", "4"],
    movementBlowUp: ["Loupe", "Fullscreen", "Fit to window"],
    folderContentsPreviewSortedBy: ["Name", "Size", "Date", "Type"],
    openNewTab: ["Next to the current tab", "At the end"],
    onClosingTheCurrentTab: ["Activate the right tab", "Activate the left tab", "Activate the last active tab"],
    tabCaptions: ["Folder only", "Full path", "Custom"],
    showXCloseButtonsOnTabs: ["Selected tab", "All tabs", "None"],
    visualStyleTabs: ["XYplorer Style (Rounded)", "Square", "Modern", "Classic"],
    buttonsPositionTabs: ["Flexible", "Left", "Right"],
    tabKeyDualPane: ["Tab between both panes only", "Cycle through all controls"],
    resizingTheWindowDualPane: ["Both panes flexible size", "Keep left pane fixed", "Keep right pane fixed"],
    
    // config1 to 15 (Colors and styles placeholders)
    selectConfig4: ["Drives", "Folders", "Files"],
    selectConfig5: ["Zebra Stripes: Alternate Rows (1)", "Zebra Stripes: Alternate Rows (2)", "Solid Color"],
    selectConfig6: ["No border", "Solid border", "Dashed border"],
    selectConfig7: ["BNDZ Style (Rounded)", "Windows Native", "Flat"],
    selectConfig8: ["Solid", "Gradient", "Transparent"],
    selectConfig9: ["1", "2", "3", "4", "5"],
    selectConfig10: ["12", "24", "48", "96", "Unlimited"],
    selectConfig11: ["20", "40", "60", "80", "100"],
    selectConfig12: ["15", "30", "45", "60", "75"],
    selectConfig13: ["0", "25", "50", "75", "100"],
    selectConfig14: ["2", "4", "6", "8", "10"],
    selectConfig15: ["6", "12", "18", "24", "30"],
};

// We will split the file by "<select " and for each part that contains "</select>", replace the inside.
const parts = content.split('<select ');
for (let i = 1; i < parts.length; i++) {
    const endHeader = parts[i].indexOf('>');
    const endSelect = parts[i].indexOf('</select>');
    
    if (endHeader !== -1 && endSelect !== -1 && endHeader < endSelect) {
        // extract header part (this contains value={config.XYZ} and onChange={...})
        const selectTagInner = parts[i].substring(0, endHeader);
        
        let match = selectTagInner.match(/value=\{config\.([a-zA-Z0-9_]+)/);
        if (match) {
            let key = match[1];
            let opts = optionsMap[key];
            
            if (!opts) {
                // Read what was originally there
                let htmlInside = parts[i].substring(endHeader + 1, endSelect);
                let singleOptMatch = htmlInside.match(/<option>([^<]+)<\/option>/);
                let defaultOpt = singleOptMatch ? singleOptMatch[1] : "Default";
                opts = [defaultOpt, "Option 1", "Option 2", "Option 3"];
            }

            let newInner = opts.map(o => `<option>${o}</option>`).join('');
            // Replace old inner with newInner
            parts[i] = parts[i].substring(0, endHeader + 1) + newInner + parts[i].substring(endSelect);
        }
    }
}
content = parts.join('<select ');

fs.writeFileSync('src/components/ConfigurationDialog.tsx', content);
console.log('Selects safely fixed!');
