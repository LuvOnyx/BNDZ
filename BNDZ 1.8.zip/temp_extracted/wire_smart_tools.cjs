const fs = require('fs');
let content = fs.readFileSync('src/components/SmartToolsDialog.tsx', 'utf8');

// First, remove the inline Checkbox definition
content = content.replace(/const Checkbox: React\.FC<[\s\S]*?\);\n\n/, '');

// Add the import if not present
if (!content.includes('import { Checkbox }')) {
  if (content.includes("import { ColorPicker }")) {
      content = content.replace(/import \{ ColorPicker \} from '\.\/color-picker';\n/, "import { ColorPicker } from './color-picker';\nimport { Checkbox } from './ui/checkbox';\n");
  } else {
      content = content.replace(/import React/g, "import { Checkbox } from './ui/checkbox';\nimport React");
  }
}

let matchCount = 0;
// We want to match all <Checkbox /> tags, regardless of whether they have onChange or checked already.
// We use [\s\S]+? to match across newlines inside the tag.
content = content.replace(/<Checkbox([\s\S]+?)\/>/g, (match, props) => {
    // Extract label
    let labelMatch = props.match(/label=\{([\s\S]+?)\}/);
    let labelStringMatch = props.match(/label=\"([^\"]+)\"/);
    let labelGroup = '';
    
    if (labelMatch) {
       labelGroup = `{${labelMatch[1]}}`;
    } else if (labelStringMatch) {
       labelGroup = `"${labelStringMatch[1]}"`;
    }
    
    if (!labelGroup) return match; // fallback
    
    let text = labelGroup.replace(/<[^>]+>/g, '').replace(/\"/g, '').replace(/^\{/, '').replace(/\}$/, '').trim();
    let keyName = text.replace(/[^a-zA-Z0-9]/g, ' ').split(' ').map((w,i) => i===0 ? w.toLowerCase() : w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join('');
    
    // clean keyName slightly further
    keyName = keyName.replace(/\s+/g,'');
    
    if (!keyName) keyName = 'unknownKey' + Math.floor(Math.random()*1000);
    if (keyName.length > 50) keyName = keyName.substring(0, 50); // limit string length
    
    // We update config and read from config. 
    // Wait, some checkboxes had `disabled` prop! We must preserve it if it exists!
    let disabledMatch = props.match(/disabled=\{([^\}]+)\}/);
    let disabledProp = '';
    if (disabledMatch) {
        if (disabledMatch[1]) {
            disabledProp = ` disabled={${disabledMatch[1]}}`;
        }
    } else if (props.includes('disabled') && !props.includes('disabled={')) {
        disabledProp = ` disabled={true}`;
    }
    
    matchCount++;
    return `<Checkbox label=${labelGroup} checked={settings.${keyName} ?? false} onChange={e => setSettings((s: any) => ({...s, [\`${keyName}\`]: e.target.checked}))}${disabledProp} />`;
});

fs.writeFileSync('src/components/SmartToolsDialog.tsx', content);
console.log('Wired ' + matchCount + ' checkboxes in SmartToolsDialog!');
