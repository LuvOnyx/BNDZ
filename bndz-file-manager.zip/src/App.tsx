/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ConfigProvider } from './data/configContext';
import { PluginRegistryProvider } from './data/PluginRegistryContext';
import BNDZUI from './components/BNDZUI';

export default function App() {
  return (
    <ConfigProvider>
      <PluginRegistryProvider>
        <BNDZUI />
      </PluginRegistryProvider>
    </ConfigProvider>
  );
}
