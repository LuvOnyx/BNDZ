import React, { useRef, useState } from 'react';
import { Dialog, DialogContent, DialogTitle, DialogDescription, DialogHeader, DialogTrigger } from "./ui/dialog";
import { Check, Plus, Upload, Settings, Search, Filter, Database, Layers, Replace, Puzzle, Trash } from 'lucide-react';
import { usePluginRegistry, PluginManifest } from '../data/PluginRegistryContext';

// Hardcoded map to resolve icons dynamically
const iconRegistry: Record<string, React.ElementType> = {
    'properties': Settings,
    'find': Search,
    'filters': Filter,
    'metadata': Database,
    'drop-stack': Layers,
    'batch-rename': Replace,
};

export function PluginStoreDialog({ children }: { children: React.ReactNode }) {
    const { pluginRegistry, togglePluginInstall, addPluginToRegistry } = usePluginRegistry();
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [searchQuery, setSearchQuery] = useState('');

    const handleImportPlugin = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const json = JSON.parse(event.target?.result as string);
                // Validate against schema
                if (
                    typeof json === 'object' && json !== null &&
                    typeof json.id === 'string' &&
                    typeof json.name === 'string' &&
                    typeof json.description === 'string' &&
                    (json.targetPanel === 'bottom' || json.targetPanel === 'sidebar') &&
                    typeof json.isNative === 'boolean'
                ) {
                    const newPlugin: PluginManifest = { ...json, isInstalled: true };
                    addPluginToRegistry(newPlugin);
                } else {
                    alert('Invalid plugin manifest schema.');
                }
            } catch (err) {
                alert('Invalid JSON file.');
            }
        };
        reader.readAsText(file);
    };

    const filteredPlugins = pluginRegistry.filter(plugin => 
        plugin.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        plugin.description.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <Dialog>
            {children}
            <DialogContent className="bg-[#1e1e1e] border-[#444] text-gray-200 sm:max-w-[750px] p-6">
                <DialogHeader className="flex flex-col gap-4">
                    <div className="flex flex-row justify-between items-start">
                        <div>
                            <DialogTitle className="text-[18px] font-bold text-white tracking-tight">Plugin Marketplace</DialogTitle>
                            <DialogDescription className="text-[13px] text-gray-400 mt-1">
                                Discover, install, and manage extensions for your workspace.
                            </DialogDescription>
                        </div>
                        <button 
                            onClick={() => fileInputRef.current?.click()}
                            className="flex items-center gap-2 border border-[#444] bg-[#2a2a2a] hover:bg-[#333] px-3 py-1.5 rounded transition-colors text-xs font-semibold text-gray-300"
                        >
                            <Upload size={14} /> Install from File...
                        </button>
                        <input 
                            type="file" 
                            accept=".json" 
                            ref={fileInputRef} 
                            style={{ display: 'none' }} 
                            onChange={handleImportPlugin} 
                        />
                    </div>
                    
                    {/* Search Bar */}
                    <div className="relative">
                        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                        <input 
                            type="text" 
                            placeholder="Search plugins by name or description..." 
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-full bg-[#111] border border-[#333] rounded px-9 py-2 text-sm text-white focus:outline-none focus:border-[#555] transition-colors"
                        />
                    </div>
                </DialogHeader>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4 max-h-[60vh] overflow-y-auto no-scrollbar pr-2 pb-2">
                    {filteredPlugins.length === 0 ? (
                        <div className="col-span-2 text-center text-gray-500 text-sm py-8">No plugins found matching your search.</div>
                    ) : (
                        filteredPlugins.map(plugin => {
                            const isInstalled = plugin.isInstalled;
                            const Icon = iconRegistry[plugin.id] || Puzzle;
                            return (
                                <div 
                                    key={plugin.id}
                                    className={`flex flex-col p-4 rounded-[6px] border transition-colors ${ isInstalled ? 'bg-[#181818] border-[#333]' : 'bg-[#1a1a1a] border-[#2a2a2a] hover:border-[#444]' }`}
                                >
                                    <div className="flex items-start gap-4 mb-3">
                                        <div className={`p-2 rounded-md shrink-0 ${isInstalled ? 'bg-sky-900/30 text-sky-400' : 'bg-[#222] text-gray-400'}`}>
                                            <Icon size={24} />
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <div className="flex items-center justify-between">
                                                <h3 className={`text-[14px] font-bold truncate ${isInstalled ? 'text-white' : 'text-gray-200'}`}>{plugin.name}</h3>
                                                <span className="text-[10px] text-gray-500 font-mono tracking-tighter">v1.0.0</span>
                                            </div>
                                            <p className="text-[11px] text-gray-500 leading-snug mt-1 line-clamp-2" title={plugin.description}>{plugin.description}</p>
                                        </div>
                                    </div>
                                    <div className="mt-auto flex justify-end">
                                        <button 
                                            onClick={() => togglePluginInstall(plugin.id)}
                                            className={`flex items-center gap-1.5 px-4 py-1.5 rounded-[4px] text-[11px] font-bold transition-colors ${
                                                isInstalled 
                                                    ? 'bg-red-900/20 text-red-400 hover:bg-red-900/40 border border-red-900/40' 
                                                    : 'bg-sky-600 text-white hover:bg-sky-500 border border-sky-500'
                                            }`}
                                        >
                                            {isInstalled ? (
                                                <><Trash size={12} /> Uninstall</>
                                            ) : (
                                                <><Plus size={12} /> Install</>
                                            )}
                                        </button>
                                    </div>
                                </div>
                            )
                        })
                    )}
                </div>
            </DialogContent>
        </Dialog>
    );
}
