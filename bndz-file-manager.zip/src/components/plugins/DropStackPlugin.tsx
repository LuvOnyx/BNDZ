import React, { useState } from 'react';
import { Layers, Copy, Scissors, Trash } from 'lucide-react';
import { IPC } from '../../lib/ipcBridge';

export const DropStackPluginDef = {
    id: "drop-stack",
    name: "Drop Stack",
    icon: Layers
};

interface StagedFile {
    name: string;
    path: string;
    size: number | string;
}

export default function DropStackPlugin({ activeTab, drives, config, entity, focusedPath }: any) {
    const [StagedFiles, setStagedFiles] = useState<StagedFile[]>([]);

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        try {
            const data = e.dataTransfer.getData("application/bndz-file");
            if (data) {
                const parsed = JSON.parse(data);
                // We use mock size if not available, or attempt to extract
                const mockSize = Math.floor(Math.random() * 1024 * 1024 * 5); // Just a mock size
                setStagedFiles(prev => [...prev, { path: `${parsed.sourcePath}/${parsed.entityId}`, name: parsed.entityId, size: mockSize }]);
            }
        } catch {}
    };

    const handleCopyAll = () => {
        if (!focusedPath) return;
        StagedFiles.forEach((item, i) => IPC.executeFsOperation(`stack-copy-${i}`, 'copy', item.path, focusedPath));
        setStagedFiles([]);
    };

    const handleMoveAll = () => {
        if (!focusedPath) return;
        StagedFiles.forEach((item, i) => IPC.executeFsOperation(`stack-move-${i}`, 'move', item.path, focusedPath));
        setStagedFiles([]);
    };

    return (
        <div 
            className="w-full h-full p-4 flex flex-col"
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
        >
            <div className="flex justify-between items-center mb-4">
                <span className="text-[13px] font-bold text-gray-200">Drop Stack (Virtual Clipboard)</span>
                <div className="flex gap-2">
                    <button onClick={handleCopyAll} className="px-3 py-1 bg-[#007acc] hover:bg-sky-600 rounded text-[11px] flex items-center gap-1"><Copy size={12}/> Copy All to Active Folder</button>
                    <button onClick={handleMoveAll} className="px-3 py-1 bg-[#264f78] hover:bg-sky-700 rounded text-[11px] flex items-center gap-1"><Scissors size={12}/> Move All to Active Folder</button>
                    <button onClick={() => setStagedFiles([])} className="px-3 py-1 bg-red-900/50 hover:bg-red-800 rounded text-[11px] flex items-center gap-1"><Trash size={12}/> Clear Stack</button>
                </div>
            </div>
            
            <div className="flex-1 border border-[#333] bg-[#111] overflow-y-auto w-full p-0 text-[11px]">
                {StagedFiles.length === 0 ? (
                    <div className="w-full h-full flex items-center justify-center text-[#555] italic">Drag items from the file list and drop here...</div>
                ) : (
                    <table className="w-full text-left border-collapse">
                        <thead className="bg-[#1a1a1a] sticky top-0 border-b border-[#333]">
                            <tr>
                                <th className="p-1.5 px-2 font-medium text-[#888] w-1/3">File Name</th>
                                <th className="p-1.5 px-2 font-medium text-[#888] w-1/2">Source Path</th>
                                <th className="p-1.5 px-2 font-medium text-[#888]">Byte Size</th>
                            </tr>
                        </thead>
                        <tbody>
                            {StagedFiles.map((it, idx) => (
                                <tr key={idx} className="border-b border-[#222]">
                                    <td className="p-1.5 px-2 font-medium text-gray-300 truncate max-w-[150px]">{it.name}</td>
                                    <td className="p-1.5 px-2 text-[#666] truncate max-w-[250px]">{it.path}</td>
                                    <td className="p-1.5 px-2 text-[#aaa] whitespace-nowrap">{typeof it.size === 'number' ? `${it.size} bytes` : it.size}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
        </div>
    );
}
